using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Stores.CreateStore;

public record CreateStoreRequest : IRequest<GetStoreResponse>
{
    public Int32? Id {get; set;}
    public String? Name {get; set;} = null!;
}