using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ExamTypes.GetExamTypeById;

public class GetExamTypeByIdHandler : IRequestHandler<GetExamTypeByIdRequest, OneOf<GetExamTypeResponse, ExamTypeNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetExamTypeByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetExamTypeResponse, ExamTypeNotFound>> Handle(GetExamTypeByIdRequest request, CancellationToken cancellationToken)
    {
        //var ExamType = await _context.ExamTypes.FirstOrDefaultAsync(x => x.ExamTypeId == request.id,
          //  cancellationToken: cancellationToken);s
        var ExamType = await _context.ExamType.FirstOrDefaultAsync(x => x.ExamTypeId == request.ExamTypeId
);

        if (ExamType is null) return new ExamTypeNotFound();
        return _mapper.Map<GetExamTypeResponse>(ExamType);
    }
}
