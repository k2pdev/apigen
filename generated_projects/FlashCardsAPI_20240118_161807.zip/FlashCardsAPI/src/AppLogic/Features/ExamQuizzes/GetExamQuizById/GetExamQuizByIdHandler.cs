using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ExamQuizzes.GetExamQuizById;

public class GetExamQuizByIdHandler : IRequestHandler<GetExamQuizByIdRequest, OneOf<GetExamQuizResponse, ExamQuizNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetExamQuizByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetExamQuizResponse, ExamQuizNotFound>> Handle(GetExamQuizByIdRequest request, CancellationToken cancellationToken)
    {
        //var ExamQuiz = await _context.ExamQuizzes.FirstOrDefaultAsync(x => x.ExamQuizId == request.id,
          //  cancellationToken: cancellationToken);s
        var ExamQuiz = await _context.ExamQuiz.FirstOrDefaultAsync(x => x.ExamId == request.ExamId
 && x.QuizId == request.QuizId
);

        if (ExamQuiz is null) return new ExamQuizNotFound();
        return _mapper.Map<GetExamQuizResponse>(ExamQuiz);
    }
}
