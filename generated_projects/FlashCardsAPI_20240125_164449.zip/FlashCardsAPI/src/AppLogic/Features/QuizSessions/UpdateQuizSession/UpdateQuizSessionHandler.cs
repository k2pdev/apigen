using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.QuizSessions.UpdateQuizSession;

public class UpdateQuizSessionHandler : IRequestHandler<UpdateQuizSessionRequest, OneOf<GetQuizSessionResponse, QuizSessionNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateQuizSessionHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetQuizSessionResponse, QuizSessionNotFound>> Handle(UpdateQuizSessionRequest request,
        CancellationToken cancellationToken)
    {
        var updateQuizSession = await _context.QuizSession.FirstOrDefaultAsync(x => x.QuizSessionId == request.QuizSessionId
        , cancellationToken);
        if (updateQuizSession == null) return new QuizSessionNotFound();


updateQuizSession.QuizSessionId = request.QuizSessionId;
updateQuizSession.QuizId = request.QuizId;
updateQuizSession.AppUserId = request.AppUserId;


        _context.QuizSession.Update(updateQuizSession);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetQuizSessionResponse>(updateQuizSession);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);