using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Employees.GetAllEmployees;

public record GetAllEmployeesRequest : PaginatedRequest, IRequest<PaginatedList<GetEmployeesResponse>>;