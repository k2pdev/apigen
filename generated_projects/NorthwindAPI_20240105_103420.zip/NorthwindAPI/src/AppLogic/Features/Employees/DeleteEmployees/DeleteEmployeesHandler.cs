using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Employees.DeleteEmployees;

public class DeleteEmployeesHandler : IRequestHandler<DeleteEmployeesRequest, OneOf<bool, EmployeesNotFound>>
{
    private readonly IContext _context;
    public DeleteEmployeesHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, EmployeesNotFound>> Handle(DeleteEmployeesRequest request, CancellationToken cancellationToken)
    {
        var Employees = await _context.Employees.FirstOrDefaultAsync(x => x.EmployeeID == request.EmployeeID
);

        if (Employees is null) return new EmployeesNotFound();

        _context.Employees.Remove(Employees);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
