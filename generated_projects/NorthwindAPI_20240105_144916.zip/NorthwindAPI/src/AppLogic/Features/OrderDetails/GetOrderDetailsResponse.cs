using Domain.Entities.Common;
using System;

namespace AppLogic.Features.OrderDetails;

public record GetOrderDetailsResponse
{
    public Int32? OrderID {get; set;}
    public Int32? ProductID {get; set;}
    public Int32? UnitPrice {get; set;}
    public Int32? Quantity {get; set;}
    public Int32? Discount {get; set;}
}



