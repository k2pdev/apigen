using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.AppUsers.GetAllAppUsers;

public record GetAllAppUsersRequest : PaginatedRequest, IRequest<PaginatedList<GetAppUserResponse>>;