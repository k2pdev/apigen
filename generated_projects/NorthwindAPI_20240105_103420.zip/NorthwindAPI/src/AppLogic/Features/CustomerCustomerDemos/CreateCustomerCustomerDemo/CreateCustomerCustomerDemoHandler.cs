using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.CustomerCustomerDemos.CreateCustomerCustomerDemo;

public class CreateCustomerCustomerDemoHandler : IRequestHandler<CreateCustomerCustomerDemoRequest, GetCustomerCustomerDemoResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateCustomerCustomerDemoHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetCustomerCustomerDemoResponse?> Handle(CreateCustomerCustomerDemoRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.CustomerCustomerDemo>(request);
        _context.CustomerCustomerDemo.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetCustomerCustomerDemoResponse?>(created);
    }
}