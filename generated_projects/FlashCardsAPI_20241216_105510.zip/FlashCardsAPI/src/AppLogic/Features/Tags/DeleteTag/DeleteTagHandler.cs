using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Tags.DeleteTag;

public class DeleteTagHandler : IRequestHandler<DeleteTagRequest, OneOf<bool, TagNotFound>>
{
    private readonly IContext _context;
    public DeleteTagHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, TagNotFound>> Handle(DeleteTagRequest request, CancellationToken cancellationToken)
    {
        var Tag = await _context.Tag.FirstOrDefaultAsync(x => x.TagId == request.TagId
 && x.TagName == request.TagName
);

        if (Tag is null) return new TagNotFound();

        _context.Tag.Remove(Tag);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
