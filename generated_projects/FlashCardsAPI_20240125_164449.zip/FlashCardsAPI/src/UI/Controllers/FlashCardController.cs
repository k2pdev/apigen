using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.FlashCards.GetAllFlashCards;
using AppLogic.Features.FlashCards.GetFlashCardById;
using AppLogic.Features.FlashCards.CreateFlashCard;
using AppLogic.Features.FlashCards.UpdateFlashCard;
using AppLogic.Features.FlashCards.DeleteFlashCard;
using AppLogic.Features.FlashCards;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class FlashCardController : ControllerBase
{
  private readonly IMediator _mediator;
  public FlashCardController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllFlashCards")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetFlashCardResponse>>> GetAllFlashCards([FromQuery] GetAllFlashCardsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetFlashCardById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetFlashCardById(Int32? _FlashCardId)
  {
    var result = await _mediator.Send(new GetFlashCardByIdRequest(_FlashCardId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateFlashCard")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetFlashCardResponse> CreateFlashCard([FromBody] CreateFlashCardRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateFlashCard")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateFlashCard(Int32? _FlashCardId, [FromBody] UpdateFlashCardRequest req)
  {
      var result = await _mediator.Send(req with {FlashCardId = _FlashCardId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteFlashCard")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteFlashCard(Int32? _FlashCardId)
  {
      var result = await _mediator.Send(new DeleteFlashCardRequest( _FlashCardId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}