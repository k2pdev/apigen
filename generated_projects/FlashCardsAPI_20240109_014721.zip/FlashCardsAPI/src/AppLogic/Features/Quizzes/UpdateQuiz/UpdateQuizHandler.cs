using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Quizzes.UpdateQuiz;

public class UpdateQuizHandler : IRequestHandler<UpdateQuizRequest, OneOf<GetQuizResponse, QuizNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateQuizHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetQuizResponse, QuizNotFound>> Handle(UpdateQuizRequest request,
        CancellationToken cancellationToken)
    {
        var updateQuiz = await _context.Quiz.FirstOrDefaultAsync(x => x.QuizId == request.QuizId
        , cancellationToken);
        if (updateQuiz == null) return new QuizNotFound();


updateQuiz.QuizId = request.QuizId;
updateQuiz.ParentQuizId = request.ParentQuizId;
updateQuiz.QuizName = request.QuizName;


        _context.Quiz.Update(updateQuiz);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetQuizResponse>(updateQuiz);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);