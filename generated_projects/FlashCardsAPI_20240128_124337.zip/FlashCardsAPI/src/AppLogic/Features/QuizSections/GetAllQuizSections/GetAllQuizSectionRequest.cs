using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.QuizSections.GetAllQuizSections;

public record GetAllQuizSectionsRequest : PaginatedRequest, IRequest<PaginatedList<GetQuizSectionResponse>>;