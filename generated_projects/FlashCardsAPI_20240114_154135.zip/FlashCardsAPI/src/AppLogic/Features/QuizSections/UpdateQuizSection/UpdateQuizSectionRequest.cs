using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.QuizSections.UpdateQuizSection;

public record UpdateQuizSectionRequest : IRequest<OneOf<GetQuizSectionResponse, QuizSectionNotFound>>
{
    public Int32? QuizId {get; set;}
    public Int32? SectionId {get; set;}
    public String? SectionName {get; set;} = null!;
}   