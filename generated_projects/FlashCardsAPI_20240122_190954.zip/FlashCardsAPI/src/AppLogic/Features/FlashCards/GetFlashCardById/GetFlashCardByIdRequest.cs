using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.FlashCards.GetFlashCardById;

//ublic record GetFlashCardByIdRequest(Int32? id) : IRequest<OneOf<GetFlashCardResponse, FlashCardNotFound>>;

public record GetFlashCardByIdRequest(Int32? FlashCardId) : IRequest<OneOf<GetFlashCardResponse, FlashCardNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;