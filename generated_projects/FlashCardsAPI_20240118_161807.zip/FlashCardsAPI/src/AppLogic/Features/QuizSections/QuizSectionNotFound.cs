using AppLogic.Common.Responses;

namespace AppLogic.Features.QuizSections;

public record QuizSectionNotFound : NotFound {}