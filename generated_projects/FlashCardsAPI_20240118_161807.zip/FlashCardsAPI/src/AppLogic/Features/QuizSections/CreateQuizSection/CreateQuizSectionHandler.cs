using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.QuizSections.CreateQuizSection;

public class CreateQuizSectionHandler : IRequestHandler<CreateQuizSectionRequest, GetQuizSectionResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateQuizSectionHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetQuizSectionResponse?> Handle(CreateQuizSectionRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.QuizSection>(request);
        _context.QuizSection.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetQuizSectionResponse?>(created);
    }
}