using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Regions.CreateRegion;

public class CreateRegionHandler : IRequestHandler<CreateRegionRequest, GetRegionResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateRegionHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetRegionResponse?> Handle(CreateRegionRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.Region>(request);
        _context.Region.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetRegionResponse?>(created);
    }
}