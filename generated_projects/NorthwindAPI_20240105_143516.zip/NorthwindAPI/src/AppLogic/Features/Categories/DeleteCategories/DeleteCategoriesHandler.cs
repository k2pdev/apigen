using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Categories.DeleteCategories;

public class DeleteCategoriesHandler : IRequestHandler<DeleteCategoriesRequest, OneOf<bool, CategoriesNotFound>>
{
    private readonly IContext _context;
    public DeleteCategoriesHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, CategoriesNotFound>> Handle(DeleteCategoriesRequest request, CancellationToken cancellationToken)
    {
        var Categories = await _context.Categories.FirstOrDefaultAsync(x => x.CategoryID == request.CategoryID
);

        if (Categories is null) return new CategoriesNotFound();

        _context.Categories.Remove(Categories);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
