using AppLogic.Common.Responses;

namespace AppLogic.Features.Products;

public record ProductsNotFound : NotFound {}