using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.Categories.UpdateCategories;

public record UpdateCategoriesRequest : IRequest<OneOf<GetCategoriesResponse, CategoriesNotFound>>
{
    public Int32? CategoryID {get; set;}
    public String? CategoryName {get; set;} = null!;
    public String? Description {get; set;}
    public System.Byte[]? Picture {get; set;} = null!;
}   