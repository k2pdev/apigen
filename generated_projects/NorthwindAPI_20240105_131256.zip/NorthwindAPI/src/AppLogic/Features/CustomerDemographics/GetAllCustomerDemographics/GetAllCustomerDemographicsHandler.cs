using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.CustomerDemographics.GetAllCustomerDemographics;

public class GetAllCustomerDemographicsHandler : IRequestHandler<GetAllCustomerDemographicsRequest, PaginatedList<GetCustomerDemographicsResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllCustomerDemographicsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetCustomerDemographicsResponse>> Handle(GetAllCustomerDemographicsRequest request, CancellationToken cancellationToken)
    {
        var CustomerDemographics = _context.CustomerDemographics;
        return await _mapper.ProjectTo<GetCustomerDemographicsResponse>(CustomerDemographics)
            .OrderBy(x => x.CustomerDesc) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    