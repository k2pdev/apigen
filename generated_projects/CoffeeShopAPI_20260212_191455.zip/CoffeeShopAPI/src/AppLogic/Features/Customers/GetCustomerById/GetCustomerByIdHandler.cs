using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Customers.GetCustomerById;

public class GetCustomerByIdHandler : IRequestHandler<GetCustomerByIdRequest, OneOf<GetCustomerResponse, CustomerNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetCustomerByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetCustomerResponse, CustomerNotFound>> Handle(GetCustomerByIdRequest request, CancellationToken cancellationToken)
    {
        //var Customer = await _context.Customers.FirstOrDefaultAsync(x => x.CustomerId == request.id,
          //  cancellationToken: cancellationToken);s
        var Customer = await _context.Customer.FirstOrDefaultAsync(x => x.CustomerId == request.CustomerId
);

        if (Customer is null) return new CustomerNotFound();
        return _mapper.Map<GetCustomerResponse>(Customer);
    }
}
