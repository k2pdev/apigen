using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Regions.GetAllRegions;

public class GetAllRegionsHandler : IRequestHandler<GetAllRegionsRequest, PaginatedList<GetRegionResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllRegionsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetRegionResponse>> Handle(GetAllRegionsRequest request, CancellationToken cancellationToken)
    {
        var Region = _context.Region;
        return await _mapper.ProjectTo<GetRegionResponse>(Region)
            .OrderBy(x => x.RegionDescription) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    