using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.AppUsers.GetAllAppUsers;
using AppLogic.Features.AppUsers.GetAppUserById;
using AppLogic.Features.AppUsers.CreateAppUser;
using AppLogic.Features.AppUsers.UpdateAppUser;
using AppLogic.Features.AppUsers.DeleteAppUser;
using AppLogic.Features.AppUsers;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class AppUserController : ControllerBase
{
  private readonly IMediator _mediator;
  public AppUserController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllAppUsers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetAppUserResponse>>> GetAllAppUsers([FromQuery] GetAllAppUsersRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetAppUserById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetAppUserById(Int32? _AppUserId)
  {
    var result = await _mediator.Send(new GetAppUserByIdRequest(_AppUserId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateAppUser")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetAppUserResponse> CreateAppUser([FromBody] CreateAppUserRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateAppUser")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateAppUser(Int32? _AppUserId, [FromBody] UpdateAppUserRequest req)
  {
      var result = await _mediator.Send(req with {AppUserId = _AppUserId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteAppUser")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteAppUser(Int32? _AppUserId)
  {
      var result = await _mediator.Send(new DeleteAppUserRequest( _AppUserId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}