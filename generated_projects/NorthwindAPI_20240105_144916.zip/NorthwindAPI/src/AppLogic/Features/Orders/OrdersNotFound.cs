using AppLogic.Common.Responses;

namespace AppLogic.Features.Orders;

public record OrdersNotFound : NotFound {}