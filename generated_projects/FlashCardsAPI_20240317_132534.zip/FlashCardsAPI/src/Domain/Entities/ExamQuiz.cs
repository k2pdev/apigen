
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(ExamId),        nameof(QuizId))]
  public partial class ExamQuiz
  {
    public Int32? ExamId {get; set;}
    public Int32? QuizId {get; set;}
  }


