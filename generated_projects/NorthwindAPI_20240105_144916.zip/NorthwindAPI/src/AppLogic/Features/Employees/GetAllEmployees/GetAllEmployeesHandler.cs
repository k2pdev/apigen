using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Employees.GetAllEmployees;

public class GetAllEmployeesHandler : IRequestHandler<GetAllEmployeesRequest, PaginatedList<GetEmployeesResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllEmployeesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetEmployeesResponse>> Handle(GetAllEmployeesRequest request, CancellationToken cancellationToken)
    {
        var Employees = _context.Employees;
        return await _mapper.ProjectTo<GetEmployeesResponse>(Employees)
            .OrderBy(x => x.LastName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    