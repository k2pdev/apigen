using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Exams.CreateExam;

public class CreateExamHandler : IRequestHandler<CreateExamRequest, GetExamResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateExamHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetExamResponse?> Handle(CreateExamRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.Exam>(request);
        _context.Exam.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetExamResponse?>(created);
    }
}