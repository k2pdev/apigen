using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Customers.DeleteCustomers;

public class DeleteCustomersHandler : IRequestHandler<DeleteCustomersRequest, OneOf<bool, CustomersNotFound>>
{
    private readonly IContext _context;
    public DeleteCustomersHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, CustomersNotFound>> Handle(DeleteCustomersRequest request, CancellationToken cancellationToken)
    {
        var Customers = await _context.Customers.FirstOrDefaultAsync(x => x.CustomerID == request.CustomerID
);

        if (Customers is null) return new CustomersNotFound();

        _context.Customers.Remove(Customers);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
