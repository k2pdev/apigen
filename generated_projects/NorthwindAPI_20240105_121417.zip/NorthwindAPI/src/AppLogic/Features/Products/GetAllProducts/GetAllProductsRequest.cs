using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Products.GetAllProducts;

public record GetAllProductsRequest : PaginatedRequest, IRequest<PaginatedList<GetProductsResponse>>;