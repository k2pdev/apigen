using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.OrderDetails.CreateOrderDetails;

public record CreateOrderDetailsRequest : IRequest<GetOrderDetailsResponse>
{
    public Int32? OrderID {get; set;}
    public Int32? ProductID {get; set;}
    public Int32? UnitPrice {get; set;}
    public Int32? Quantity {get; set;}
    public Int32? Discount {get; set;}
}