using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.QuizSessions.GetQuizSessionById;

//ublic record GetQuizSessionByIdRequest(Int32? id) : IRequest<OneOf<GetQuizSessionResponse, QuizSessionNotFound>>;

public record GetQuizSessionByIdRequest(Int32? QuizSessionId) : IRequest<OneOf<GetQuizSessionResponse, QuizSessionNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;