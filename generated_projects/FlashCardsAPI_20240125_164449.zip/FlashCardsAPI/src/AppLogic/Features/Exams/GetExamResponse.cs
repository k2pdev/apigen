using Domain.Entities.Common;
using System;

namespace AppLogic.Features.Exams;

public record GetExamResponse
{
    public Int32? ExamId {get; set;}
    public Int32? ExamType {get; set;}
    public String? ExamName {get; set;} = null!;
}



