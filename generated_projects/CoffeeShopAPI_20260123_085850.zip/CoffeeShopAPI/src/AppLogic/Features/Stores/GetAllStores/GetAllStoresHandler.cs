using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Stores.GetAllStores;

public class GetAllStoresHandler : IRequestHandler<GetAllStoresRequest, PaginatedList<GetStoreResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllStoresHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetStoreResponse>> Handle(GetAllStoresRequest request, CancellationToken cancellationToken)
    {
        var Store = _context.Store;
        return await _mapper.ProjectTo<GetStoreResponse>(Store)
            .OrderBy(x => x.Name) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    