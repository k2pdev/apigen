using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Customers.DeleteCustomer;

//public record DeleteCustomerRequest : IRequest<OneOf<GetCustomerResponse, CustomerNotFound>>
//public record DeleteCustomerRequest : IRequest<OneOf<bool, CustomerNotFound>>

public record DeleteCustomerRequest(Guid? CustomerId) : IRequest<OneOf<bool, CustomerNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
