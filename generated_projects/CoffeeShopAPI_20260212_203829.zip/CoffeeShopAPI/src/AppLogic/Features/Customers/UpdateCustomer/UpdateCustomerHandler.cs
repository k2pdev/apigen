using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Customers.UpdateCustomer;

public class UpdateCustomerHandler : IRequestHandler<UpdateCustomerRequest, OneOf<GetCustomerResponse, CustomerNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateCustomerHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetCustomerResponse, CustomerNotFound>> Handle(UpdateCustomerRequest request,
        CancellationToken cancellationToken)
    {
        var updateCustomer = await _context.Customer.FirstOrDefaultAsync(x => x.CustomerId == request.CustomerId
        , cancellationToken);
        if (updateCustomer == null) return new CustomerNotFound();


updateCustomer.CustomerId = request.CustomerId;
updateCustomer.FirstName = request.FirstName;
updateCustomer.LastName = request.LastName;


        _context.Customer.Update(updateCustomer);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetCustomerResponse>(updateCustomer);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);