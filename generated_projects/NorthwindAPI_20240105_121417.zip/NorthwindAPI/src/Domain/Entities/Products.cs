
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(ProductID))]
  public partial class Products
  {
    public Int32? ProductID {get; set;}
    public String? ProductName {get; set;} = null!;
    public Int32? SupplierID {get; set;}
    public Int32? CategoryID {get; set;}
    public String? QuantityPerUnit {get; set;} = null!;
    public String? UnitPrice {get; set;}
    public String? UnitsInStock {get; set;}
    public String? UnitsOnOrder {get; set;}
    public String? ReorderLevel {get; set;}
    public Boolean? Discontinued {get; set;}
  }


