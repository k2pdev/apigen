using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.QuizSessions.GetAllQuizSessions;

public class GetAllQuizSessionsHandler : IRequestHandler<GetAllQuizSessionsRequest, PaginatedList<GetQuizSessionResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllQuizSessionsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetQuizSessionResponse>> Handle(GetAllQuizSessionsRequest request, CancellationToken cancellationToken)
    {
        var QuizSession = _context.QuizSession;
        return await _mapper.ProjectTo<GetQuizSessionResponse>(QuizSession)
            .OrderBy(x => x.AppUserId) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    