using Domain.Entities.Common;
using System;

namespace AppLogic.Features.Shippers;

public record GetShippersResponse
{
    public Int32? ShipperID {get; set;}
    public String? CompanyName {get; set;} = null!;
    public String? Phone {get; set;} = null!;
}



