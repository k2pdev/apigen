using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.OrderDetails.GetOrderDetailsById;

public class GetOrderDetailsByIdHandler : IRequestHandler<GetOrderDetailsByIdRequest, OneOf<GetOrderDetailsResponse, OrderDetailsNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetOrderDetailsByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetOrderDetailsResponse, OrderDetailsNotFound>> Handle(GetOrderDetailsByIdRequest request, CancellationToken cancellationToken)
    {
        //var OrderDetails = await _context.OrderDetails.FirstOrDefaultAsync(x => x.OrderDetailsId == request.id,
          //  cancellationToken: cancellationToken);s
        var OrderDetails = await _context.OrderDetails.FirstOrDefaultAsync(x => x.OrderID == request.OrderID
);

        if (OrderDetails is null) return new OrderDetailsNotFound();
        return _mapper.Map<GetOrderDetailsResponse>(OrderDetails);
    }
}
