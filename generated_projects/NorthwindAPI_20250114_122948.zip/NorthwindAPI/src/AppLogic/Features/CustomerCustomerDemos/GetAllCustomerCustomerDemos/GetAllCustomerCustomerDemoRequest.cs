using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.CustomerCustomerDemos.GetAllCustomerCustomerDemos;

public record GetAllCustomerCustomerDemosRequest : PaginatedRequest, IRequest<PaginatedList<GetCustomerCustomerDemoResponse>>;