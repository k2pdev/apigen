using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.Shippers.UpdateShippers;

public record UpdateShippersRequest : IRequest<OneOf<GetShippersResponse, ShippersNotFound>>
{
    public Int32? ShipperID {get; set;}
    public String? CompanyName {get; set;} = null!;
    public String? Phone {get; set;} = null!;
}   