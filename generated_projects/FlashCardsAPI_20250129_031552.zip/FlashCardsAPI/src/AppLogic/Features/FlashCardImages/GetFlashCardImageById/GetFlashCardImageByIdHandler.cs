using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCardImages.GetFlashCardImageById;

public class GetFlashCardImageByIdHandler : IRequestHandler<GetFlashCardImageByIdRequest, OneOf<GetFlashCardImageResponse, FlashCardImageNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetFlashCardImageByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetFlashCardImageResponse, FlashCardImageNotFound>> Handle(GetFlashCardImageByIdRequest request, CancellationToken cancellationToken)
    {
        //var FlashCardImage = await _context.FlashCardImages.FirstOrDefaultAsync(x => x.FlashCardImageId == request.id,
          //  cancellationToken: cancellationToken);s
        var FlashCardImage = await _context.FlashCardImage.FirstOrDefaultAsync(x => x.FlashCardId == request.FlashCardId
);

        if (FlashCardImage is null) return new FlashCardImageNotFound();
        return _mapper.Map<GetFlashCardImageResponse>(FlashCardImage);
    }
}
