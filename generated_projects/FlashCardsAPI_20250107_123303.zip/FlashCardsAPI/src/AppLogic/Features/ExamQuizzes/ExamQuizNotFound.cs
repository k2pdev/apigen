using AppLogic.Common.Responses;

namespace AppLogic.Features.ExamQuizzes;

public record ExamQuizNotFound : NotFound {}