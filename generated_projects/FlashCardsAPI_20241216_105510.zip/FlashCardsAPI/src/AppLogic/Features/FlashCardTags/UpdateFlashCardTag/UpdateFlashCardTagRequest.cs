using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.FlashCardTags.UpdateFlashCardTag;

public record UpdateFlashCardTagRequest : IRequest<OneOf<GetFlashCardTagResponse, FlashCardTagNotFound>>
{
    public Int32? FlashCardId {get; set;}
    public Int32? TagId {get; set;}
}   