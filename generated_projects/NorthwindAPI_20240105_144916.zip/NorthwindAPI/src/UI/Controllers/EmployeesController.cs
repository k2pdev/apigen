using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Employees.GetAllEmployees;
using AppLogic.Features.Employees.GetEmployeesById;
using AppLogic.Features.Employees.CreateEmployees;
using AppLogic.Features.Employees.UpdateEmployees;
using AppLogic.Features.Employees.DeleteEmployees;
using AppLogic.Features.Employees;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class EmployeesController : ControllerBase
{
  private readonly IMediator _mediator;
  public EmployeesController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllEmployees")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetEmployeesResponse>>> GetAllEmployees([FromQuery] GetAllEmployeesRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetEmployeesById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetEmployeesById(Int32? _EmployeeID)
  {
    var result = await _mediator.Send(new GetEmployeesByIdRequest(_EmployeeID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateEmployees")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetEmployeesResponse> CreateEmployees([FromBody] CreateEmployeesRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateEmployees")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateEmployees(Int32? _EmployeeID, [FromBody] UpdateEmployeesRequest req)
  {
      var result = await _mediator.Send(req with {EmployeeID = _EmployeeID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteEmployees")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteEmployees(Int32? _EmployeeID)
  {
      var result = await _mediator.Send(new DeleteEmployeesRequest( _EmployeeID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}