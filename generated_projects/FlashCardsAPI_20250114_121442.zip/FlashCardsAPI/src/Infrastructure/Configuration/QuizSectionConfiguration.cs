using Domain.Entities;
using Domain.Entities.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configuration;

public class QuizSectionConfiguration : IEntityTypeConfiguration<QuizSection>
{
    public void Configure(EntityTypeBuilder<QuizSection> builder)
    {
        builder.HasKey(x => x.QuizSectionId);
        builder.Property(x => x.QuizSectionId);

    }
}