
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(ShipperID))]
  public partial class Shippers
  {
    public Int32? ShipperID {get; set;}
    public String? CompanyName {get; set;} = null!;
    public String? Phone {get; set;} = null!;
  }


