using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCardTags.GetAllFlashCardTags;

public class GetAllFlashCardTagsHandler : IRequestHandler<GetAllFlashCardTagsRequest, PaginatedList<GetFlashCardTagResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllFlashCardTagsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetFlashCardTagResponse>> Handle(GetAllFlashCardTagsRequest request, CancellationToken cancellationToken)
    {
        var FlashCardTag = _context.FlashCardTag;
        return await _mapper.ProjectTo<GetFlashCardTagResponse>(FlashCardTag)
            .OrderBy(x => x.TagId) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    