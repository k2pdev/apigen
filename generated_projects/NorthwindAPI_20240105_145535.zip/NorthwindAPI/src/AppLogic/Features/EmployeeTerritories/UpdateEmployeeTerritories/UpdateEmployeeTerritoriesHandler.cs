using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.EmployeeTerritories.UpdateEmployeeTerritories;

public class UpdateEmployeeTerritoriesHandler : IRequestHandler<UpdateEmployeeTerritoriesRequest, OneOf<GetEmployeeTerritoriesResponse, EmployeeTerritoriesNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateEmployeeTerritoriesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetEmployeeTerritoriesResponse, EmployeeTerritoriesNotFound>> Handle(UpdateEmployeeTerritoriesRequest request,
        CancellationToken cancellationToken)
    {
        var updateEmployeeTerritories = await _context.EmployeeTerritories.FirstOrDefaultAsync(x => x.EmployeeID == request.EmployeeID
 && x.TerritoryID == request.TerritoryID
        , cancellationToken);
        if (updateEmployeeTerritories == null) return new EmployeeTerritoriesNotFound();


updateEmployeeTerritories.EmployeeID = request.EmployeeID;
updateEmployeeTerritories.TerritoryID = request.TerritoryID;


        _context.EmployeeTerritories.Update(updateEmployeeTerritories);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetEmployeeTerritoriesResponse>(updateEmployeeTerritories);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);