using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.Tags.UpdateTag;

public record UpdateTagRequest : IRequest<OneOf<GetTagResponse, TagNotFound>>
{
    public Int32? TagId {get; set;}
    public String? TagName {get; set;} = null!;
}   