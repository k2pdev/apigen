using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.EmployeeTerritories.DeleteEmployeeTerritories;

//public record DeleteEmployeeTerritoriesRequest : IRequest<OneOf<GetEmployeeTerritoriesResponse, EmployeeTerritoriesNotFound>>
//public record DeleteEmployeeTerritoriesRequest : IRequest<OneOf<bool, EmployeeTerritoriesNotFound>>

public record DeleteEmployeeTerritoriesRequest(Int32? EmployeeID,String? TerritoryID) : IRequest<OneOf<bool, EmployeeTerritoriesNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
