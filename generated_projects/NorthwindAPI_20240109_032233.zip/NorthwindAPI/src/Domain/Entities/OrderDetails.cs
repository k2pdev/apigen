
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(OrderID))]
  public partial class OrderDetails
  {
    public Int32? OrderID {get; set;}
    public Int32? ProductID {get; set;}
    public Int32? UnitPrice {get; set;}
    public Int32? Quantity {get; set;}
    public Int32? Discount {get; set;}
  }


