using AppLogic.Common.Responses;

namespace AppLogic.Features.Tags;

public record TagNotFound : NotFound {}