using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Customers.DeleteCustomer;

public class DeleteCustomerHandler : IRequestHandler<DeleteCustomerRequest, OneOf<bool, CustomerNotFound>>
{
    private readonly IContext _context;
    public DeleteCustomerHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, CustomerNotFound>> Handle(DeleteCustomerRequest request, CancellationToken cancellationToken)
    {
        var Customer = await _context.Customer.FirstOrDefaultAsync(x => x.CustomerId == request.CustomerId
);

        if (Customer is null) return new CustomerNotFound();

        _context.Customer.Remove(Customer);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
