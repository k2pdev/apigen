using Domain.Entities.Common;
using System;

namespace AppLogic.Features.ExamQuizzes;

public record GetExamQuizResponse
{
    public Int32? ExamId {get; set;}
    public Int32? QuizId {get; set;}
}



