using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ParkBoundaries.DeleteParkBoundaries;

public class DeleteParkBoundariesHandler : IRequestHandler<DeleteParkBoundariesRequest, OneOf<bool, ParkBoundariesNotFound>>
{
    private readonly IContext _context;
    public DeleteParkBoundariesHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, ParkBoundariesNotFound>> Handle(DeleteParkBoundariesRequest request, CancellationToken cancellationToken)
    {
        var ParkBoundaries = await _context.ParkBoundaries.FirstOrDefaultAsync(x => x.ID == request.ID
);

        if (ParkBoundaries is null) return new ParkBoundariesNotFound();

        _context.ParkBoundaries.Remove(ParkBoundaries);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
