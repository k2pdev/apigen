using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.OrderDetails.GetAllOrderDetails;
using AppLogic.Features.OrderDetails.GetOrderDetailsById;
using AppLogic.Features.OrderDetails.CreateOrderDetails;
using AppLogic.Features.OrderDetails.UpdateOrderDetails;
using AppLogic.Features.OrderDetails.DeleteOrderDetails;
using AppLogic.Features.OrderDetails;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class OrderDetailsController : ControllerBase
{
  private readonly IMediator _mediator;
  public OrderDetailsController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllOrderDetails")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetOrderDetailsResponse>>> GetAllOrderDetails([FromQuery] GetAllOrderDetailsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetOrderDetailsById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetOrderDetailsById(Int32? _OrderID)
  {
    var result = await _mediator.Send(new GetOrderDetailsByIdRequest(_OrderID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateOrderDetails")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetOrderDetailsResponse> CreateOrderDetails([FromBody] CreateOrderDetailsRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateOrderDetails")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateOrderDetails(Int32? _OrderID, [FromBody] UpdateOrderDetailsRequest req)
  {
      var result = await _mediator.Send(req with {OrderID = _OrderID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteOrderDetails")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteOrderDetails(Int32? _OrderID)
  {
      var result = await _mediator.Send(new DeleteOrderDetailsRequest( _OrderID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}