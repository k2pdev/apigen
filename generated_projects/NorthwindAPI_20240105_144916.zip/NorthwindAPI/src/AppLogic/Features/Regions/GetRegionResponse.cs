using Domain.Entities.Common;
using System;

namespace AppLogic.Features.Regions;

public record GetRegionResponse
{
    public Int32? RegionID {get; set;}
    public String? RegionDescription {get; set;} = null!;
}



