using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.EmployeeTerritories.DeleteEmployeeTerritories;

public class DeleteEmployeeTerritoriesHandler : IRequestHandler<DeleteEmployeeTerritoriesRequest, OneOf<bool, EmployeeTerritoriesNotFound>>
{
    private readonly IContext _context;
    public DeleteEmployeeTerritoriesHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, EmployeeTerritoriesNotFound>> Handle(DeleteEmployeeTerritoriesRequest request, CancellationToken cancellationToken)
    {
        var EmployeeTerritories = await _context.EmployeeTerritories.FirstOrDefaultAsync(x => x.EmployeeID == request.EmployeeID
 && x.TerritoryID == request.TerritoryID
);

        if (EmployeeTerritories is null) return new EmployeeTerritoriesNotFound();

        _context.EmployeeTerritories.Remove(EmployeeTerritories);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
