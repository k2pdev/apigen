using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.CustomerCustomerDemos.DeleteCustomerCustomerDemo;

public class DeleteCustomerCustomerDemoHandler : IRequestHandler<DeleteCustomerCustomerDemoRequest, OneOf<bool, CustomerCustomerDemoNotFound>>
{
    private readonly IContext _context;
    public DeleteCustomerCustomerDemoHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, CustomerCustomerDemoNotFound>> Handle(DeleteCustomerCustomerDemoRequest request, CancellationToken cancellationToken)
    {
        var CustomerCustomerDemo = await _context.CustomerCustomerDemo.FirstOrDefaultAsync(x => x.CustomerID == request.CustomerID
 && x.CustomerTypeID == request.CustomerTypeID
);

        if (CustomerCustomerDemo is null) return new CustomerCustomerDemoNotFound();

        _context.CustomerCustomerDemo.Remove(CustomerCustomerDemo);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
