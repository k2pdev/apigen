using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Shippers.DeleteShippers;

public class DeleteShippersHandler : IRequestHandler<DeleteShippersRequest, OneOf<bool, ShippersNotFound>>
{
    private readonly IContext _context;
    public DeleteShippersHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, ShippersNotFound>> Handle(DeleteShippersRequest request, CancellationToken cancellationToken)
    {
        var Shippers = await _context.Shippers.FirstOrDefaultAsync(x => x.ShipperID == request.ShipperID
);

        if (Shippers is null) return new ShippersNotFound();

        _context.Shippers.Remove(Shippers);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
