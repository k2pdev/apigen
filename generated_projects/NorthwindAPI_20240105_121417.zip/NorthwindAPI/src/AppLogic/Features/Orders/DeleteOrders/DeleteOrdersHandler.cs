using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Orders.DeleteOrders;

public class DeleteOrdersHandler : IRequestHandler<DeleteOrdersRequest, OneOf<bool, OrdersNotFound>>
{
    private readonly IContext _context;
    public DeleteOrdersHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, OrdersNotFound>> Handle(DeleteOrdersRequest request, CancellationToken cancellationToken)
    {
        var Orders = await _context.Orders.FirstOrDefaultAsync(x => x.OrderID == request.OrderID
);

        if (Orders is null) return new OrdersNotFound();

        _context.Orders.Remove(Orders);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
