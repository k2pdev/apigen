using AutoMapper;
using AppLogic.Features.Customers;
using AppLogic.Features.Customers.GetAllCustomers;
using AppLogic.Features.Customers.CreateCustomer;
using AppLogic.Features.Customers.UpdateCustomer;
using AppLogic.Features.Stores;
using AppLogic.Features.Stores.GetAllStores;
using AppLogic.Features.Stores.CreateStore;
using AppLogic.Features.Stores.UpdateStore;

using Domain.Auth;
using Domain.Entities;

namespace AppLogic.MappingProfiles;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<Customer, GetCustomerResponse>().ReverseMap();
        CreateMap<CreateCustomerRequest, Customer>();
        CreateMap<UpdateCustomerRequest, Customer>();

        CreateMap<Store, GetStoreResponse>().ReverseMap();
        CreateMap<CreateStoreRequest, Store>();
        CreateMap<UpdateStoreRequest, Store>();


    }
}