using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Items.GetItemById;

public class GetItemByIdHandler : IRequestHandler<GetItemByIdRequest, OneOf<GetItemResponse, ItemNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetItemByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetItemResponse, ItemNotFound>> Handle(GetItemByIdRequest request, CancellationToken cancellationToken)
    {
        //var Item = await _context.Items.FirstOrDefaultAsync(x => x.ItemId == request.id,
          //  cancellationToken: cancellationToken);s
        var Item = await _context.Item.FirstOrDefaultAsync(x => x.ID == request.ID
);

        if (Item is null) return new ItemNotFound();
        return _mapper.Map<GetItemResponse>(Item);
    }
}
