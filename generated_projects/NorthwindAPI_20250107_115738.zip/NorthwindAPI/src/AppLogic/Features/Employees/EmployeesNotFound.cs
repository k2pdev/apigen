using AppLogic.Common.Responses;

namespace AppLogic.Features.Employees;

public record EmployeesNotFound : NotFound {}