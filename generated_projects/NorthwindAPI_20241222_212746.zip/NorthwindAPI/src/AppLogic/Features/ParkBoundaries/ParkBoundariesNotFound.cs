using AppLogic.Common.Responses;

namespace AppLogic.Features.ParkBoundaries;

public record ParkBoundariesNotFound : NotFound {}