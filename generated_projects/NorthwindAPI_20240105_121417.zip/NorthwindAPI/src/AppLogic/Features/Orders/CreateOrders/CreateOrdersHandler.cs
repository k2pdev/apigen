using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Orders.CreateOrders;

public class CreateOrdersHandler : IRequestHandler<CreateOrdersRequest, GetOrdersResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateOrdersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetOrdersResponse?> Handle(CreateOrdersRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.Orders>(request);
        _context.Orders.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetOrdersResponse?>(created);
    }
}