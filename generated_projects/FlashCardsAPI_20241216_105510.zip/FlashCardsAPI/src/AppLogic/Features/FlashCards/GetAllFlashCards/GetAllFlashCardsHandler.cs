using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCards.GetAllFlashCards;

public class GetAllFlashCardsHandler : IRequestHandler<GetAllFlashCardsRequest, PaginatedList<GetFlashCardResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllFlashCardsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetFlashCardResponse>> Handle(GetAllFlashCardsRequest request, CancellationToken cancellationToken)
    {
        var FlashCard = _context.FlashCard;
        return await _mapper.ProjectTo<GetFlashCardResponse>(FlashCard)
            .OrderBy(x => x.Required) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    