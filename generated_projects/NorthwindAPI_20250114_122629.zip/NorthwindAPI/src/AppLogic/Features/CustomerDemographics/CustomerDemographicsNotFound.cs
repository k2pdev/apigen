using AppLogic.Common.Responses;

namespace AppLogic.Features.CustomerDemographics;

public record CustomerDemographicsNotFound : NotFound {}