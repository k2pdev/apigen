using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Items.UpdateItem;

public class UpdateItemHandler : IRequestHandler<UpdateItemRequest, OneOf<GetItemResponse, ItemNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateItemHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetItemResponse, ItemNotFound>> Handle(UpdateItemRequest request,
        CancellationToken cancellationToken)
    {
        var updateItem = await _context.Item.FirstOrDefaultAsync(x => x.ID == request.ID
        , cancellationToken);
        if (updateItem == null) return new ItemNotFound();


updateItem.ID = request.ID;
updateItem.ItemName = request.ItemName;
updateItem.Description = request.Description;
updateItem.DueDttm = request.DueDttm;


        _context.Item.Update(updateItem);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetItemResponse>(updateItem);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);