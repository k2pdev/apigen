﻿using AppLogic.Common;
using AppLogic.Common.Handlers;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Net;
using System.Threading.Tasks;

namespace UI.Common;

public class ValidationErrorResultFilter : IAsyncResultFilter
{
    private readonly ValidationErrorHandler _errorHandler;

    public ValidationErrorResultFilter(INotificationHandler<ValidationError> errorHandler)
    {
        _errorHandler = (ValidationErrorHandler)errorHandler;
    }

    public async Task OnResultExecutionAsync(ResultExecutingContext context, ResultExecutionDelegate next)
    {
        if (_errorHandler.HasErrors)
        {
            var errors = _errorHandler.GetErrors();

            context.HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
            
            await context.HttpContext.Response.WriteAsJsonAsync(errors)
                .ConfigureAwait(false);

            return;
        }

        await next().ConfigureAwait(false);
    }
}