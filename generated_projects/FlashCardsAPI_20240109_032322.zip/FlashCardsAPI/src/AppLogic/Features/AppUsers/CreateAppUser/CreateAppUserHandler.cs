using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.AppUsers.CreateAppUser;

public class CreateAppUserHandler : IRequestHandler<CreateAppUserRequest, GetAppUserResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateAppUserHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetAppUserResponse?> Handle(CreateAppUserRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.AppUser>(request);
        _context.AppUser.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetAppUserResponse?>(created);
    }
}