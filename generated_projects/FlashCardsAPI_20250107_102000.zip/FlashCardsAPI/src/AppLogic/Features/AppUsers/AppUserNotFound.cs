using AppLogic.Common.Responses;

namespace AppLogic.Features.AppUsers;

public record AppUserNotFound : NotFound {}