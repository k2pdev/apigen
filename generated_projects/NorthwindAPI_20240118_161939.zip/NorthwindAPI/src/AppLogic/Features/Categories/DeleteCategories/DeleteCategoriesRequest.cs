using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Categories.DeleteCategories;

//public record DeleteCategoriesRequest : IRequest<OneOf<GetCategoriesResponse, CategoriesNotFound>>
//public record DeleteCategoriesRequest : IRequest<OneOf<bool, CategoriesNotFound>>

public record DeleteCategoriesRequest(Int32? CategoryID) : IRequest<OneOf<bool, CategoriesNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
