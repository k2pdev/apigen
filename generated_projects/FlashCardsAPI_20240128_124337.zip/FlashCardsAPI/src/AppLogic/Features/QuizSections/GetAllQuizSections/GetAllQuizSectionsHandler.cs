using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.QuizSections.GetAllQuizSections;

public class GetAllQuizSectionsHandler : IRequestHandler<GetAllQuizSectionsRequest, PaginatedList<GetQuizSectionResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllQuizSectionsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetQuizSectionResponse>> Handle(GetAllQuizSectionsRequest request, CancellationToken cancellationToken)
    {
        var QuizSection = _context.QuizSection;
        return await _mapper.ProjectTo<GetQuizSectionResponse>(QuizSection)
            .OrderBy(x => x.SectionName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    