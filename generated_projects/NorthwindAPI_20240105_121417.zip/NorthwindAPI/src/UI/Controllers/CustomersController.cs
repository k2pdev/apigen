using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Customers.GetAllCustomers;
using AppLogic.Features.Customers.GetCustomersById;
using AppLogic.Features.Customers.CreateCustomers;
using AppLogic.Features.Customers.UpdateCustomers;
using AppLogic.Features.Customers.DeleteCustomers;
using AppLogic.Features.Customers;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class CustomersController : ControllerBase
{
  private readonly IMediator _mediator;
  public CustomersController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllCustomers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetCustomersResponse>>> GetAllCustomers([FromQuery] GetAllCustomersRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetCustomersById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetCustomersById(String? _CustomerID)
  {
    var result = await _mediator.Send(new GetCustomersByIdRequest(_CustomerID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateCustomers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetCustomersResponse> CreateCustomers([FromBody] CreateCustomersRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateCustomers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateCustomers(String? _CustomerID, [FromBody] UpdateCustomersRequest req)
  {
      var result = await _mediator.Send(req with {CustomerID = _CustomerID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteCustomers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteCustomers(String? _CustomerID)
  {
      var result = await _mediator.Send(new DeleteCustomersRequest( _CustomerID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}