using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Stores.UpdateStore;

public class UpdateStoreHandler : IRequestHandler<UpdateStoreRequest, OneOf<GetStoreResponse, StoreNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateStoreHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetStoreResponse, StoreNotFound>> Handle(UpdateStoreRequest request,
        CancellationToken cancellationToken)
    {
        var updateStore = await _context.Store.FirstOrDefaultAsync(x => x.Id == request.Id
        , cancellationToken);
        if (updateStore == null) return new StoreNotFound();


updateStore.Id = request.Id;
updateStore.Name = request.Name;


        _context.Store.Update(updateStore);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetStoreResponse>(updateStore);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);