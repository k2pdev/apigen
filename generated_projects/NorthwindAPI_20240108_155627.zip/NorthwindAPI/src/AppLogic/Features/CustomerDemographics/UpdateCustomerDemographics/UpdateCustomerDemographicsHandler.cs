using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.CustomerDemographics.UpdateCustomerDemographics;

public class UpdateCustomerDemographicsHandler : IRequestHandler<UpdateCustomerDemographicsRequest, OneOf<GetCustomerDemographicsResponse, CustomerDemographicsNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateCustomerDemographicsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetCustomerDemographicsResponse, CustomerDemographicsNotFound>> Handle(UpdateCustomerDemographicsRequest request,
        CancellationToken cancellationToken)
    {
        var updateCustomerDemographics = await _context.CustomerDemographics.FirstOrDefaultAsync(x => x.CustomerTypeID == request.CustomerTypeID
 && x.CustomerDesc == request.CustomerDesc
        , cancellationToken);
        if (updateCustomerDemographics == null) return new CustomerDemographicsNotFound();


updateCustomerDemographics.CustomerTypeID = request.CustomerTypeID;
updateCustomerDemographics.CustomerDesc = request.CustomerDesc;


        _context.CustomerDemographics.Update(updateCustomerDemographics);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetCustomerDemographicsResponse>(updateCustomerDemographics);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);