using AppLogic.Common;
using Domain.Entities;
using Infrastructure.Configuration;
using EntityFramework.Exceptions.SqlServer;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Context;

public class ApplicationDbContext : DbContext, IContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Categories> Categories => Set<Categories>();
    public DbSet<CustomerCustomerDemo> CustomerCustomerDemo => Set<CustomerCustomerDemo>();
    public DbSet<CustomerDemographics> CustomerDemographics => Set<CustomerDemographics>();
    public DbSet<Customers> Customers => Set<Customers>();
    public DbSet<Employees> Employees => Set<Employees>();
    public DbSet<EmployeeTerritories> EmployeeTerritories => Set<EmployeeTerritories>();
    public DbSet<OrderDetails> OrderDetails => Set<OrderDetails>();
    public DbSet<Orders> Orders => Set<Orders>();
    public DbSet<Products> Products => Set<Products>();
    public DbSet<Region> Region => Set<Region>();
    public DbSet<Shippers> Shippers => Set<Shippers>();
    public DbSet<Suppliers> Suppliers => Set<Suppliers>();
    public DbSet<Territories> Territories => Set<Territories>();


    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);
        optionsBuilder.UseExceptionProcessor();
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
         
    }
}


