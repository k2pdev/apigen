﻿namespace AppLogic;

public interface IAssemblyMarker
{
    
}