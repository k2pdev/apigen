
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(TagId),        nameof(TagName))]
  public partial class Tag
  {
    public Int32? TagId {get; set;}
    public String? TagName {get; set;} = null!;
  }


