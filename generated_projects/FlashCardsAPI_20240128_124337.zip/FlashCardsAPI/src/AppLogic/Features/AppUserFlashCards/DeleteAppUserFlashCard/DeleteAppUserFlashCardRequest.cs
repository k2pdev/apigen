using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.AppUserFlashCards.DeleteAppUserFlashCard;

//public record DeleteAppUserFlashCardRequest : IRequest<OneOf<GetAppUserFlashCardResponse, AppUserFlashCardNotFound>>
//public record DeleteAppUserFlashCardRequest : IRequest<OneOf<bool, AppUserFlashCardNotFound>>

public record DeleteAppUserFlashCardRequest(Int32? AppUserFlashCardId) : IRequest<OneOf<bool, AppUserFlashCardNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
