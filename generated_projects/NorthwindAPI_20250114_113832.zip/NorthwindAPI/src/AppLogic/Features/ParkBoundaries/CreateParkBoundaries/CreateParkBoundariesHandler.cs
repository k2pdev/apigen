using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ParkBoundaries.CreateParkBoundaries;

public class CreateParkBoundariesHandler : IRequestHandler<CreateParkBoundariesRequest, GetParkBoundariesResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateParkBoundariesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetParkBoundariesResponse?> Handle(CreateParkBoundariesRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.ParkBoundaries>(request);
        _context.ParkBoundaries.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetParkBoundariesResponse?>(created);
    }
}