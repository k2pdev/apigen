using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.Territories.UpdateTerritories;

public record UpdateTerritoriesRequest : IRequest<OneOf<GetTerritoriesResponse, TerritoriesNotFound>>
{
    public String? TerritoryID {get; set;} = null!;
    public String? TerritoryDescription {get; set;} = null!;
    public Int32? RegionID {get; set;}
}   