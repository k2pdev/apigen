using Domain.Entities.Common;
using System;

namespace AppLogic.Features.Tags;

public record GetTagResponse
{
    public Int32? TagId {get; set;}
    public String? TagName {get; set;} = null!;
}



