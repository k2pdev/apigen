using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Shippers.GetAllShippers;

public record GetAllShippersRequest : PaginatedRequest, IRequest<PaginatedList<GetShippersResponse>>;