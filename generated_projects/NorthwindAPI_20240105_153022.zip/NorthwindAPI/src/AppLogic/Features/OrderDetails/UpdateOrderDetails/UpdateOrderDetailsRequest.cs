using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.OrderDetails.UpdateOrderDetails;

public record UpdateOrderDetailsRequest : IRequest<OneOf<GetOrderDetailsResponse, OrderDetailsNotFound>>
{
    public Int32? OrderID {get; set;}
    public Int32? ProductID {get; set;}
    public Int32? UnitPrice {get; set;}
    public Int32? Quantity {get; set;}
    public Int32? Discount {get; set;}
}   