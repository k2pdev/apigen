using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.AppUsers.DeleteAppUser;

public class DeleteAppUserHandler : IRequestHandler<DeleteAppUserRequest, OneOf<bool, AppUserNotFound>>
{
    private readonly IContext _context;
    public DeleteAppUserHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, AppUserNotFound>> Handle(DeleteAppUserRequest request, CancellationToken cancellationToken)
    {
        var AppUser = await _context.AppUser.FirstOrDefaultAsync(x => x.AppUserId == request.AppUserId
);

        if (AppUser is null) return new AppUserNotFound();

        _context.AppUser.Remove(AppUser);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
