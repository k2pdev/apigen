using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.CustomerCustomerDemos.UpdateCustomerCustomerDemo;

public class UpdateCustomerCustomerDemoHandler : IRequestHandler<UpdateCustomerCustomerDemoRequest, OneOf<GetCustomerCustomerDemoResponse, CustomerCustomerDemoNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateCustomerCustomerDemoHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetCustomerCustomerDemoResponse, CustomerCustomerDemoNotFound>> Handle(UpdateCustomerCustomerDemoRequest request,
        CancellationToken cancellationToken)
    {
        var updateCustomerCustomerDemo = await _context.CustomerCustomerDemo.FirstOrDefaultAsync(x => x.CustomerID == request.CustomerID
 && x.CustomerTypeID == request.CustomerTypeID
        , cancellationToken);
        if (updateCustomerCustomerDemo == null) return new CustomerCustomerDemoNotFound();


updateCustomerCustomerDemo.CustomerID = request.CustomerID;
updateCustomerCustomerDemo.CustomerTypeID = request.CustomerTypeID;


        _context.CustomerCustomerDemo.Update(updateCustomerCustomerDemo);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetCustomerCustomerDemoResponse>(updateCustomerCustomerDemo);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);