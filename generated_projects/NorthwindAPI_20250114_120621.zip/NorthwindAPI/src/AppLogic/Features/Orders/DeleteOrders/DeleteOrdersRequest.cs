using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Orders.DeleteOrders;

//public record DeleteOrdersRequest : IRequest<OneOf<GetOrdersResponse, OrdersNotFound>>
//public record DeleteOrdersRequest : IRequest<OneOf<bool, OrdersNotFound>>

public record DeleteOrdersRequest(Int32? OrderID) : IRequest<OneOf<bool, OrdersNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
