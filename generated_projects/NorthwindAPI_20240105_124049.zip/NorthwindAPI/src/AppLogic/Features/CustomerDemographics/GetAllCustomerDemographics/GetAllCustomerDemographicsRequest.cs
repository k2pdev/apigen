using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.CustomerDemographics.GetAllCustomerDemographics;

public record GetAllCustomerDemographicsRequest : PaginatedRequest, IRequest<PaginatedList<GetCustomerDemographicsResponse>>;