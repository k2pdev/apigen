using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.OrderDetails.GetAllOrderDetails;

public record GetAllOrderDetailsRequest : PaginatedRequest, IRequest<PaginatedList<GetOrderDetailsResponse>>;