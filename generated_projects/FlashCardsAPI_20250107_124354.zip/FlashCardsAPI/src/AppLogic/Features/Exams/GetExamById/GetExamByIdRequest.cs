using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Exams.GetExamById;

//ublic record GetExamByIdRequest(Int32? id) : IRequest<OneOf<GetExamResponse, ExamNotFound>>;

public record GetExamByIdRequest(Int32? ExamId) : IRequest<OneOf<GetExamResponse, ExamNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;