
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(ID))]
  public partial class Item
  {
    public Int32? ID {get; set;}
    public String? ItemName {get; set;} = null!;
    public String? Description {get; set;}
    public String? DueDttm {get; set;}
  }


