using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Products.CreateProducts;

public record CreateProductsRequest : IRequest<GetProductsResponse>
{
    public String? ProductName {get; set;} = null!;
    public Int32? SupplierID {get; set;}
    public Int32? CategoryID {get; set;}
    public String? QuantityPerUnit {get; set;} = null!;
    public String? UnitPrice {get; set;}
    public String? UnitsInStock {get; set;}
    public String? UnitsOnOrder {get; set;}
    public String? ReorderLevel {get; set;}
    public Boolean? Discontinued {get; set;}
}