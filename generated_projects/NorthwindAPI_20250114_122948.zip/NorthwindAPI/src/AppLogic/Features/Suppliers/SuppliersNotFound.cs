using AppLogic.Common.Responses;

namespace AppLogic.Features.Suppliers;

public record SuppliersNotFound : NotFound {}