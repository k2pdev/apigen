using Domain.Entities.Common;
using System;

namespace AppLogic.Features.EmployeeTerritories;

public record GetEmployeeTerritoriesResponse
{
    public Int32? EmployeeID {get; set;}
    public String? TerritoryID {get; set;} = null!;
}



