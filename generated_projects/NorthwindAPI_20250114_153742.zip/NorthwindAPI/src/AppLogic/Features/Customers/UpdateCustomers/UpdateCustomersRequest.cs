using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.Customers.UpdateCustomers;

public record UpdateCustomersRequest : IRequest<OneOf<GetCustomersResponse, CustomersNotFound>>
{
    public String? CustomerID {get; set;} = null!;
    public String? CompanyName {get; set;} = null!;
    public String? ContactName {get; set;} = null!;
    public String? ContactTitle {get; set;} = null!;
    public String? Address {get; set;} = null!;
    public String? City {get; set;} = null!;
    public String? Region {get; set;} = null!;
    public String? PostalCode {get; set;} = null!;
    public String? Country {get; set;} = null!;
    public String? Phone {get; set;} = null!;
    public String? Fax {get; set;} = null!;
}   