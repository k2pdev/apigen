using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCards.GetFlashCardById;

public class GetFlashCardByIdHandler : IRequestHandler<GetFlashCardByIdRequest, OneOf<GetFlashCardResponse, FlashCardNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetFlashCardByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetFlashCardResponse, FlashCardNotFound>> Handle(GetFlashCardByIdRequest request, CancellationToken cancellationToken)
    {
        //var FlashCard = await _context.FlashCards.FirstOrDefaultAsync(x => x.FlashCardId == request.id,
          //  cancellationToken: cancellationToken);s
        var FlashCard = await _context.FlashCard.FirstOrDefaultAsync(x => x.FlashCardId == request.FlashCardId
);

        if (FlashCard is null) return new FlashCardNotFound();
        return _mapper.Map<GetFlashCardResponse>(FlashCard);
    }
}
