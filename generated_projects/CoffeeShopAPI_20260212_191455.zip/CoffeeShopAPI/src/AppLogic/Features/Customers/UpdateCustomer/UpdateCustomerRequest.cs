using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.Customers.UpdateCustomer;

public record UpdateCustomerRequest : IRequest<OneOf<GetCustomerResponse, CustomerNotFound>>
{
    public Guid? CustomerId {get; set;}
    public String? FirstName {get; set;} = null!;
    public String? LastName {get; set;} = null!;
}   