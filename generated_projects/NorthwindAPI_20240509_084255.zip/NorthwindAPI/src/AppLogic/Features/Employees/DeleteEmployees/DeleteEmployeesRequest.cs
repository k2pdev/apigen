using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Employees.DeleteEmployees;

//public record DeleteEmployeesRequest : IRequest<OneOf<GetEmployeesResponse, EmployeesNotFound>>
//public record DeleteEmployeesRequest : IRequest<OneOf<bool, EmployeesNotFound>>

public record DeleteEmployeesRequest(Int32? EmployeeID) : IRequest<OneOf<bool, EmployeesNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
