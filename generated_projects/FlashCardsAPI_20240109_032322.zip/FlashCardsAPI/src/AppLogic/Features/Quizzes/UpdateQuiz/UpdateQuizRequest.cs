using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.Quizzes.UpdateQuiz;

public record UpdateQuizRequest : IRequest<OneOf<GetQuizResponse, QuizNotFound>>
{
    public Int32? QuizId {get; set;}
    public Int32? ParentQuizId {get; set;}
    public String? QuizName {get; set;} = null!;
}   