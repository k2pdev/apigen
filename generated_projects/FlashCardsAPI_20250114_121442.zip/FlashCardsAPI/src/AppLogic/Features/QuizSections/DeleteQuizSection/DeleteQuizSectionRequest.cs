using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.QuizSections.DeleteQuizSection;

//public record DeleteQuizSectionRequest : IRequest<OneOf<GetQuizSectionResponse, QuizSectionNotFound>>
//public record DeleteQuizSectionRequest : IRequest<OneOf<bool, QuizSectionNotFound>>

public record DeleteQuizSectionRequest(Int32? QuizSectionId) : IRequest<OneOf<bool, QuizSectionNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
