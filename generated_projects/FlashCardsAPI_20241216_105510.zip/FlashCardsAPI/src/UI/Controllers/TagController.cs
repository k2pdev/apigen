using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Tags.GetAllTags;
using AppLogic.Features.Tags.GetTagById;
using AppLogic.Features.Tags.CreateTag;
using AppLogic.Features.Tags.UpdateTag;
using AppLogic.Features.Tags.DeleteTag;
using AppLogic.Features.Tags;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class TagController : ControllerBase
{
  private readonly IMediator _mediator;
  public TagController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllTags")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetTagResponse>>> GetAllTags([FromQuery] GetAllTagsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetTagById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetTagById(Int32? _TagId,String? _TagName)
  {
    var result = await _mediator.Send(new GetTagByIdRequest(_TagId,_TagName));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateTag")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetTagResponse> CreateTag([FromBody] CreateTagRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateTag")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateTag(Int32? _TagId,String? _TagName, [FromBody] UpdateTagRequest req)
  {
      var result = await _mediator.Send(req with {TagId = _TagId,TagName = _TagName});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteTag")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteTag(Int32? _TagId,String? _TagName)
  {
      var result = await _mediator.Send(new DeleteTagRequest( _TagId, _TagName)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}