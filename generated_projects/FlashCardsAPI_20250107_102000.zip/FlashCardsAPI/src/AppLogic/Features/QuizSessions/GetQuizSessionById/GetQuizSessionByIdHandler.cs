using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.QuizSessions.GetQuizSessionById;

public class GetQuizSessionByIdHandler : IRequestHandler<GetQuizSessionByIdRequest, OneOf<GetQuizSessionResponse, QuizSessionNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetQuizSessionByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetQuizSessionResponse, QuizSessionNotFound>> Handle(GetQuizSessionByIdRequest request, CancellationToken cancellationToken)
    {
        //var QuizSession = await _context.QuizSessions.FirstOrDefaultAsync(x => x.QuizSessionId == request.id,
          //  cancellationToken: cancellationToken);s
        var QuizSession = await _context.QuizSession.FirstOrDefaultAsync(x => x.QuizSessionId == request.QuizSessionId
);

        if (QuizSession is null) return new QuizSessionNotFound();
        return _mapper.Map<GetQuizSessionResponse>(QuizSession);
    }
}
