using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Products.GetProductsById;

//ublic record GetProductsByIdRequest(Int32? id) : IRequest<OneOf<GetProductsResponse, ProductsNotFound>>;

public record GetProductsByIdRequest(Int32? ProductID) : IRequest<OneOf<GetProductsResponse, ProductsNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;