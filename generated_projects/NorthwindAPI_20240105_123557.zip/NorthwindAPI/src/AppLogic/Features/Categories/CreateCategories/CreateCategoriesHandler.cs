using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Categories.CreateCategories;

public class CreateCategoriesHandler : IRequestHandler<CreateCategoriesRequest, GetCategoriesResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateCategoriesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetCategoriesResponse?> Handle(CreateCategoriesRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.Categories>(request);
        _context.Categories.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetCategoriesResponse?>(created);
    }
}