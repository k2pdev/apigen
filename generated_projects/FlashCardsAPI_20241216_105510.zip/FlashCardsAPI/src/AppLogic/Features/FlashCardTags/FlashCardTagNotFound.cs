using AppLogic.Common.Responses;

namespace AppLogic.Features.FlashCardTags;

public record FlashCardTagNotFound : NotFound {}