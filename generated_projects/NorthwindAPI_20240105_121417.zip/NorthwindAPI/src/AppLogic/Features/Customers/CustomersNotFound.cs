using AppLogic.Common.Responses;

namespace AppLogic.Features.Customers;

public record CustomersNotFound : NotFound {}