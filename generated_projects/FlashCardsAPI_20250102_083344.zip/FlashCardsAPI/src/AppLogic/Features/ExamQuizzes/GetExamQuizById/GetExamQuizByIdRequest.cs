using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.ExamQuizzes.GetExamQuizById;

//ublic record GetExamQuizByIdRequest(Int32? id) : IRequest<OneOf<GetExamQuizResponse, ExamQuizNotFound>>;

public record GetExamQuizByIdRequest(Int32? ExamId,Int32? QuizId) : IRequest<OneOf<GetExamQuizResponse, ExamQuizNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;