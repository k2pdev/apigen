using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Employees.GetEmployeesById;

public class GetEmployeesByIdHandler : IRequestHandler<GetEmployeesByIdRequest, OneOf<GetEmployeesResponse, EmployeesNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetEmployeesByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetEmployeesResponse, EmployeesNotFound>> Handle(GetEmployeesByIdRequest request, CancellationToken cancellationToken)
    {
        //var Employees = await _context.Employees.FirstOrDefaultAsync(x => x.EmployeesId == request.id,
          //  cancellationToken: cancellationToken);s
        var Employees = await _context.Employees.FirstOrDefaultAsync(x => x.EmployeeID == request.EmployeeID
);

        if (Employees is null) return new EmployeesNotFound();
        return _mapper.Map<GetEmployeesResponse>(Employees);
    }
}
