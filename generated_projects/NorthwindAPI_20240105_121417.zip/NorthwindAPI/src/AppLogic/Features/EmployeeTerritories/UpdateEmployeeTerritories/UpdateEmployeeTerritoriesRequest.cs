using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.EmployeeTerritories.UpdateEmployeeTerritories;

public record UpdateEmployeeTerritoriesRequest : IRequest<OneOf<GetEmployeeTerritoriesResponse, EmployeeTerritoriesNotFound>>
{
    public Int32? EmployeeID {get; set;}
    public String? TerritoryID {get; set;} = null!;
}   