using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.ExamQuizzes.UpdateExamQuiz;

public record UpdateExamQuizRequest : IRequest<OneOf<GetExamQuizResponse, ExamQuizNotFound>>
{
    public Int32? ExamId {get; set;}
    public Int32? QuizId {get; set;}
}   