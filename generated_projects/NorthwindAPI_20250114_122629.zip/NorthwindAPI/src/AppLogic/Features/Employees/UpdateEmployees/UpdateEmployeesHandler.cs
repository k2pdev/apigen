using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Employees.UpdateEmployees;

public class UpdateEmployeesHandler : IRequestHandler<UpdateEmployeesRequest, OneOf<GetEmployeesResponse, EmployeesNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateEmployeesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetEmployeesResponse, EmployeesNotFound>> Handle(UpdateEmployeesRequest request,
        CancellationToken cancellationToken)
    {
        var updateEmployees = await _context.Employees.FirstOrDefaultAsync(x => x.EmployeeID == request.EmployeeID
        , cancellationToken);
        if (updateEmployees == null) return new EmployeesNotFound();


updateEmployees.EmployeeID = request.EmployeeID;
updateEmployees.LastName = request.LastName;
updateEmployees.FirstName = request.FirstName;
updateEmployees.Title = request.Title;
updateEmployees.TitleOfCourtesy = request.TitleOfCourtesy;
updateEmployees.BirthDate = request.BirthDate;
updateEmployees.HireDate = request.HireDate;
updateEmployees.Address = request.Address;
updateEmployees.City = request.City;
updateEmployees.Region = request.Region;
updateEmployees.PostalCode = request.PostalCode;
updateEmployees.Country = request.Country;
updateEmployees.HomePhone = request.HomePhone;
updateEmployees.Extension = request.Extension;
updateEmployees.Photo = request.Photo;
updateEmployees.Notes = request.Notes;
updateEmployees.ReportsTo = request.ReportsTo;
updateEmployees.PhotoPath = request.PhotoPath;


        _context.Employees.Update(updateEmployees);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetEmployeesResponse>(updateEmployees);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);