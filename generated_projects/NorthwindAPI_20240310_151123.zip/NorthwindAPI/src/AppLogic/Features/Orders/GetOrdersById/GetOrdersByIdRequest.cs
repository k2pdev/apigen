using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Orders.GetOrdersById;

//ublic record GetOrdersByIdRequest(Int32? id) : IRequest<OneOf<GetOrdersResponse, OrdersNotFound>>;

public record GetOrdersByIdRequest(Int32? OrderID) : IRequest<OneOf<GetOrdersResponse, OrdersNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;