using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.ParkBoundaries.DeleteParkBoundaries;

//public record DeleteParkBoundariesRequest : IRequest<OneOf<GetParkBoundariesResponse, ParkBoundariesNotFound>>
//public record DeleteParkBoundariesRequest : IRequest<OneOf<bool, ParkBoundariesNotFound>>

public record DeleteParkBoundariesRequest(Int32? ID) : IRequest<OneOf<bool, ParkBoundariesNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
