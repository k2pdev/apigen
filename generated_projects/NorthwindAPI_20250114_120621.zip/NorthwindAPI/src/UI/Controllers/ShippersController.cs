using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Shippers.GetAllShippers;
using AppLogic.Features.Shippers.GetShippersById;
using AppLogic.Features.Shippers.CreateShippers;
using AppLogic.Features.Shippers.UpdateShippers;
using AppLogic.Features.Shippers.DeleteShippers;
using AppLogic.Features.Shippers;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class ShippersController : ControllerBase
{
  private readonly IMediator _mediator;
  public ShippersController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllShippers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetShippersResponse>>> GetAllShippers([FromQuery] GetAllShippersRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetShippersById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetShippersById(Int32? _ShipperID)
  {
    var result = await _mediator.Send(new GetShippersByIdRequest(_ShipperID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateShippers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetShippersResponse> CreateShippers([FromBody] CreateShippersRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateShippers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateShippers(Int32? _ShipperID, [FromBody] UpdateShippersRequest req)
  {
      var result = await _mediator.Send(req with {ShipperID = _ShipperID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteShippers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteShippers(Int32? _ShipperID)
  {
      var result = await _mediator.Send(new DeleteShippersRequest( _ShipperID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}