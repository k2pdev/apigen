using Domain.Entities;
using Domain.Entities.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configuration;

public class FlashCardImageConfiguration : IEntityTypeConfiguration<FlashCardImage>
{
    public void Configure(EntityTypeBuilder<FlashCardImage> builder)
    {
        builder.HasKey(x => x.FlashCardId);
        builder.Property(x => x.FlashCardId);

    }
}