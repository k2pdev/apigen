using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.CustomerDemographics.DeleteCustomerDemographics;

public class DeleteCustomerDemographicsHandler : IRequestHandler<DeleteCustomerDemographicsRequest, OneOf<bool, CustomerDemographicsNotFound>>
{
    private readonly IContext _context;
    public DeleteCustomerDemographicsHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, CustomerDemographicsNotFound>> Handle(DeleteCustomerDemographicsRequest request, CancellationToken cancellationToken)
    {
        var CustomerDemographics = await _context.CustomerDemographics.FirstOrDefaultAsync(x => x.CustomerTypeID == request.CustomerTypeID
 && x.CustomerDesc == request.CustomerDesc
);

        if (CustomerDemographics is null) return new CustomerDemographicsNotFound();

        _context.CustomerDemographics.Remove(CustomerDemographics);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
