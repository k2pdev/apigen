using Domain.Entities.Common;
using System;

namespace AppLogic.Features.FlashCards;

public record GetFlashCardResponse
{
    public Int32? FlashCardId {get; set;}
    public Int32? QuizId {get; set;}
    public String? QuestionContent {get; set;} = null!;
    public String? AnswerContent {get; set;} = null!;
    public Int32? QuizSectionId {get; set;}
}



