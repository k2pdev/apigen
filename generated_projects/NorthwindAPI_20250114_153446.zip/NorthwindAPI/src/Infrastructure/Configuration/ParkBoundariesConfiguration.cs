using Domain.Entities;
using Domain.Entities.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configuration;

public class ParkBoundariesConfiguration : IEntityTypeConfiguration<ParkBoundaries>
{
    public void Configure(EntityTypeBuilder<ParkBoundaries> builder)
    {
        builder.HasKey(x => x.ID);
        builder.Property(x => x.ID);

    }
}