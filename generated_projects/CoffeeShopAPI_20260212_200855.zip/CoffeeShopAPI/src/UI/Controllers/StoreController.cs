using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Stores.GetAllStores;
using AppLogic.Features.Stores.GetStoreById;
using AppLogic.Features.Stores.CreateStore;
using AppLogic.Features.Stores.UpdateStore;
using AppLogic.Features.Stores.DeleteStore;
using AppLogic.Features.Stores;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class StoreController : ControllerBase
{
  private readonly IMediator _mediator;
  public StoreController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllStores")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetStoreResponse>>> GetAllStores([FromQuery] GetAllStoresRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetStoreById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetStoreById(Int32? _Id)
  {
    var result = await _mediator.Send(new GetStoreByIdRequest(_Id));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateStore")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetStoreResponse> CreateStore([FromBody] CreateStoreRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateStore")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateStore(Int32? _Id, [FromBody] UpdateStoreRequest req)
  {
      var result = await _mediator.Send(req with {Id = _Id});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteStore")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteStore(Int32? _Id)
  {
      var result = await _mediator.Send(new DeleteStoreRequest( _Id)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}