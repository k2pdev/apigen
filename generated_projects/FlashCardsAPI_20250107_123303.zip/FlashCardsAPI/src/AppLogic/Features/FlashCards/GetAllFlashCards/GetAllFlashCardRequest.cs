using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.FlashCards.GetAllFlashCards;

public record GetAllFlashCardsRequest : PaginatedRequest, IRequest<PaginatedList<GetFlashCardResponse>>;