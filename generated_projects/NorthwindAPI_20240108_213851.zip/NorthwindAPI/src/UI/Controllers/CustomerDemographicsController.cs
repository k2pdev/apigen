using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.CustomerDemographics.GetAllCustomerDemographics;
using AppLogic.Features.CustomerDemographics.GetCustomerDemographicsById;
using AppLogic.Features.CustomerDemographics.CreateCustomerDemographics;
using AppLogic.Features.CustomerDemographics.UpdateCustomerDemographics;
using AppLogic.Features.CustomerDemographics.DeleteCustomerDemographics;
using AppLogic.Features.CustomerDemographics;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class CustomerDemographicsController : ControllerBase
{
  private readonly IMediator _mediator;
  public CustomerDemographicsController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllCustomerDemographics")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetCustomerDemographicsResponse>>> GetAllCustomerDemographics([FromQuery] GetAllCustomerDemographicsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetCustomerDemographicsById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetCustomerDemographicsById(String? _CustomerTypeID,String? _CustomerDesc)
  {
    var result = await _mediator.Send(new GetCustomerDemographicsByIdRequest(_CustomerTypeID,_CustomerDesc));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateCustomerDemographics")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetCustomerDemographicsResponse> CreateCustomerDemographics([FromBody] CreateCustomerDemographicsRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateCustomerDemographics")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateCustomerDemographics(String? _CustomerTypeID,String? _CustomerDesc, [FromBody] UpdateCustomerDemographicsRequest req)
  {
      var result = await _mediator.Send(req with {CustomerTypeID = _CustomerTypeID,CustomerDesc = _CustomerDesc});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteCustomerDemographics")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteCustomerDemographics(String? _CustomerTypeID,String? _CustomerDesc)
  {
      var result = await _mediator.Send(new DeleteCustomerDemographicsRequest( _CustomerTypeID, _CustomerDesc)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}