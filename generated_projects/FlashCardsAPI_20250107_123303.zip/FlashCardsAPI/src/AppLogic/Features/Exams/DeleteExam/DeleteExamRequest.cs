using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Exams.DeleteExam;

//public record DeleteExamRequest : IRequest<OneOf<GetExamResponse, ExamNotFound>>
//public record DeleteExamRequest : IRequest<OneOf<bool, ExamNotFound>>

public record DeleteExamRequest(Int32? ExamId) : IRequest<OneOf<bool, ExamNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
