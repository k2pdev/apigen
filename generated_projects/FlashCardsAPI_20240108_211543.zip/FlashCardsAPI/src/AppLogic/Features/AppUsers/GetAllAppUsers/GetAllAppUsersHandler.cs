using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.AppUsers.GetAllAppUsers;

public class GetAllAppUsersHandler : IRequestHandler<GetAllAppUsersRequest, PaginatedList<GetAppUserResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllAppUsersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetAppUserResponse>> Handle(GetAllAppUsersRequest request, CancellationToken cancellationToken)
    {
        var AppUser = _context.AppUser;
        return await _mapper.ProjectTo<GetAppUserResponse>(AppUser)
            .OrderBy(x => x.UserName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    