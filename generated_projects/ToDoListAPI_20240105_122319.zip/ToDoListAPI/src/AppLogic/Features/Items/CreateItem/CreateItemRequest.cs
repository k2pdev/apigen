using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Items.CreateItem;

public record CreateItemRequest : IRequest<GetItemResponse>
{
    public String? ItemName {get; set;} = null!;
    public String? Description {get; set;}
    public String? DueDttm {get; set;}
}