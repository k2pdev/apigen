using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Tags.DeleteTag;

//public record DeleteTagRequest : IRequest<OneOf<GetTagResponse, TagNotFound>>
//public record DeleteTagRequest : IRequest<OneOf<bool, TagNotFound>>

public record DeleteTagRequest(Int32? TagId,String? TagName) : IRequest<OneOf<bool, TagNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
