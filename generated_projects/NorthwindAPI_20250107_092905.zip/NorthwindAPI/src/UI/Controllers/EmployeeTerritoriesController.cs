using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.EmployeeTerritories.GetAllEmployeeTerritories;
using AppLogic.Features.EmployeeTerritories.GetEmployeeTerritoriesById;
using AppLogic.Features.EmployeeTerritories.CreateEmployeeTerritories;
using AppLogic.Features.EmployeeTerritories.UpdateEmployeeTerritories;
using AppLogic.Features.EmployeeTerritories.DeleteEmployeeTerritories;
using AppLogic.Features.EmployeeTerritories;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class EmployeeTerritoriesController : ControllerBase
{
  private readonly IMediator _mediator;
  public EmployeeTerritoriesController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllEmployeeTerritories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetEmployeeTerritoriesResponse>>> GetAllEmployeeTerritories([FromQuery] GetAllEmployeeTerritoriesRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetEmployeeTerritoriesById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetEmployeeTerritoriesById(Int32? _EmployeeID,String? _TerritoryID)
  {
    var result = await _mediator.Send(new GetEmployeeTerritoriesByIdRequest(_EmployeeID,_TerritoryID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateEmployeeTerritories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetEmployeeTerritoriesResponse> CreateEmployeeTerritories([FromBody] CreateEmployeeTerritoriesRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateEmployeeTerritories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateEmployeeTerritories(Int32? _EmployeeID,String? _TerritoryID, [FromBody] UpdateEmployeeTerritoriesRequest req)
  {
      var result = await _mediator.Send(req with {EmployeeID = _EmployeeID,TerritoryID = _TerritoryID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteEmployeeTerritories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteEmployeeTerritories(Int32? _EmployeeID,String? _TerritoryID)
  {
      var result = await _mediator.Send(new DeleteEmployeeTerritoriesRequest( _EmployeeID, _TerritoryID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}