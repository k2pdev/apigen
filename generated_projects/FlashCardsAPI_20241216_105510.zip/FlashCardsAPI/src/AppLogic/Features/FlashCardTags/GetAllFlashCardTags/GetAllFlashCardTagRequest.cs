using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.FlashCardTags.GetAllFlashCardTags;

public record GetAllFlashCardTagsRequest : PaginatedRequest, IRequest<PaginatedList<GetFlashCardTagResponse>>;