using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.AppUsers.UpdateAppUser;

public record UpdateAppUserRequest : IRequest<OneOf<GetAppUserResponse, AppUserNotFound>>
{
    public Int32? AppUserId {get; set;}
    public String? UserName {get; set;} = null!;
    public String? FirstName {get; set;} = null!;
    public String? LastName {get; set;} = null!;
    public String? Email {get; set;} = null!;
}   