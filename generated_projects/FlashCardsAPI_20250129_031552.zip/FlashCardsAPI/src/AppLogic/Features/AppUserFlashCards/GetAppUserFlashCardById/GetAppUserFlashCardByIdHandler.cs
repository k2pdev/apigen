using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.AppUserFlashCards.GetAppUserFlashCardById;

public class GetAppUserFlashCardByIdHandler : IRequestHandler<GetAppUserFlashCardByIdRequest, OneOf<GetAppUserFlashCardResponse, AppUserFlashCardNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetAppUserFlashCardByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetAppUserFlashCardResponse, AppUserFlashCardNotFound>> Handle(GetAppUserFlashCardByIdRequest request, CancellationToken cancellationToken)
    {
        //var AppUserFlashCard = await _context.AppUserFlashCards.FirstOrDefaultAsync(x => x.AppUserFlashCardId == request.id,
          //  cancellationToken: cancellationToken);s
        var AppUserFlashCard = await _context.AppUserFlashCard.FirstOrDefaultAsync(x => x.AppUserFlashCardId == request.AppUserFlashCardId
);

        if (AppUserFlashCard is null) return new AppUserFlashCardNotFound();
        return _mapper.Map<GetAppUserFlashCardResponse>(AppUserFlashCard);
    }
}
