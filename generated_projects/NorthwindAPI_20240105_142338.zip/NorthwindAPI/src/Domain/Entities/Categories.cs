
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(CategoryID))]
  public partial class Categories
  {
    public Int32? CategoryID {get; set;}
    public String? CategoryName {get; set;} = null!;
    public String? Description {get; set;}
    public System.Byte[]? Picture {get; set;} = null!;
  }


