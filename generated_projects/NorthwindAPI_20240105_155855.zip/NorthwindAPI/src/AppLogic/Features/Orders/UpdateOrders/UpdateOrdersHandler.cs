using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Orders.UpdateOrders;

public class UpdateOrdersHandler : IRequestHandler<UpdateOrdersRequest, OneOf<GetOrdersResponse, OrdersNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateOrdersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetOrdersResponse, OrdersNotFound>> Handle(UpdateOrdersRequest request,
        CancellationToken cancellationToken)
    {
        var updateOrders = await _context.Orders.FirstOrDefaultAsync(x => x.OrderID == request.OrderID
        , cancellationToken);
        if (updateOrders == null) return new OrdersNotFound();


updateOrders.OrderID = request.OrderID;
updateOrders.CustomerID = request.CustomerID;
updateOrders.EmployeeID = request.EmployeeID;
updateOrders.OrderDate = request.OrderDate;
updateOrders.RequiredDate = request.RequiredDate;
updateOrders.ShippedDate = request.ShippedDate;
updateOrders.ShipVia = request.ShipVia;
updateOrders.Freight = request.Freight;
updateOrders.ShipName = request.ShipName;
updateOrders.ShipAddress = request.ShipAddress;
updateOrders.ShipCity = request.ShipCity;
updateOrders.ShipRegion = request.ShipRegion;
updateOrders.ShipPostalCode = request.ShipPostalCode;
updateOrders.ShipCountry = request.ShipCountry;


        _context.Orders.Update(updateOrders);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetOrdersResponse>(updateOrders);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);