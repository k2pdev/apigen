using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.ExamQuizzes.DeleteExamQuiz;

//public record DeleteExamQuizRequest : IRequest<OneOf<GetExamQuizResponse, ExamQuizNotFound>>
//public record DeleteExamQuizRequest : IRequest<OneOf<bool, ExamQuizNotFound>>

public record DeleteExamQuizRequest(Int32? ExamId,Int32? QuizId) : IRequest<OneOf<bool, ExamQuizNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
