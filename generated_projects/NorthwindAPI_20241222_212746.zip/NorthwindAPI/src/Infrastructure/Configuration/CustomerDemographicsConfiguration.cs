using Domain.Entities;
using Domain.Entities.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configuration;

public class CustomerDemographicsConfiguration : IEntityTypeConfiguration<CustomerDemographics>
{
    public void Configure(EntityTypeBuilder<CustomerDemographics> builder)
    {

    }
}