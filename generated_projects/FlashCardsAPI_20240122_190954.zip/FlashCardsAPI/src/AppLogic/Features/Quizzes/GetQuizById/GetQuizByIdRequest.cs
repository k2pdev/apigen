using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Quizzes.GetQuizById;

//ublic record GetQuizByIdRequest(Int32? id) : IRequest<OneOf<GetQuizResponse, QuizNotFound>>;

public record GetQuizByIdRequest(Int32? QuizId) : IRequest<OneOf<GetQuizResponse, QuizNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;