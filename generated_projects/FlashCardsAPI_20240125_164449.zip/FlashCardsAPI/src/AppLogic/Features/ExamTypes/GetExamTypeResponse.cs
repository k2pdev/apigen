using Domain.Entities.Common;
using System;

namespace AppLogic.Features.ExamTypes;

public record GetExamTypeResponse
{
    public Int32? ExamTypeId {get; set;}
    public String? ExamTypeName {get; set;} = null!;
}



