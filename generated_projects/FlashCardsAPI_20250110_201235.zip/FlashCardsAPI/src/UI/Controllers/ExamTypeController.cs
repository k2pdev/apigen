using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.ExamTypes.GetAllExamTypes;
using AppLogic.Features.ExamTypes.GetExamTypeById;
using AppLogic.Features.ExamTypes.CreateExamType;
using AppLogic.Features.ExamTypes.UpdateExamType;
using AppLogic.Features.ExamTypes.DeleteExamType;
using AppLogic.Features.ExamTypes;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class ExamTypeController : ControllerBase
{
  private readonly IMediator _mediator;
  public ExamTypeController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllExamTypes")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetExamTypeResponse>>> GetAllExamTypes([FromQuery] GetAllExamTypesRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetExamTypeById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetExamTypeById(Int32? _ExamTypeId)
  {
    var result = await _mediator.Send(new GetExamTypeByIdRequest(_ExamTypeId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateExamType")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetExamTypeResponse> CreateExamType([FromBody] CreateExamTypeRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateExamType")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateExamType(Int32? _ExamTypeId, [FromBody] UpdateExamTypeRequest req)
  {
      var result = await _mediator.Send(req with {ExamTypeId = _ExamTypeId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteExamType")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteExamType(Int32? _ExamTypeId)
  {
      var result = await _mediator.Send(new DeleteExamTypeRequest( _ExamTypeId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}