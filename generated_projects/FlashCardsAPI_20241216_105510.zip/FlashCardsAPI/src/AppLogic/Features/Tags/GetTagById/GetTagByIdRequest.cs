using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Tags.GetTagById;

//ublic record GetTagByIdRequest(Int32? id) : IRequest<OneOf<GetTagResponse, TagNotFound>>;

public record GetTagByIdRequest(Int32? TagId,String? TagName) : IRequest<OneOf<GetTagResponse, TagNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;