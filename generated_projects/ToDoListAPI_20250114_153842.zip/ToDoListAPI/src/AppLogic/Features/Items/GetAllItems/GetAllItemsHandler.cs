using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Items.GetAllItems;

public class GetAllItemsHandler : IRequestHandler<GetAllItemsRequest, PaginatedList<GetItemResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllItemsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetItemResponse>> Handle(GetAllItemsRequest request, CancellationToken cancellationToken)
    {
        var Item = _context.Item;
        return await _mapper.ProjectTo<GetItemResponse>(Item)
            .OrderBy(x => x.ItemName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    