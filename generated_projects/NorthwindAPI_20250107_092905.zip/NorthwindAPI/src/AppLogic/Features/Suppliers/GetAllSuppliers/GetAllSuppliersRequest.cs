using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Suppliers.GetAllSuppliers;

public record GetAllSuppliersRequest : PaginatedRequest, IRequest<PaginatedList<GetSuppliersResponse>>;