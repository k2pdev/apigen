using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ExamQuizzes.GetAllExamQuizzes;

public class GetAllExamQuizzesHandler : IRequestHandler<GetAllExamQuizzesRequest, PaginatedList<GetExamQuizResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllExamQuizzesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetExamQuizResponse>> Handle(GetAllExamQuizzesRequest request, CancellationToken cancellationToken)
    {
        var ExamQuiz = _context.ExamQuiz;
        return await _mapper.ProjectTo<GetExamQuizResponse>(ExamQuiz)
            .OrderBy(x => x.QuizId) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    