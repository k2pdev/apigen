using Domain.Entities.Common;
using System;

namespace AppLogic.Features.Orders;

public record GetOrdersResponse
{
    public Int32? OrderID {get; set;}
    public String? CustomerID {get; set;} = null!;
    public Int32? EmployeeID {get; set;}
    public Int32? OrderDate {get; set;}
    public Int32? RequiredDate {get; set;}
    public Int32? ShippedDate {get; set;}
    public Int32? ShipVia {get; set;}
    public Int32? Freight {get; set;}
    public String? ShipName {get; set;} = null!;
    public String? ShipAddress {get; set;} = null!;
    public String? ShipCity {get; set;} = null!;
    public String? ShipRegion {get; set;} = null!;
    public String? ShipPostalCode {get; set;} = null!;
    public String? ShipCountry {get; set;} = null!;
}



