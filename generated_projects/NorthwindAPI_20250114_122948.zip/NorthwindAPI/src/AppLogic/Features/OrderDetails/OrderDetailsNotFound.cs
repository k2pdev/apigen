using AppLogic.Common.Responses;

namespace AppLogic.Features.OrderDetails;

public record OrderDetailsNotFound : NotFound {}