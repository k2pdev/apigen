using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ExamTypes.CreateExamType;

public class CreateExamTypeHandler : IRequestHandler<CreateExamTypeRequest, GetExamTypeResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateExamTypeHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetExamTypeResponse?> Handle(CreateExamTypeRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.ExamType>(request);
        _context.ExamType.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetExamTypeResponse?>(created);
    }
}