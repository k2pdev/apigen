using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.ExamQuizzes.UpdateExamQuiz;

public class UpdateExamQuizHandler : IRequestHandler<UpdateExamQuizRequest, OneOf<GetExamQuizResponse, ExamQuizNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateExamQuizHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetExamQuizResponse, ExamQuizNotFound>> Handle(UpdateExamQuizRequest request,
        CancellationToken cancellationToken)
    {
        var updateExamQuiz = await _context.ExamQuiz.FirstOrDefaultAsync(x => x.ExamId == request.ExamId
 && x.QuizId == request.QuizId
        , cancellationToken);
        if (updateExamQuiz == null) return new ExamQuizNotFound();


updateExamQuiz.ExamId = request.ExamId;
updateExamQuiz.QuizId = request.QuizId;


        _context.ExamQuiz.Update(updateExamQuiz);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetExamQuizResponse>(updateExamQuiz);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);