using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Territories.DeleteTerritories;

//public record DeleteTerritoriesRequest : IRequest<OneOf<GetTerritoriesResponse, TerritoriesNotFound>>
//public record DeleteTerritoriesRequest : IRequest<OneOf<bool, TerritoriesNotFound>>

public record DeleteTerritoriesRequest(String? TerritoryID,String? TerritoryDescription,Int32? RegionID) : IRequest<OneOf<bool, TerritoriesNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
