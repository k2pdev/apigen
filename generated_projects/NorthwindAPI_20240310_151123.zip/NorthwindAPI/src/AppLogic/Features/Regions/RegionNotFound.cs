using AppLogic.Common.Responses;

namespace AppLogic.Features.Regions;

public record RegionNotFound : NotFound {}