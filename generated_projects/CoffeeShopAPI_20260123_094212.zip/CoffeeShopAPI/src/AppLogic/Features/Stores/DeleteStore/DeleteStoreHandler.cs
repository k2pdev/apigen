using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Stores.DeleteStore;

public class DeleteStoreHandler : IRequestHandler<DeleteStoreRequest, OneOf<bool, StoreNotFound>>
{
    private readonly IContext _context;
    public DeleteStoreHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, StoreNotFound>> Handle(DeleteStoreRequest request, CancellationToken cancellationToken)
    {
        var Store = await _context.Store.FirstOrDefaultAsync(x => x.Id == request.Id
);

        if (Store is null) return new StoreNotFound();

        _context.Store.Remove(Store);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
