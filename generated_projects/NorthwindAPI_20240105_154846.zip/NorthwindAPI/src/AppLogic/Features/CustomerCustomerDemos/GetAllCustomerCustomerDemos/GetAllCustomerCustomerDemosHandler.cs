using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.CustomerCustomerDemos.GetAllCustomerCustomerDemos;

public class GetAllCustomerCustomerDemosHandler : IRequestHandler<GetAllCustomerCustomerDemosRequest, PaginatedList<GetCustomerCustomerDemoResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllCustomerCustomerDemosHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetCustomerCustomerDemoResponse>> Handle(GetAllCustomerCustomerDemosRequest request, CancellationToken cancellationToken)
    {
        var CustomerCustomerDemo = _context.CustomerCustomerDemo;
        return await _mapper.ProjectTo<GetCustomerCustomerDemoResponse>(CustomerCustomerDemo)
            .OrderBy(x => x.CustomerTypeID) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    