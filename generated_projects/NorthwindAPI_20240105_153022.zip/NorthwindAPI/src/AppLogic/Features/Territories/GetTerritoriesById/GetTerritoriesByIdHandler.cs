using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Territories.GetTerritoriesById;

public class GetTerritoriesByIdHandler : IRequestHandler<GetTerritoriesByIdRequest, OneOf<GetTerritoriesResponse, TerritoriesNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetTerritoriesByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetTerritoriesResponse, TerritoriesNotFound>> Handle(GetTerritoriesByIdRequest request, CancellationToken cancellationToken)
    {
        //var Territories = await _context.Territories.FirstOrDefaultAsync(x => x.TerritoriesId == request.id,
          //  cancellationToken: cancellationToken);s
        var Territories = await _context.Territories.FirstOrDefaultAsync(x => x.TerritoryID == request.TerritoryID
 && x.TerritoryDescription == request.TerritoryDescription
 && x.RegionID == request.RegionID
);

        if (Territories is null) return new TerritoriesNotFound();
        return _mapper.Map<GetTerritoriesResponse>(Territories);
    }
}
