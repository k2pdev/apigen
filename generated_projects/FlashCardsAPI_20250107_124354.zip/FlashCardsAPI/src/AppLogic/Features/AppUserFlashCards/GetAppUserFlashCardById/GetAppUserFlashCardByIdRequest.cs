using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.AppUserFlashCards.GetAppUserFlashCardById;

//ublic record GetAppUserFlashCardByIdRequest(Int32? id) : IRequest<OneOf<GetAppUserFlashCardResponse, AppUserFlashCardNotFound>>;

public record GetAppUserFlashCardByIdRequest(Int32? AppUserFlashCardId) : IRequest<OneOf<GetAppUserFlashCardResponse, AppUserFlashCardNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;