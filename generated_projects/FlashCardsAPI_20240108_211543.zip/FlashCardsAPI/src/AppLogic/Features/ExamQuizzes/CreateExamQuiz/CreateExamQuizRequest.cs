using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.ExamQuizzes.CreateExamQuiz;

public record CreateExamQuizRequest : IRequest<GetExamQuizResponse>
{
    public Int32? ExamId {get; set;}
    public Int32? QuizId {get; set;}
}