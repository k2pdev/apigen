
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(Id))]
  public partial class Store
  {
    public Int32? Id {get; set;}
    public String? Name {get; set;} = null!;
  }


