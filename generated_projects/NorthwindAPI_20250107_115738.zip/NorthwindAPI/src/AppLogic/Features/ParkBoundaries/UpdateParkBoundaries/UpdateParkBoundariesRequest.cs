using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.ParkBoundaries.UpdateParkBoundaries;

public record UpdateParkBoundariesRequest : IRequest<OneOf<GetParkBoundariesResponse, ParkBoundariesNotFound>>
{
    public Int32? ID {get; set;}
    public String? Name {get; set;} = null!;
    public String? BoundaryType {get; set;} = null!;
    public String? geom {get; set;}
}   