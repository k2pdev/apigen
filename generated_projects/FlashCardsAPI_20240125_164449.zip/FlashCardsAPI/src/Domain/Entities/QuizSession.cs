
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(QuizSessionId))]
  public partial class QuizSession
  {
    public Int32? QuizSessionId {get; set;}
    public Int32? QuizId {get; set;}
    public Int32? AppUserId {get; set;}
  }


