using Domain.Entities.Common;
using System;

namespace AppLogic.Features.AppUserFlashCards;

public record GetAppUserFlashCardResponse
{
    public Int32? AppUserFlashCardId {get; set;}
    public Int32? AppUserId {get; set;}
    public Int32? FlashCardId {get; set;}
    public Int32? Score {get; set;}
    public String? Comment {get; set;} = null!;
}



