using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Shippers.GetShippersById;

public class GetShippersByIdHandler : IRequestHandler<GetShippersByIdRequest, OneOf<GetShippersResponse, ShippersNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetShippersByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetShippersResponse, ShippersNotFound>> Handle(GetShippersByIdRequest request, CancellationToken cancellationToken)
    {
        //var Shippers = await _context.Shippers.FirstOrDefaultAsync(x => x.ShippersId == request.id,
          //  cancellationToken: cancellationToken);s
        var Shippers = await _context.Shippers.FirstOrDefaultAsync(x => x.ShipperID == request.ShipperID
);

        if (Shippers is null) return new ShippersNotFound();
        return _mapper.Map<GetShippersResponse>(Shippers);
    }
}
