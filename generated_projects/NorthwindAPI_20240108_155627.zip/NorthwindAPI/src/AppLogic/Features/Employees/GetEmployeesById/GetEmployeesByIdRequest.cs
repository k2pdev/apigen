using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Employees.GetEmployeesById;

//ublic record GetEmployeesByIdRequest(Int32? id) : IRequest<OneOf<GetEmployeesResponse, EmployeesNotFound>>;

public record GetEmployeesByIdRequest(Int32? EmployeeID) : IRequest<OneOf<GetEmployeesResponse, EmployeesNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;