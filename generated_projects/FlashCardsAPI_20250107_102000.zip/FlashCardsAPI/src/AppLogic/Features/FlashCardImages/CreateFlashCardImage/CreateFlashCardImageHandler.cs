using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCardImages.CreateFlashCardImage;

public class CreateFlashCardImageHandler : IRequestHandler<CreateFlashCardImageRequest, GetFlashCardImageResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateFlashCardImageHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetFlashCardImageResponse?> Handle(CreateFlashCardImageRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.FlashCardImage>(request);
        _context.FlashCardImage.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetFlashCardImageResponse?>(created);
    }
}