using AutoMapper;
using AppLogic.Features.Items;
using AppLogic.Features.Items.GetAllItems;
using AppLogic.Features.Items.CreateItem;
using AppLogic.Features.Items.UpdateItem;

using Domain.Auth;
using Domain.Entities;

namespace AppLogic.MappingProfiles;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<Item, GetItemResponse>().ReverseMap();
        CreateMap<CreateItemRequest, Item>();
        CreateMap<UpdateItemRequest, Item>();


    }
}