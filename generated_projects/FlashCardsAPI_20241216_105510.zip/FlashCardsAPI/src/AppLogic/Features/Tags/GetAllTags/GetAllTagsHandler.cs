using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Tags.GetAllTags;

public class GetAllTagsHandler : IRequestHandler<GetAllTagsRequest, PaginatedList<GetTagResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllTagsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetTagResponse>> Handle(GetAllTagsRequest request, CancellationToken cancellationToken)
    {
        var Tag = _context.Tag;
        return await _mapper.ProjectTo<GetTagResponse>(Tag)
            .OrderBy(x => x.TagName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    