using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Orders.GetAllOrders;
using AppLogic.Features.Orders.GetOrdersById;
using AppLogic.Features.Orders.CreateOrders;
using AppLogic.Features.Orders.UpdateOrders;
using AppLogic.Features.Orders.DeleteOrders;
using AppLogic.Features.Orders;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class OrdersController : ControllerBase
{
  private readonly IMediator _mediator;
  public OrdersController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllOrders")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetOrdersResponse>>> GetAllOrders([FromQuery] GetAllOrdersRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetOrdersById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetOrdersById(Int32? _OrderID)
  {
    var result = await _mediator.Send(new GetOrdersByIdRequest(_OrderID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateOrders")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetOrdersResponse> CreateOrders([FromBody] CreateOrdersRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateOrders")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateOrders(Int32? _OrderID, [FromBody] UpdateOrdersRequest req)
  {
      var result = await _mediator.Send(req with {OrderID = _OrderID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteOrders")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteOrders(Int32? _OrderID)
  {
      var result = await _mediator.Send(new DeleteOrdersRequest( _OrderID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}