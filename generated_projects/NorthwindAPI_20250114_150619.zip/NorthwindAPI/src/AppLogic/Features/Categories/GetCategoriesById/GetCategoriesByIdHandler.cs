using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Categories.GetCategoriesById;

public class GetCategoriesByIdHandler : IRequestHandler<GetCategoriesByIdRequest, OneOf<GetCategoriesResponse, CategoriesNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetCategoriesByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetCategoriesResponse, CategoriesNotFound>> Handle(GetCategoriesByIdRequest request, CancellationToken cancellationToken)
    {
        //var Categories = await _context.Categories.FirstOrDefaultAsync(x => x.CategoriesId == request.id,
          //  cancellationToken: cancellationToken);s
        var Categories = await _context.Categories.FirstOrDefaultAsync(x => x.CategoryID == request.CategoryID
);

        if (Categories is null) return new CategoriesNotFound();
        return _mapper.Map<GetCategoriesResponse>(Categories);
    }
}
