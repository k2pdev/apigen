using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.ExamQuizzes.GetAllExamQuizzes;
using AppLogic.Features.ExamQuizzes.GetExamQuizById;
using AppLogic.Features.ExamQuizzes.CreateExamQuiz;
using AppLogic.Features.ExamQuizzes.UpdateExamQuiz;
using AppLogic.Features.ExamQuizzes.DeleteExamQuiz;
using AppLogic.Features.ExamQuizzes;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class ExamQuizController : ControllerBase
{
  private readonly IMediator _mediator;
  public ExamQuizController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllExamQuizzes")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetExamQuizResponse>>> GetAllExamQuizzes([FromQuery] GetAllExamQuizzesRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetExamQuizById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetExamQuizById(Int32? _ExamId,Int32? _QuizId)
  {
    var result = await _mediator.Send(new GetExamQuizByIdRequest(_ExamId,_QuizId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateExamQuiz")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetExamQuizResponse> CreateExamQuiz([FromBody] CreateExamQuizRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateExamQuiz")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateExamQuiz(Int32? _ExamId,Int32? _QuizId, [FromBody] UpdateExamQuizRequest req)
  {
      var result = await _mediator.Send(req with {ExamId = _ExamId,QuizId = _QuizId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteExamQuiz")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteExamQuiz(Int32? _ExamId,Int32? _QuizId)
  {
      var result = await _mediator.Send(new DeleteExamQuizRequest( _ExamId, _QuizId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}