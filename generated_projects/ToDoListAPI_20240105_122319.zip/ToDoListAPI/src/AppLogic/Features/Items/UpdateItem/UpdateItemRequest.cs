using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.Items.UpdateItem;

public record UpdateItemRequest : IRequest<OneOf<GetItemResponse, ItemNotFound>>
{
    public Int32? ID {get; set;}
    public String? ItemName {get; set;} = null!;
    public String? Description {get; set;}
    public String? DueDttm {get; set;}
}   