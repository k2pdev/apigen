using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.ExamTypes.UpdateExamType;

public record UpdateExamTypeRequest : IRequest<OneOf<GetExamTypeResponse, ExamTypeNotFound>>
{
    public Int32? ExamTypeId {get; set;}
    public String? ExamTypeName {get; set;} = null!;
}   