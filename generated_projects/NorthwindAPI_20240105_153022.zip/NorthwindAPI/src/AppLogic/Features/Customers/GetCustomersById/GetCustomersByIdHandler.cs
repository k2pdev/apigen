using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Customers.GetCustomersById;

public class GetCustomersByIdHandler : IRequestHandler<GetCustomersByIdRequest, OneOf<GetCustomersResponse, CustomersNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetCustomersByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetCustomersResponse, CustomersNotFound>> Handle(GetCustomersByIdRequest request, CancellationToken cancellationToken)
    {
        //var Customers = await _context.Customers.FirstOrDefaultAsync(x => x.CustomersId == request.id,
          //  cancellationToken: cancellationToken);s
        var Customers = await _context.Customers.FirstOrDefaultAsync(x => x.CustomerID == request.CustomerID
);

        if (Customers is null) return new CustomersNotFound();
        return _mapper.Map<GetCustomersResponse>(Customers);
    }
}
