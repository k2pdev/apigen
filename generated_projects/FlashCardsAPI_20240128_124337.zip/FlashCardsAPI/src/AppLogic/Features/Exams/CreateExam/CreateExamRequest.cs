using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Exams.CreateExam;

public record CreateExamRequest : IRequest<GetExamResponse>
{
    public Int32? ExamType {get; set;}
    public String? ExamName {get; set;} = null!;
}