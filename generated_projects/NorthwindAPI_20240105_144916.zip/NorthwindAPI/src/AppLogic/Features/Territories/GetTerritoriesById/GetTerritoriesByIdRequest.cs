using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Territories.GetTerritoriesById;

//ublic record GetTerritoriesByIdRequest(Int32? id) : IRequest<OneOf<GetTerritoriesResponse, TerritoriesNotFound>>;

public record GetTerritoriesByIdRequest(String? TerritoryID,String? TerritoryDescription,Int32? RegionID) : IRequest<OneOf<GetTerritoriesResponse, TerritoriesNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;