using Domain.Entities.Common;
using System;

namespace AppLogic.Features.Territories;

public record GetTerritoriesResponse
{
    public String? TerritoryID {get; set;} = null!;
    public String? TerritoryDescription {get; set;} = null!;
    public Int32? RegionID {get; set;}
}



