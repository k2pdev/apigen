using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.CustomerCustomerDemos.DeleteCustomerCustomerDemo;

//public record DeleteCustomerCustomerDemoRequest : IRequest<OneOf<GetCustomerCustomerDemoResponse, CustomerCustomerDemoNotFound>>
//public record DeleteCustomerCustomerDemoRequest : IRequest<OneOf<bool, CustomerCustomerDemoNotFound>>

public record DeleteCustomerCustomerDemoRequest(String? CustomerID,String? CustomerTypeID) : IRequest<OneOf<bool, CustomerCustomerDemoNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
