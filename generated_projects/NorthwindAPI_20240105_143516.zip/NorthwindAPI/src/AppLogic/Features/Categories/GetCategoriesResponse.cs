using Domain.Entities.Common;
using System;

namespace AppLogic.Features.Categories;

public record GetCategoriesResponse
{
    public Int32? CategoryID {get; set;}
    public String? CategoryName {get; set;} = null!;
    public String? Description {get; set;}
    public System.Byte[]? Picture {get; set;} = null!;
}



