
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(ExamId))]
  public partial class Exam
  {
    public Int32? ExamId {get; set;}
    public Int32? ExamType {get; set;}
    public String? ExamName {get; set;} = null!;
  }


