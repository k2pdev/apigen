using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Customers.UpdateCustomers;

public class UpdateCustomersHandler : IRequestHandler<UpdateCustomersRequest, OneOf<GetCustomersResponse, CustomersNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateCustomersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetCustomersResponse, CustomersNotFound>> Handle(UpdateCustomersRequest request,
        CancellationToken cancellationToken)
    {
        var updateCustomers = await _context.Customers.FirstOrDefaultAsync(x => x.CustomerID == request.CustomerID
        , cancellationToken);
        if (updateCustomers == null) return new CustomersNotFound();


updateCustomers.CustomerID = request.CustomerID;
updateCustomers.CompanyName = request.CompanyName;
updateCustomers.ContactName = request.ContactName;
updateCustomers.ContactTitle = request.ContactTitle;
updateCustomers.Address = request.Address;
updateCustomers.City = request.City;
updateCustomers.Region = request.Region;
updateCustomers.PostalCode = request.PostalCode;
updateCustomers.Country = request.Country;
updateCustomers.Phone = request.Phone;
updateCustomers.Fax = request.Fax;


        _context.Customers.Update(updateCustomers);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetCustomersResponse>(updateCustomers);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);