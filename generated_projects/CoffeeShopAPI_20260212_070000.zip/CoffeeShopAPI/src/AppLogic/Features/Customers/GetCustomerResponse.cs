using Domain.Entities.Common;
using System;

namespace AppLogic.Features.Customers;

public record GetCustomerResponse
{
    public Guid? CustomerId {get; set;}
    public String? FirstName {get; set;} = null!;
    public String? LastName {get; set;} = null!;
}



