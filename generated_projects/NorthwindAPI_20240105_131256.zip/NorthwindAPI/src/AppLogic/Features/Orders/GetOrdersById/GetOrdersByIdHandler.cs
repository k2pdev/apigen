using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Orders.GetOrdersById;

public class GetOrdersByIdHandler : IRequestHandler<GetOrdersByIdRequest, OneOf<GetOrdersResponse, OrdersNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetOrdersByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetOrdersResponse, OrdersNotFound>> Handle(GetOrdersByIdRequest request, CancellationToken cancellationToken)
    {
        //var Orders = await _context.Orders.FirstOrDefaultAsync(x => x.OrdersId == request.id,
          //  cancellationToken: cancellationToken);s
        var Orders = await _context.Orders.FirstOrDefaultAsync(x => x.OrderID == request.OrderID
);

        if (Orders is null) return new OrdersNotFound();
        return _mapper.Map<GetOrdersResponse>(Orders);
    }
}
