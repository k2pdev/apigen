using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.QuizSessions.GetAllQuizSessions;

public record GetAllQuizSessionsRequest : PaginatedRequest, IRequest<PaginatedList<GetQuizSessionResponse>>;