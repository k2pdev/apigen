using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Stores.GetStoreById;

public class GetStoreByIdHandler : IRequestHandler<GetStoreByIdRequest, OneOf<GetStoreResponse, StoreNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetStoreByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetStoreResponse, StoreNotFound>> Handle(GetStoreByIdRequest request, CancellationToken cancellationToken)
    {
        //var Store = await _context.Stores.FirstOrDefaultAsync(x => x.StoreId == request.id,
          //  cancellationToken: cancellationToken);s
        var Store = await _context.Store.FirstOrDefaultAsync(x => x.Id == request.Id
);

        if (Store is null) return new StoreNotFound();
        return _mapper.Map<GetStoreResponse>(Store);
    }
}
