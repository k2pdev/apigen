using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.FlashCardImages.GetAllFlashCardImages;

public record GetAllFlashCardImagesRequest : PaginatedRequest, IRequest<PaginatedList<GetFlashCardImageResponse>>;