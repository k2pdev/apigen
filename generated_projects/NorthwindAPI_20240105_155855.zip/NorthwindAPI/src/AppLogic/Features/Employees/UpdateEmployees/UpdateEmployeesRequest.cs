using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.Employees.UpdateEmployees;

public record UpdateEmployeesRequest : IRequest<OneOf<GetEmployeesResponse, EmployeesNotFound>>
{
    public Int32? EmployeeID {get; set;}
    public String? LastName {get; set;} = null!;
    public String? FirstName {get; set;} = null!;
    public String? Title {get; set;} = null!;
    public String? TitleOfCourtesy {get; set;} = null!;
    public String? BirthDate {get; set;}
    public String? HireDate {get; set;}
    public String? Address {get; set;} = null!;
    public String? City {get; set;} = null!;
    public String? Region {get; set;} = null!;
    public String? PostalCode {get; set;} = null!;
    public String? Country {get; set;} = null!;
    public String? HomePhone {get; set;} = null!;
    public String? Extension {get; set;} = null!;
    public System.Byte[]? Photo {get; set;} = null!;
    public System.Byte[]? Notes {get; set;}
    public Int32? ReportsTo {get; set;}
    public String? PhotoPath {get; set;} = null!;
}   