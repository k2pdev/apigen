using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Quizzes.GetAllQuizzes;

public record GetAllQuizzesRequest : PaginatedRequest, IRequest<PaginatedList<GetQuizResponse>>;