using Domain.Entities.Common;
using System;

namespace AppLogic.Features.QuizSessions;

public record GetQuizSessionResponse
{
    public Int32? QuizSessionId {get; set;}
    public Int32? QuizId {get; set;}
    public Int32? AppUserId {get; set;}
}



