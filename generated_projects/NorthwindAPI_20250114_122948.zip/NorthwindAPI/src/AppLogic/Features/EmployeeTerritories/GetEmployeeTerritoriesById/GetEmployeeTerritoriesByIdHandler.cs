using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.EmployeeTerritories.GetEmployeeTerritoriesById;

public class GetEmployeeTerritoriesByIdHandler : IRequestHandler<GetEmployeeTerritoriesByIdRequest, OneOf<GetEmployeeTerritoriesResponse, EmployeeTerritoriesNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetEmployeeTerritoriesByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetEmployeeTerritoriesResponse, EmployeeTerritoriesNotFound>> Handle(GetEmployeeTerritoriesByIdRequest request, CancellationToken cancellationToken)
    {
        //var EmployeeTerritories = await _context.EmployeeTerritories.FirstOrDefaultAsync(x => x.EmployeeTerritoriesId == request.id,
          //  cancellationToken: cancellationToken);s
        var EmployeeTerritories = await _context.EmployeeTerritories.FirstOrDefaultAsync(x => x.EmployeeID == request.EmployeeID
 && x.TerritoryID == request.TerritoryID
);

        if (EmployeeTerritories is null) return new EmployeeTerritoriesNotFound();
        return _mapper.Map<GetEmployeeTerritoriesResponse>(EmployeeTerritories);
    }
}
