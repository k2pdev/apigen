using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Quizzes.CreateQuiz;

public class CreateQuizHandler : IRequestHandler<CreateQuizRequest, GetQuizResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateQuizHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetQuizResponse?> Handle(CreateQuizRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.Quiz>(request);
        _context.Quiz.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetQuizResponse?>(created);
    }
}