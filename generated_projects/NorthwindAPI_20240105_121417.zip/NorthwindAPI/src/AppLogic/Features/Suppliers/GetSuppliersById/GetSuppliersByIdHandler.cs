using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Suppliers.GetSuppliersById;

public class GetSuppliersByIdHandler : IRequestHandler<GetSuppliersByIdRequest, OneOf<GetSuppliersResponse, SuppliersNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetSuppliersByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetSuppliersResponse, SuppliersNotFound>> Handle(GetSuppliersByIdRequest request, CancellationToken cancellationToken)
    {
        //var Suppliers = await _context.Suppliers.FirstOrDefaultAsync(x => x.SuppliersId == request.id,
          //  cancellationToken: cancellationToken);s
        var Suppliers = await _context.Suppliers.FirstOrDefaultAsync(x => x.SupplierID == request.SupplierID
);

        if (Suppliers is null) return new SuppliersNotFound();
        return _mapper.Map<GetSuppliersResponse>(Suppliers);
    }
}
