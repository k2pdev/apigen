using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.ExamQuizzes.GetAllExamQuizzes;

public record GetAllExamQuizzesRequest : PaginatedRequest, IRequest<PaginatedList<GetExamQuizResponse>>;