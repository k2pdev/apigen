using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Territories.CreateTerritories;

public record CreateTerritoriesRequest : IRequest<GetTerritoriesResponse>
{
    public String? TerritoryID {get; set;} = null!;
    public String? TerritoryDescription {get; set;} = null!;
    public Int32? RegionID {get; set;}
}