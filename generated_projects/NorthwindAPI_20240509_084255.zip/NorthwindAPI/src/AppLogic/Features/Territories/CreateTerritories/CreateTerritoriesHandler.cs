using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Territories.CreateTerritories;

public class CreateTerritoriesHandler : IRequestHandler<CreateTerritoriesRequest, GetTerritoriesResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateTerritoriesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetTerritoriesResponse?> Handle(CreateTerritoriesRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.Territories>(request);
        _context.Territories.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetTerritoriesResponse?>(created);
    }
}