using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.FlashCards.CreateFlashCard;

public record CreateFlashCardRequest : IRequest<GetFlashCardResponse>
{
    public Int32? QuizId {get; set;}
    public String? QuestionContent {get; set;} = null!;
    public String? AnswerContent {get; set;} = null!;
}