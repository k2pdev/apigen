using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.EmployeeTerritories.GetAllEmployeeTerritories;

public class GetAllEmployeeTerritoriesHandler : IRequestHandler<GetAllEmployeeTerritoriesRequest, PaginatedList<GetEmployeeTerritoriesResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllEmployeeTerritoriesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetEmployeeTerritoriesResponse>> Handle(GetAllEmployeeTerritoriesRequest request, CancellationToken cancellationToken)
    {
        var EmployeeTerritories = _context.EmployeeTerritories;
        return await _mapper.ProjectTo<GetEmployeeTerritoriesResponse>(EmployeeTerritories)
            .OrderBy(x => x.TerritoryID) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    