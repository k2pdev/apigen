using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.OrderDetails.DeleteOrderDetails;

//public record DeleteOrderDetailsRequest : IRequest<OneOf<GetOrderDetailsResponse, OrderDetailsNotFound>>
//public record DeleteOrderDetailsRequest : IRequest<OneOf<bool, OrderDetailsNotFound>>

public record DeleteOrderDetailsRequest(Int32? OrderID) : IRequest<OneOf<bool, OrderDetailsNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
