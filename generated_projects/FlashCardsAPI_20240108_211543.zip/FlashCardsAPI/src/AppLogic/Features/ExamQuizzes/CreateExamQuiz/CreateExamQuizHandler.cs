using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ExamQuizzes.CreateExamQuiz;

public class CreateExamQuizHandler : IRequestHandler<CreateExamQuizRequest, GetExamQuizResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateExamQuizHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetExamQuizResponse?> Handle(CreateExamQuizRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.ExamQuiz>(request);
        _context.ExamQuiz.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetExamQuizResponse?>(created);
    }
}