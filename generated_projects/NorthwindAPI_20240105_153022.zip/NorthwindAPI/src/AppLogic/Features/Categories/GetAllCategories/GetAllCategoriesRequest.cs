using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Categories.GetAllCategories;

public record GetAllCategoriesRequest : PaginatedRequest, IRequest<PaginatedList<GetCategoriesResponse>>;