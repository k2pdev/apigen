
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(CustomerID),        nameof(CustomerTypeID))]
  public partial class CustomerCustomerDemo
  {
    public String? CustomerID {get; set;} = null!;
    public String? CustomerTypeID {get; set;} = null!;
  }


