using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Products.CreateProducts;

public class CreateProductsHandler : IRequestHandler<CreateProductsRequest, GetProductsResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateProductsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetProductsResponse?> Handle(CreateProductsRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.Products>(request);
        _context.Products.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetProductsResponse?>(created);
    }
}