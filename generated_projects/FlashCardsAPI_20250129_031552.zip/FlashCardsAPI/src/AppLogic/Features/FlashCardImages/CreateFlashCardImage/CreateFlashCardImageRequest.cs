using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.FlashCardImages.CreateFlashCardImage;

public record CreateFlashCardImageRequest : IRequest<GetFlashCardImageResponse>
{
    public Int32? FlashCardId {get; set;}
    public Int32? Image {get; set;}
}