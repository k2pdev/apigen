using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Products.DeleteProducts;

public class DeleteProductsHandler : IRequestHandler<DeleteProductsRequest, OneOf<bool, ProductsNotFound>>
{
    private readonly IContext _context;
    public DeleteProductsHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, ProductsNotFound>> Handle(DeleteProductsRequest request, CancellationToken cancellationToken)
    {
        var Products = await _context.Products.FirstOrDefaultAsync(x => x.ProductID == request.ProductID
);

        if (Products is null) return new ProductsNotFound();

        _context.Products.Remove(Products);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
