using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCardImages.DeleteFlashCardImage;

public class DeleteFlashCardImageHandler : IRequestHandler<DeleteFlashCardImageRequest, OneOf<bool, FlashCardImageNotFound>>
{
    private readonly IContext _context;
    public DeleteFlashCardImageHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, FlashCardImageNotFound>> Handle(DeleteFlashCardImageRequest request, CancellationToken cancellationToken)
    {
        var FlashCardImage = await _context.FlashCardImage.FirstOrDefaultAsync(x => x.FlashCardId == request.FlashCardId
);

        if (FlashCardImage is null) return new FlashCardImageNotFound();

        _context.FlashCardImage.Remove(FlashCardImage);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
