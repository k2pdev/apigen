using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.FlashCardTags.DeleteFlashCardTag;

//public record DeleteFlashCardTagRequest : IRequest<OneOf<GetFlashCardTagResponse, FlashCardTagNotFound>>
//public record DeleteFlashCardTagRequest : IRequest<OneOf<bool, FlashCardTagNotFound>>

public record DeleteFlashCardTagRequest(Int32? FlashCardId,Int32? TagId) : IRequest<OneOf<bool, FlashCardTagNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
