using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCardTags.CreateFlashCardTag;

public class CreateFlashCardTagHandler : IRequestHandler<CreateFlashCardTagRequest, GetFlashCardTagResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateFlashCardTagHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetFlashCardTagResponse?> Handle(CreateFlashCardTagRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.FlashCardTag>(request);
        _context.FlashCardTag.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetFlashCardTagResponse?>(created);
    }
}