using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Regions.GetAllRegions;

public record GetAllRegionsRequest : PaginatedRequest, IRequest<PaginatedList<GetRegionResponse>>;