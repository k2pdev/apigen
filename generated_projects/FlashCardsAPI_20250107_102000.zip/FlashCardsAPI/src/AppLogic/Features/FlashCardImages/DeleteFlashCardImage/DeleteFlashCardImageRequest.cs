using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.FlashCardImages.DeleteFlashCardImage;

//public record DeleteFlashCardImageRequest : IRequest<OneOf<GetFlashCardImageResponse, FlashCardImageNotFound>>
//public record DeleteFlashCardImageRequest : IRequest<OneOf<bool, FlashCardImageNotFound>>

public record DeleteFlashCardImageRequest(Int32? FlashCardId) : IRequest<OneOf<bool, FlashCardImageNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
