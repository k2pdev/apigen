using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Items.CreateItem;

public class CreateItemHandler : IRequestHandler<CreateItemRequest, GetItemResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateItemHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetItemResponse?> Handle(CreateItemRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.Item>(request);
        _context.Item.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetItemResponse?>(created);
    }
}