using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Exams.DeleteExam;

public class DeleteExamHandler : IRequestHandler<DeleteExamRequest, OneOf<bool, ExamNotFound>>
{
    private readonly IContext _context;
    public DeleteExamHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, ExamNotFound>> Handle(DeleteExamRequest request, CancellationToken cancellationToken)
    {
        var Exam = await _context.Exam.FirstOrDefaultAsync(x => x.ExamId == request.ExamId
);

        if (Exam is null) return new ExamNotFound();

        _context.Exam.Remove(Exam);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
