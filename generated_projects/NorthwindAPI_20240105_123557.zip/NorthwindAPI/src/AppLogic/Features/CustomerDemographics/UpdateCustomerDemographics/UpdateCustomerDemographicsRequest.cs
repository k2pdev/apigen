using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.CustomerDemographics.UpdateCustomerDemographics;

public record UpdateCustomerDemographicsRequest : IRequest<OneOf<GetCustomerDemographicsResponse, CustomerDemographicsNotFound>>
{
    public String? CustomerTypeID {get; set;} = null!;
    public String? CustomerDesc {get; set;}
}   