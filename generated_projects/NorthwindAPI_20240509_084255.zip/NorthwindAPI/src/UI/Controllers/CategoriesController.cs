using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Categories.GetAllCategories;
using AppLogic.Features.Categories.GetCategoriesById;
using AppLogic.Features.Categories.CreateCategories;
using AppLogic.Features.Categories.UpdateCategories;
using AppLogic.Features.Categories.DeleteCategories;
using AppLogic.Features.Categories;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class CategoriesController : ControllerBase
{
  private readonly IMediator _mediator;
  public CategoriesController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllCategories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetCategoriesResponse>>> GetAllCategories([FromQuery] GetAllCategoriesRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetCategoriesById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetCategoriesById(Int32? _CategoryID)
  {
    var result = await _mediator.Send(new GetCategoriesByIdRequest(_CategoryID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateCategories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetCategoriesResponse> CreateCategories([FromBody] CreateCategoriesRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateCategories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateCategories(Int32? _CategoryID, [FromBody] UpdateCategoriesRequest req)
  {
      var result = await _mediator.Send(req with {CategoryID = _CategoryID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteCategories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteCategories(Int32? _CategoryID)
  {
      var result = await _mediator.Send(new DeleteCategoriesRequest( _CategoryID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}