using AppLogic.Common.Responses;

namespace AppLogic.Features.Categories;

public record CategoriesNotFound : NotFound {}