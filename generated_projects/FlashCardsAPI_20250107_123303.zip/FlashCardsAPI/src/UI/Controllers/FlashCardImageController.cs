using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.FlashCardImages.GetAllFlashCardImages;
using AppLogic.Features.FlashCardImages.GetFlashCardImageById;
using AppLogic.Features.FlashCardImages.CreateFlashCardImage;
using AppLogic.Features.FlashCardImages.UpdateFlashCardImage;
using AppLogic.Features.FlashCardImages.DeleteFlashCardImage;
using AppLogic.Features.FlashCardImages;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class FlashCardImageController : ControllerBase
{
  private readonly IMediator _mediator;
  public FlashCardImageController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllFlashCardImages")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetFlashCardImageResponse>>> GetAllFlashCardImages([FromQuery] GetAllFlashCardImagesRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetFlashCardImageById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetFlashCardImageById(Int32? _FlashCardId)
  {
    var result = await _mediator.Send(new GetFlashCardImageByIdRequest(_FlashCardId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateFlashCardImage")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetFlashCardImageResponse> CreateFlashCardImage([FromBody] CreateFlashCardImageRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateFlashCardImage")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateFlashCardImage(Int32? _FlashCardId, [FromBody] UpdateFlashCardImageRequest req)
  {
      var result = await _mediator.Send(req with {FlashCardId = _FlashCardId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteFlashCardImage")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteFlashCardImage(Int32? _FlashCardId)
  {
      var result = await _mediator.Send(new DeleteFlashCardImageRequest( _FlashCardId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}