using Domain.Entities;
using Domain.Entities.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configuration;

public class ShippersConfiguration : IEntityTypeConfiguration<Shippers>
{
    public void Configure(EntityTypeBuilder<Shippers> builder)
    {
        builder.HasKey(x => x.ShipperID);
        builder.Property(x => x.ShipperID);

    }
}