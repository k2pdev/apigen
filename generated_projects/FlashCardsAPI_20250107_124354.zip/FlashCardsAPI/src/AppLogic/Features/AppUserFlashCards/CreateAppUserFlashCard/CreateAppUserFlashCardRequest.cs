using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.AppUserFlashCards.CreateAppUserFlashCard;

public record CreateAppUserFlashCardRequest : IRequest<GetAppUserFlashCardResponse>
{
    public Int32? AppUserId {get; set;}
    public Int32? FlashCardId {get; set;}
    public Int32? Score {get; set;}
    public String? Comment {get; set;} = null!;
}