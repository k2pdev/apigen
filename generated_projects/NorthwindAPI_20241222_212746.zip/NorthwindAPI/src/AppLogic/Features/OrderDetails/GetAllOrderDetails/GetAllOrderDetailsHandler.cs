using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.OrderDetails.GetAllOrderDetails;

public class GetAllOrderDetailsHandler : IRequestHandler<GetAllOrderDetailsRequest, PaginatedList<GetOrderDetailsResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllOrderDetailsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetOrderDetailsResponse>> Handle(GetAllOrderDetailsRequest request, CancellationToken cancellationToken)
    {
        var OrderDetails = _context.OrderDetails;
        return await _mapper.ProjectTo<GetOrderDetailsResponse>(OrderDetails)
            .OrderBy(x => x.Discount) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    