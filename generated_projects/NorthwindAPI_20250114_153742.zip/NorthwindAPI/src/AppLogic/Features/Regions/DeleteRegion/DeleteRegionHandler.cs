using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Regions.DeleteRegion;

public class DeleteRegionHandler : IRequestHandler<DeleteRegionRequest, OneOf<bool, RegionNotFound>>
{
    private readonly IContext _context;
    public DeleteRegionHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, RegionNotFound>> Handle(DeleteRegionRequest request, CancellationToken cancellationToken)
    {
        var Region = await _context.Region.FirstOrDefaultAsync(x => x.RegionID == request.RegionID
 && x.RegionDescription == request.RegionDescription
);

        if (Region is null) return new RegionNotFound();

        _context.Region.Remove(Region);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
