using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.QuizSections.GetQuizSectionById;

//ublic record GetQuizSectionByIdRequest(Int32? id) : IRequest<OneOf<GetQuizSectionResponse, QuizSectionNotFound>>;

public record GetQuizSectionByIdRequest(Int32? QuizSectionId) : IRequest<OneOf<GetQuizSectionResponse, QuizSectionNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;