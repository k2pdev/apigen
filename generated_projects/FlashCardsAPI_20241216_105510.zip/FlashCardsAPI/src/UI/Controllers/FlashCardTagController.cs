using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.FlashCardTags.GetAllFlashCardTags;
using AppLogic.Features.FlashCardTags.GetFlashCardTagById;
using AppLogic.Features.FlashCardTags.CreateFlashCardTag;
using AppLogic.Features.FlashCardTags.UpdateFlashCardTag;
using AppLogic.Features.FlashCardTags.DeleteFlashCardTag;
using AppLogic.Features.FlashCardTags;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class FlashCardTagController : ControllerBase
{
  private readonly IMediator _mediator;
  public FlashCardTagController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllFlashCardTags")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetFlashCardTagResponse>>> GetAllFlashCardTags([FromQuery] GetAllFlashCardTagsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetFlashCardTagById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetFlashCardTagById(Int32? _FlashCardId,Int32? _TagId)
  {
    var result = await _mediator.Send(new GetFlashCardTagByIdRequest(_FlashCardId,_TagId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateFlashCardTag")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetFlashCardTagResponse> CreateFlashCardTag([FromBody] CreateFlashCardTagRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateFlashCardTag")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateFlashCardTag(Int32? _FlashCardId,Int32? _TagId, [FromBody] UpdateFlashCardTagRequest req)
  {
      var result = await _mediator.Send(req with {FlashCardId = _FlashCardId,TagId = _TagId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteFlashCardTag")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteFlashCardTag(Int32? _FlashCardId,Int32? _TagId)
  {
      var result = await _mediator.Send(new DeleteFlashCardTagRequest( _FlashCardId, _TagId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}