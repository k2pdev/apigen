﻿namespace UI;

public interface IAssemblyMarker
{
}