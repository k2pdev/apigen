using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Items.GetItemById;

//ublic record GetItemByIdRequest(Int32? id) : IRequest<OneOf<GetItemResponse, ItemNotFound>>;

public record GetItemByIdRequest(Int32? ID) : IRequest<OneOf<GetItemResponse, ItemNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;