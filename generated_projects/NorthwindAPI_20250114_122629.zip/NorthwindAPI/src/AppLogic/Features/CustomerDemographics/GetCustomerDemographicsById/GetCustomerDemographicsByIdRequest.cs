using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.CustomerDemographics.GetCustomerDemographicsById;

//ublic record GetCustomerDemographicsByIdRequest(Int32? id) : IRequest<OneOf<GetCustomerDemographicsResponse, CustomerDemographicsNotFound>>;

public record GetCustomerDemographicsByIdRequest(String? CustomerTypeID,String? CustomerDesc) : IRequest<OneOf<GetCustomerDemographicsResponse, CustomerDemographicsNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;