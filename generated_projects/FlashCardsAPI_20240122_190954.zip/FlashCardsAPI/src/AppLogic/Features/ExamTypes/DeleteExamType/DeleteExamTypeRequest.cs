using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.ExamTypes.DeleteExamType;

//public record DeleteExamTypeRequest : IRequest<OneOf<GetExamTypeResponse, ExamTypeNotFound>>
//public record DeleteExamTypeRequest : IRequest<OneOf<bool, ExamTypeNotFound>>

public record DeleteExamTypeRequest(Int32? ExamTypeId) : IRequest<OneOf<bool, ExamTypeNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
