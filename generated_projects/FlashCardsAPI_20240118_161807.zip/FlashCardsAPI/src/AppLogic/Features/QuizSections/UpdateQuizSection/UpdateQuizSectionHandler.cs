using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.QuizSections.UpdateQuizSection;

public class UpdateQuizSectionHandler : IRequestHandler<UpdateQuizSectionRequest, OneOf<GetQuizSectionResponse, QuizSectionNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateQuizSectionHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetQuizSectionResponse, QuizSectionNotFound>> Handle(UpdateQuizSectionRequest request,
        CancellationToken cancellationToken)
    {
        var updateQuizSection = await _context.QuizSection.FirstOrDefaultAsync(x => x.QuizId == request.QuizId
 && x.SectionId == request.SectionId
        , cancellationToken);
        if (updateQuizSection == null) return new QuizSectionNotFound();


updateQuizSection.QuizId = request.QuizId;
updateQuizSection.SectionId = request.SectionId;
updateQuizSection.SectionName = request.SectionName;


        _context.QuizSection.Update(updateQuizSection);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetQuizSectionResponse>(updateQuizSection);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);