using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.AppUserFlashCards.GetAllAppUserFlashCards;

public class GetAllAppUserFlashCardsHandler : IRequestHandler<GetAllAppUserFlashCardsRequest, PaginatedList<GetAppUserFlashCardResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllAppUserFlashCardsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetAppUserFlashCardResponse>> Handle(GetAllAppUserFlashCardsRequest request, CancellationToken cancellationToken)
    {
        var AppUserFlashCard = _context.AppUserFlashCard;
        return await _mapper.ProjectTo<GetAppUserFlashCardResponse>(AppUserFlashCard)
            .OrderBy(x => x.Comment) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    