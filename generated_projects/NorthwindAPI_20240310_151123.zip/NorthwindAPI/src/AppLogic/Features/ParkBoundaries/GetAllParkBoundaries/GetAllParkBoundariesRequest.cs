using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.ParkBoundaries.GetAllParkBoundaries;

public record GetAllParkBoundariesRequest : PaginatedRequest, IRequest<PaginatedList<GetParkBoundariesResponse>>;