using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Products.GetProductsById;

public class GetProductsByIdHandler : IRequestHandler<GetProductsByIdRequest, OneOf<GetProductsResponse, ProductsNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetProductsByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetProductsResponse, ProductsNotFound>> Handle(GetProductsByIdRequest request, CancellationToken cancellationToken)
    {
        //var Products = await _context.Products.FirstOrDefaultAsync(x => x.ProductsId == request.id,
          //  cancellationToken: cancellationToken);s
        var Products = await _context.Products.FirstOrDefaultAsync(x => x.ProductID == request.ProductID
);

        if (Products is null) return new ProductsNotFound();
        return _mapper.Map<GetProductsResponse>(Products);
    }
}
