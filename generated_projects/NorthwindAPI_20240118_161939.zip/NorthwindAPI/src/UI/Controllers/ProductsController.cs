using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Products.GetAllProducts;
using AppLogic.Features.Products.GetProductsById;
using AppLogic.Features.Products.CreateProducts;
using AppLogic.Features.Products.UpdateProducts;
using AppLogic.Features.Products.DeleteProducts;
using AppLogic.Features.Products;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class ProductsController : ControllerBase
{
  private readonly IMediator _mediator;
  public ProductsController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllProducts")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetProductsResponse>>> GetAllProducts([FromQuery] GetAllProductsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetProductsById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetProductsById(Int32? _ProductID)
  {
    var result = await _mediator.Send(new GetProductsByIdRequest(_ProductID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateProducts")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetProductsResponse> CreateProducts([FromBody] CreateProductsRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateProducts")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateProducts(Int32? _ProductID, [FromBody] UpdateProductsRequest req)
  {
      var result = await _mediator.Send(req with {ProductID = _ProductID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteProducts")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteProducts(Int32? _ProductID)
  {
      var result = await _mediator.Send(new DeleteProductsRequest( _ProductID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}