using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Customers.GetCustomersById;

//ublic record GetCustomersByIdRequest(Int32? id) : IRequest<OneOf<GetCustomersResponse, CustomersNotFound>>;

public record GetCustomersByIdRequest(String? CustomerID) : IRequest<OneOf<GetCustomersResponse, CustomersNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;