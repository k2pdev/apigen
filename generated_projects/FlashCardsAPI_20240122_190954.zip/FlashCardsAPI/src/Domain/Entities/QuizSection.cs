
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(QuizSectionId))]
  public partial class QuizSection
  {
    public Int32? QuizSectionId {get; set;}
    public Int32? QuizId {get; set;}
    public Int32? SectionName {get; set;}
  }


