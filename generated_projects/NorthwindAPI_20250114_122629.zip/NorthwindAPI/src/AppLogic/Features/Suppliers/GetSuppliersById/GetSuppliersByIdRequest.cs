using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Suppliers.GetSuppliersById;

//ublic record GetSuppliersByIdRequest(Int32? id) : IRequest<OneOf<GetSuppliersResponse, SuppliersNotFound>>;

public record GetSuppliersByIdRequest(Int32? SupplierID) : IRequest<OneOf<GetSuppliersResponse, SuppliersNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;