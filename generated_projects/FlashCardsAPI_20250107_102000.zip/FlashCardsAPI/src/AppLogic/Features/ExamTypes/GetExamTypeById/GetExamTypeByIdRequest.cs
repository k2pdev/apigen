using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.ExamTypes.GetExamTypeById;

//ublic record GetExamTypeByIdRequest(Int32? id) : IRequest<OneOf<GetExamTypeResponse, ExamTypeNotFound>>;

public record GetExamTypeByIdRequest(Int32? ExamTypeId) : IRequest<OneOf<GetExamTypeResponse, ExamTypeNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;