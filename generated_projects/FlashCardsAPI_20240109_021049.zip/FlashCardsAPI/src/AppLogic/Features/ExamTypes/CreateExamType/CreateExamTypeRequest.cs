using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.ExamTypes.CreateExamType;

public record CreateExamTypeRequest : IRequest<GetExamTypeResponse>
{
    public String? ExamTypeName {get; set;} = null!;
}