using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Employees.CreateEmployees;

public record CreateEmployeesRequest : IRequest<GetEmployeesResponse>
{
    public String? LastName {get; set;} = null!;
    public String? FirstName {get; set;} = null!;
    public String? Title {get; set;} = null!;
    public String? TitleOfCourtesy {get; set;} = null!;
    public String? BirthDate {get; set;}
    public String? HireDate {get; set;}
    public String? Address {get; set;} = null!;
    public String? City {get; set;} = null!;
    public String? Region {get; set;} = null!;
    public String? PostalCode {get; set;} = null!;
    public String? Country {get; set;} = null!;
    public String? HomePhone {get; set;} = null!;
    public String? Extension {get; set;} = null!;
    public System.Byte[]? Photo {get; set;} = null!;
    public System.Byte[]? Notes {get; set;}
    public Int32? ReportsTo {get; set;}
    public String? PhotoPath {get; set;} = null!;
}