
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(QuizId))]
  public partial class Quiz
  {
    public Int32? QuizId {get; set;}
    public Int32? ParentQuizId {get; set;}
    public String? QuizName {get; set;} = null!;
  }


