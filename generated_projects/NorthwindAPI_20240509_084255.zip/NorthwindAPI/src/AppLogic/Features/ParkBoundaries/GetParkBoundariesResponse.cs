using Domain.Entities.Common;
using System;

namespace AppLogic.Features.ParkBoundaries;

public record GetParkBoundariesResponse
{
    public Int32? ID {get; set;}
    public String? Name {get; set;} = null!;
    public String? BoundaryType {get; set;} = null!;
    public String? geom {get; set;}
}



