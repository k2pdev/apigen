using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Customers.GetAllCustomers;

public record GetAllCustomersRequest : PaginatedRequest, IRequest<PaginatedList<GetCustomersResponse>>;