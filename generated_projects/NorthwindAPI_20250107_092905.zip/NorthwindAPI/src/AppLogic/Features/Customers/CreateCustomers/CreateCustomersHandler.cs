using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Customers.CreateCustomers;

public class CreateCustomersHandler : IRequestHandler<CreateCustomersRequest, GetCustomersResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateCustomersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetCustomersResponse?> Handle(CreateCustomersRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.Customers>(request);
        _context.Customers.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetCustomersResponse?>(created);
    }
}