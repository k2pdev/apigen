using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Customers.DeleteCustomers;

//public record DeleteCustomersRequest : IRequest<OneOf<GetCustomersResponse, CustomersNotFound>>
//public record DeleteCustomersRequest : IRequest<OneOf<bool, CustomersNotFound>>

public record DeleteCustomersRequest(String? CustomerID) : IRequest<OneOf<bool, CustomersNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
