using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Products.DeleteProducts;

//public record DeleteProductsRequest : IRequest<OneOf<GetProductsResponse, ProductsNotFound>>
//public record DeleteProductsRequest : IRequest<OneOf<bool, ProductsNotFound>>

public record DeleteProductsRequest(Int32? ProductID) : IRequest<OneOf<bool, ProductsNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
