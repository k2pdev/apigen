using AppLogic.Common.Responses;

namespace AppLogic.Features.FlashCards;

public record FlashCardNotFound : NotFound {}