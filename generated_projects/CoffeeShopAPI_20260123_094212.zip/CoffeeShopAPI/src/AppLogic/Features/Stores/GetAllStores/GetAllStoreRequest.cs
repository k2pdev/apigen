using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Stores.GetAllStores;

public record GetAllStoresRequest : PaginatedRequest, IRequest<PaginatedList<GetStoreResponse>>;