using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.FlashCardImages.GetFlashCardImageById;

//ublic record GetFlashCardImageByIdRequest(Int32? id) : IRequest<OneOf<GetFlashCardImageResponse, FlashCardImageNotFound>>;

public record GetFlashCardImageByIdRequest(Int32? FlashCardId) : IRequest<OneOf<GetFlashCardImageResponse, FlashCardImageNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;