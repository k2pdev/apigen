using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.CustomerCustomerDemos.UpdateCustomerCustomerDemo;

public record UpdateCustomerCustomerDemoRequest : IRequest<OneOf<GetCustomerCustomerDemoResponse, CustomerCustomerDemoNotFound>>
{
    public String? CustomerID {get; set;} = null!;
    public String? CustomerTypeID {get; set;} = null!;
}   