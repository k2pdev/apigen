using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.AppUserFlashCards.GetAllAppUserFlashCards;

public record GetAllAppUserFlashCardsRequest : PaginatedRequest, IRequest<PaginatedList<GetAppUserFlashCardResponse>>;