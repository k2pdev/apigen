using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.AppUsers.GetAppUserById;

public class GetAppUserByIdHandler : IRequestHandler<GetAppUserByIdRequest, OneOf<GetAppUserResponse, AppUserNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetAppUserByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetAppUserResponse, AppUserNotFound>> Handle(GetAppUserByIdRequest request, CancellationToken cancellationToken)
    {
        //var AppUser = await _context.AppUsers.FirstOrDefaultAsync(x => x.AppUserId == request.id,
          //  cancellationToken: cancellationToken);s
        var AppUser = await _context.AppUser.FirstOrDefaultAsync(x => x.AppUserId == request.AppUserId
);

        if (AppUser is null) return new AppUserNotFound();
        return _mapper.Map<GetAppUserResponse>(AppUser);
    }
}
