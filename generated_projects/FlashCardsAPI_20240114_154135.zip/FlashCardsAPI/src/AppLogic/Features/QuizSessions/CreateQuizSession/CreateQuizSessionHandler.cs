using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.QuizSessions.CreateQuizSession;

public class CreateQuizSessionHandler : IRequestHandler<CreateQuizSessionRequest, GetQuizSessionResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateQuizSessionHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetQuizSessionResponse?> Handle(CreateQuizSessionRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.QuizSession>(request);
        _context.QuizSession.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetQuizSessionResponse?>(created);
    }
}