using AppLogic.Common.Responses;

namespace AppLogic.Features.Shippers;

public record ShippersNotFound : NotFound {}