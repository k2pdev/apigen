using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Territories.DeleteTerritories;

public class DeleteTerritoriesHandler : IRequestHandler<DeleteTerritoriesRequest, OneOf<bool, TerritoriesNotFound>>
{
    private readonly IContext _context;
    public DeleteTerritoriesHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, TerritoriesNotFound>> Handle(DeleteTerritoriesRequest request, CancellationToken cancellationToken)
    {
        var Territories = await _context.Territories.FirstOrDefaultAsync(x => x.TerritoryID == request.TerritoryID
 && x.TerritoryDescription == request.TerritoryDescription
 && x.RegionID == request.RegionID
);

        if (Territories is null) return new TerritoriesNotFound();

        _context.Territories.Remove(Territories);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
