using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Exams.GetAllExams;
using AppLogic.Features.Exams.GetExamById;
using AppLogic.Features.Exams.CreateExam;
using AppLogic.Features.Exams.UpdateExam;
using AppLogic.Features.Exams.DeleteExam;
using AppLogic.Features.Exams;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class ExamController : ControllerBase
{
  private readonly IMediator _mediator;
  public ExamController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllExams")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetExamResponse>>> GetAllExams([FromQuery] GetAllExamsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetExamById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetExamById(Int32? _ExamId)
  {
    var result = await _mediator.Send(new GetExamByIdRequest(_ExamId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateExam")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetExamResponse> CreateExam([FromBody] CreateExamRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateExam")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateExam(Int32? _ExamId, [FromBody] UpdateExamRequest req)
  {
      var result = await _mediator.Send(req with {ExamId = _ExamId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteExam")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteExam(Int32? _ExamId)
  {
      var result = await _mediator.Send(new DeleteExamRequest( _ExamId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}