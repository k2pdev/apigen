using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Regions.GetRegionById;

//ublic record GetRegionByIdRequest(Int32? id) : IRequest<OneOf<GetRegionResponse, RegionNotFound>>;

public record GetRegionByIdRequest(Int32? RegionID,String? RegionDescription) : IRequest<OneOf<GetRegionResponse, RegionNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;