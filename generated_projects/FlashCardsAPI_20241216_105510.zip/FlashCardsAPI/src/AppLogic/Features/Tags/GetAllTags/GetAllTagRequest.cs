using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Tags.GetAllTags;

public record GetAllTagsRequest : PaginatedRequest, IRequest<PaginatedList<GetTagResponse>>;