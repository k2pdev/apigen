using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ExamTypes.DeleteExamType;

public class DeleteExamTypeHandler : IRequestHandler<DeleteExamTypeRequest, OneOf<bool, ExamTypeNotFound>>
{
    private readonly IContext _context;
    public DeleteExamTypeHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, ExamTypeNotFound>> Handle(DeleteExamTypeRequest request, CancellationToken cancellationToken)
    {
        var ExamType = await _context.ExamType.FirstOrDefaultAsync(x => x.ExamTypeId == request.ExamTypeId
);

        if (ExamType is null) return new ExamTypeNotFound();

        _context.ExamType.Remove(ExamType);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
