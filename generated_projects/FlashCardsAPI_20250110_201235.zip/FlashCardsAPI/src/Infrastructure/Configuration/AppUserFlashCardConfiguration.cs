using Domain.Entities;
using Domain.Entities.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configuration;

public class AppUserFlashCardConfiguration : IEntityTypeConfiguration<AppUserFlashCard>
{
    public void Configure(EntityTypeBuilder<AppUserFlashCard> builder)
    {
        builder.HasKey(x => x.AppUserFlashCardId);
        builder.Property(x => x.AppUserFlashCardId);

    }
}