using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.EmployeeTerritories.GetAllEmployeeTerritories;

public record GetAllEmployeeTerritoriesRequest : PaginatedRequest, IRequest<PaginatedList<GetEmployeeTerritoriesResponse>>;