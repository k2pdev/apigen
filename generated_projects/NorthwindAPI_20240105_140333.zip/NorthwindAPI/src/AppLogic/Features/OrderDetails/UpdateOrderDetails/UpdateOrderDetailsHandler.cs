using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.OrderDetails.UpdateOrderDetails;

public class UpdateOrderDetailsHandler : IRequestHandler<UpdateOrderDetailsRequest, OneOf<GetOrderDetailsResponse, OrderDetailsNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateOrderDetailsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetOrderDetailsResponse, OrderDetailsNotFound>> Handle(UpdateOrderDetailsRequest request,
        CancellationToken cancellationToken)
    {
        var updateOrderDetails = await _context.OrderDetails.FirstOrDefaultAsync(x => x.OrderID == request.OrderID
        , cancellationToken);
        if (updateOrderDetails == null) return new OrderDetailsNotFound();


updateOrderDetails.OrderID = request.OrderID;
updateOrderDetails.ProductID = request.ProductID;
updateOrderDetails.UnitPrice = request.UnitPrice;
updateOrderDetails.Quantity = request.Quantity;
updateOrderDetails.Discount = request.Discount;


        _context.OrderDetails.Update(updateOrderDetails);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetOrderDetailsResponse>(updateOrderDetails);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);