using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.ExamTypes.UpdateExamType;

public class UpdateExamTypeHandler : IRequestHandler<UpdateExamTypeRequest, OneOf<GetExamTypeResponse, ExamTypeNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateExamTypeHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetExamTypeResponse, ExamTypeNotFound>> Handle(UpdateExamTypeRequest request,
        CancellationToken cancellationToken)
    {
        var updateExamType = await _context.ExamType.FirstOrDefaultAsync(x => x.ExamTypeId == request.ExamTypeId
        , cancellationToken);
        if (updateExamType == null) return new ExamTypeNotFound();


updateExamType.ExamTypeId = request.ExamTypeId;
updateExamType.ExamTypeName = request.ExamTypeName;


        _context.ExamType.Update(updateExamType);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetExamTypeResponse>(updateExamType);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);