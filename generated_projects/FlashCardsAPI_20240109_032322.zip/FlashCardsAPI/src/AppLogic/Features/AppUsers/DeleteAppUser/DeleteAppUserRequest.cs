using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.AppUsers.DeleteAppUser;

//public record DeleteAppUserRequest : IRequest<OneOf<GetAppUserResponse, AppUserNotFound>>
//public record DeleteAppUserRequest : IRequest<OneOf<bool, AppUserNotFound>>

public record DeleteAppUserRequest(Int32? AppUserId) : IRequest<OneOf<bool, AppUserNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
