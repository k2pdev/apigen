using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Quizzes.DeleteQuiz;

public class DeleteQuizHandler : IRequestHandler<DeleteQuizRequest, OneOf<bool, QuizNotFound>>
{
    private readonly IContext _context;
    public DeleteQuizHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, QuizNotFound>> Handle(DeleteQuizRequest request, CancellationToken cancellationToken)
    {
        var Quiz = await _context.Quiz.FirstOrDefaultAsync(x => x.QuizId == request.QuizId
);

        if (Quiz is null) return new QuizNotFound();

        _context.Quiz.Remove(Quiz);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
