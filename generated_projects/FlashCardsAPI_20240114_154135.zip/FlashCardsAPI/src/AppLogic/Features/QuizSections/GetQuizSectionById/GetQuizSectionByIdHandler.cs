using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.QuizSections.GetQuizSectionById;

public class GetQuizSectionByIdHandler : IRequestHandler<GetQuizSectionByIdRequest, OneOf<GetQuizSectionResponse, QuizSectionNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetQuizSectionByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetQuizSectionResponse, QuizSectionNotFound>> Handle(GetQuizSectionByIdRequest request, CancellationToken cancellationToken)
    {
        //var QuizSection = await _context.QuizSections.FirstOrDefaultAsync(x => x.QuizSectionId == request.id,
          //  cancellationToken: cancellationToken);s
        var QuizSection = await _context.QuizSection.FirstOrDefaultAsync(x => x.QuizId == request.QuizId
 && x.SectionId == request.SectionId
);

        if (QuizSection is null) return new QuizSectionNotFound();
        return _mapper.Map<GetQuizSectionResponse>(QuizSection);
    }
}
