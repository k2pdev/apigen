using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Regions.GetAllRegions;
using AppLogic.Features.Regions.GetRegionById;
using AppLogic.Features.Regions.CreateRegion;
using AppLogic.Features.Regions.UpdateRegion;
using AppLogic.Features.Regions.DeleteRegion;
using AppLogic.Features.Regions;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class RegionController : ControllerBase
{
  private readonly IMediator _mediator;
  public RegionController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllRegions")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetRegionResponse>>> GetAllRegions([FromQuery] GetAllRegionsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetRegionById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetRegionById(Int32? _RegionID,String? _RegionDescription)
  {
    var result = await _mediator.Send(new GetRegionByIdRequest(_RegionID,_RegionDescription));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateRegion")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetRegionResponse> CreateRegion([FromBody] CreateRegionRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateRegion")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateRegion(Int32? _RegionID,String? _RegionDescription, [FromBody] UpdateRegionRequest req)
  {
      var result = await _mediator.Send(req with {RegionID = _RegionID,RegionDescription = _RegionDescription});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteRegion")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteRegion(Int32? _RegionID,String? _RegionDescription)
  {
      var result = await _mediator.Send(new DeleteRegionRequest( _RegionID, _RegionDescription)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}