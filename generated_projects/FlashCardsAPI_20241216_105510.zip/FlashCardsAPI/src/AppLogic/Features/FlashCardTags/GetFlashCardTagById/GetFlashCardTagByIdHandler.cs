using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCardTags.GetFlashCardTagById;

public class GetFlashCardTagByIdHandler : IRequestHandler<GetFlashCardTagByIdRequest, OneOf<GetFlashCardTagResponse, FlashCardTagNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetFlashCardTagByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetFlashCardTagResponse, FlashCardTagNotFound>> Handle(GetFlashCardTagByIdRequest request, CancellationToken cancellationToken)
    {
        //var FlashCardTag = await _context.FlashCardTags.FirstOrDefaultAsync(x => x.FlashCardTagId == request.id,
          //  cancellationToken: cancellationToken);s
        var FlashCardTag = await _context.FlashCardTag.FirstOrDefaultAsync(x => x.FlashCardId == request.FlashCardId
 && x.TagId == request.TagId
);

        if (FlashCardTag is null) return new FlashCardTagNotFound();
        return _mapper.Map<GetFlashCardTagResponse>(FlashCardTag);
    }
}
