
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(CustomerID))]
  public partial class Customers
  {
    public String? CustomerID {get; set;} = null!;
    public String? CompanyName {get; set;} = null!;
    public String? ContactName {get; set;} = null!;
    public String? ContactTitle {get; set;} = null!;
    public String? Address {get; set;} = null!;
    public String? City {get; set;} = null!;
    public String? Region {get; set;} = null!;
    public String? PostalCode {get; set;} = null!;
    public String? Country {get; set;} = null!;
    public String? Phone {get; set;} = null!;
    public String? Fax {get; set;} = null!;
  }


