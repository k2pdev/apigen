using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Customers.GetAllCustomers;
using AppLogic.Features.Customers.GetCustomerById;
using AppLogic.Features.Customers.CreateCustomer;
using AppLogic.Features.Customers.UpdateCustomer;
using AppLogic.Features.Customers.DeleteCustomer;
using AppLogic.Features.Customers;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class CustomerController : ControllerBase
{
  private readonly IMediator _mediator;
  public CustomerController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllCustomers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetCustomerResponse>>> GetAllCustomers([FromQuery] GetAllCustomersRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetCustomerById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetCustomerById(Guid? _CustomerId)
  {
    var result = await _mediator.Send(new GetCustomerByIdRequest(_CustomerId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateCustomer")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetCustomerResponse> CreateCustomer([FromBody] CreateCustomerRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateCustomer")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateCustomer(Guid? _CustomerId, [FromBody] UpdateCustomerRequest req)
  {
      var result = await _mediator.Send(req with {CustomerId = _CustomerId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteCustomer")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteCustomer(Guid? _CustomerId)
  {
      var result = await _mediator.Send(new DeleteCustomerRequest( _CustomerId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}