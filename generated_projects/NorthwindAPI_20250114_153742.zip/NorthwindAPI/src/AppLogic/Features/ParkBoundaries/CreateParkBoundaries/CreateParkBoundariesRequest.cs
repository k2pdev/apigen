using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.ParkBoundaries.CreateParkBoundaries;

public record CreateParkBoundariesRequest : IRequest<GetParkBoundariesResponse>
{
    public Int32? ID {get; set;}
    public String? Name {get; set;} = null!;
    public String? BoundaryType {get; set;} = null!;
    public String? geom {get; set;}
}