using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.QuizSessions.DeleteQuizSession;

public class DeleteQuizSessionHandler : IRequestHandler<DeleteQuizSessionRequest, OneOf<bool, QuizSessionNotFound>>
{
    private readonly IContext _context;
    public DeleteQuizSessionHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, QuizSessionNotFound>> Handle(DeleteQuizSessionRequest request, CancellationToken cancellationToken)
    {
        var QuizSession = await _context.QuizSession.FirstOrDefaultAsync(x => x.QuizSessionId == request.QuizSessionId
);

        if (QuizSession is null) return new QuizSessionNotFound();

        _context.QuizSession.Remove(QuizSession);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
