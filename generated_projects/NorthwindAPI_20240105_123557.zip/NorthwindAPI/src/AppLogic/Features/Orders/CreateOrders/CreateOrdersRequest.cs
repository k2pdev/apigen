using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Orders.CreateOrders;

public record CreateOrdersRequest : IRequest<GetOrdersResponse>
{
    public String? CustomerID {get; set;} = null!;
    public Int32? EmployeeID {get; set;}
    public Int32? OrderDate {get; set;}
    public Int32? RequiredDate {get; set;}
    public Int32? ShippedDate {get; set;}
    public Int32? ShipVia {get; set;}
    public Int32? Freight {get; set;}
    public String? ShipName {get; set;} = null!;
    public String? ShipAddress {get; set;} = null!;
    public String? ShipCity {get; set;} = null!;
    public String? ShipRegion {get; set;} = null!;
    public String? ShipPostalCode {get; set;} = null!;
    public String? ShipCountry {get; set;} = null!;
}