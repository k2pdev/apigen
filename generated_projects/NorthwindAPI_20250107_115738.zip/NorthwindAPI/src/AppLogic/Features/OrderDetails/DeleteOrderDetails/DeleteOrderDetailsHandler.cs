using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.OrderDetails.DeleteOrderDetails;

public class DeleteOrderDetailsHandler : IRequestHandler<DeleteOrderDetailsRequest, OneOf<bool, OrderDetailsNotFound>>
{
    private readonly IContext _context;
    public DeleteOrderDetailsHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, OrderDetailsNotFound>> Handle(DeleteOrderDetailsRequest request, CancellationToken cancellationToken)
    {
        var OrderDetails = await _context.OrderDetails.FirstOrDefaultAsync(x => x.OrderID == request.OrderID
);

        if (OrderDetails is null) return new OrderDetailsNotFound();

        _context.OrderDetails.Remove(OrderDetails);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
