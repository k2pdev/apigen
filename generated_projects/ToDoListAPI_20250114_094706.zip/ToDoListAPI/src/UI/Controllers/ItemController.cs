using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Items.GetAllItems;
using AppLogic.Features.Items.GetItemById;
using AppLogic.Features.Items.CreateItem;
using AppLogic.Features.Items.UpdateItem;
using AppLogic.Features.Items.DeleteItem;
using AppLogic.Features.Items;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class ItemController : ControllerBase
{
  private readonly IMediator _mediator;
  public ItemController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllItems")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetItemResponse>>> GetAllItems([FromQuery] GetAllItemsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetItemById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetItemById(Int32? _ID)
  {
    var result = await _mediator.Send(new GetItemByIdRequest(_ID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateItem")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetItemResponse> CreateItem([FromBody] CreateItemRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateItem")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateItem(Int32? _ID, [FromBody] UpdateItemRequest req)
  {
      var result = await _mediator.Send(req with {ID = _ID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteItem")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteItem(Int32? _ID)
  {
      var result = await _mediator.Send(new DeleteItemRequest( _ID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}