using AppLogic.Common;
using Domain.Entities;
using Infrastructure.Configuration;
using EntityFramework.Exceptions.SqlServer;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Context;

public class ApplicationDbContext : DbContext, IContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<AppUser> AppUser => Set<AppUser>();
    public DbSet<AppUserFlashCard> AppUserFlashCard => Set<AppUserFlashCard>();
    public DbSet<Exam> Exam => Set<Exam>();
    public DbSet<ExamQuiz> ExamQuiz => Set<ExamQuiz>();
    public DbSet<ExamType> ExamType => Set<ExamType>();
    public DbSet<FlashCard> FlashCard => Set<FlashCard>();
    public DbSet<FlashCardImage> FlashCardImage => Set<FlashCardImage>();
    public DbSet<FlashCardTag> FlashCardTag => Set<FlashCardTag>();
    public DbSet<Quiz> Quiz => Set<Quiz>();
    public DbSet<QuizSection> QuizSection => Set<QuizSection>();
    public DbSet<QuizSession> QuizSession => Set<QuizSession>();
    public DbSet<Tag> Tag => Set<Tag>();


    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);
        optionsBuilder.UseExceptionProcessor();
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
         
    }
}


