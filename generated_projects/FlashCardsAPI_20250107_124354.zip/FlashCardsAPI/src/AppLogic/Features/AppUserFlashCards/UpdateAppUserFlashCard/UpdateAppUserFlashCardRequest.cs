using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.AppUserFlashCards.UpdateAppUserFlashCard;

public record UpdateAppUserFlashCardRequest : IRequest<OneOf<GetAppUserFlashCardResponse, AppUserFlashCardNotFound>>
{
    public Int32? AppUserFlashCardId {get; set;}
    public Int32? AppUserId {get; set;}
    public Int32? FlashCardId {get; set;}
    public Int32? Score {get; set;}
    public String? Comment {get; set;} = null!;
}   