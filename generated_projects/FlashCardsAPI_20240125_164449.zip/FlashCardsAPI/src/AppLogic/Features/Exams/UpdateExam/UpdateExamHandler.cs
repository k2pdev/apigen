using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Exams.UpdateExam;

public class UpdateExamHandler : IRequestHandler<UpdateExamRequest, OneOf<GetExamResponse, ExamNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateExamHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetExamResponse, ExamNotFound>> Handle(UpdateExamRequest request,
        CancellationToken cancellationToken)
    {
        var updateExam = await _context.Exam.FirstOrDefaultAsync(x => x.ExamId == request.ExamId
        , cancellationToken);
        if (updateExam == null) return new ExamNotFound();


updateExam.ExamId = request.ExamId;
updateExam.ExamType = request.ExamType;
updateExam.ExamName = request.ExamName;


        _context.Exam.Update(updateExam);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetExamResponse>(updateExam);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);