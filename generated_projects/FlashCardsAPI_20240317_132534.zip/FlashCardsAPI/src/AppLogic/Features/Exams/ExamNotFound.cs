using AppLogic.Common.Responses;

namespace AppLogic.Features.Exams;

public record ExamNotFound : NotFound {}