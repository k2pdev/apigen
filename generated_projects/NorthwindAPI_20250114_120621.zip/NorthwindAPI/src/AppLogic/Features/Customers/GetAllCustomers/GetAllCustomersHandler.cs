using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Customers.GetAllCustomers;

public class GetAllCustomersHandler : IRequestHandler<GetAllCustomersRequest, PaginatedList<GetCustomersResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllCustomersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetCustomersResponse>> Handle(GetAllCustomersRequest request, CancellationToken cancellationToken)
    {
        var Customers = _context.Customers;
        return await _mapper.ProjectTo<GetCustomersResponse>(Customers)
            .OrderBy(x => x.CompanyName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    