using Domain.Entities.Common;
using System;

namespace AppLogic.Features.CustomerCustomerDemos;

public record GetCustomerCustomerDemoResponse
{
    public String? CustomerID {get; set;} = null!;
    public String? CustomerTypeID {get; set;} = null!;
}



