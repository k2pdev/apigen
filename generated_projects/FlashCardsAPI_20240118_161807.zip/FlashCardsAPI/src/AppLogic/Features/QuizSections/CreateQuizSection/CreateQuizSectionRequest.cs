using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.QuizSections.CreateQuizSection;

public record CreateQuizSectionRequest : IRequest<GetQuizSectionResponse>
{
    public Int32? QuizId {get; set;}
    public Int32? SectionId {get; set;}
    public String? SectionName {get; set;} = null!;
}