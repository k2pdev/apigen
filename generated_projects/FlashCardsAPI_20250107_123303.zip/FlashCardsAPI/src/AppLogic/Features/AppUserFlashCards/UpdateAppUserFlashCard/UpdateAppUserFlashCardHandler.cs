using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.AppUserFlashCards.UpdateAppUserFlashCard;

public class UpdateAppUserFlashCardHandler : IRequestHandler<UpdateAppUserFlashCardRequest, OneOf<GetAppUserFlashCardResponse, AppUserFlashCardNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateAppUserFlashCardHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetAppUserFlashCardResponse, AppUserFlashCardNotFound>> Handle(UpdateAppUserFlashCardRequest request,
        CancellationToken cancellationToken)
    {
        var updateAppUserFlashCard = await _context.AppUserFlashCard.FirstOrDefaultAsync(x => x.AppUserFlashCardId == request.AppUserFlashCardId
        , cancellationToken);
        if (updateAppUserFlashCard == null) return new AppUserFlashCardNotFound();


updateAppUserFlashCard.AppUserFlashCardId = request.AppUserFlashCardId;
updateAppUserFlashCard.AppUserId = request.AppUserId;
updateAppUserFlashCard.FlashCardId = request.FlashCardId;
updateAppUserFlashCard.Score = request.Score;
updateAppUserFlashCard.Comment = request.Comment;


        _context.AppUserFlashCard.Update(updateAppUserFlashCard);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetAppUserFlashCardResponse>(updateAppUserFlashCard);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);