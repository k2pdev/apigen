using Domain.Entities.Common;
using System;

namespace AppLogic.Features.CustomerDemographics;

public record GetCustomerDemographicsResponse
{
    public String? CustomerTypeID {get; set;} = null!;
    public String? CustomerDesc {get; set;}
}



