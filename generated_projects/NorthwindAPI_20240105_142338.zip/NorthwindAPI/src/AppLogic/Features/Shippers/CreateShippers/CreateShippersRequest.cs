using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Shippers.CreateShippers;

public record CreateShippersRequest : IRequest<GetShippersResponse>
{
    public String? CompanyName {get; set;} = null!;
    public String? Phone {get; set;} = null!;
}