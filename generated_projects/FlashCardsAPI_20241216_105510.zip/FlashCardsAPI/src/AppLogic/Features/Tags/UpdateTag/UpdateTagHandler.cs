using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Tags.UpdateTag;

public class UpdateTagHandler : IRequestHandler<UpdateTagRequest, OneOf<GetTagResponse, TagNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateTagHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetTagResponse, TagNotFound>> Handle(UpdateTagRequest request,
        CancellationToken cancellationToken)
    {
        var updateTag = await _context.Tag.FirstOrDefaultAsync(x => x.TagId == request.TagId
 && x.TagName == request.TagName
        , cancellationToken);
        if (updateTag == null) return new TagNotFound();


updateTag.TagId = request.TagId;
updateTag.TagName = request.TagName;


        _context.Tag.Update(updateTag);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetTagResponse>(updateTag);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);