using AppLogic.Common.Responses;

namespace AppLogic.Features.AppUserFlashCards;

public record AppUserFlashCardNotFound : NotFound {}