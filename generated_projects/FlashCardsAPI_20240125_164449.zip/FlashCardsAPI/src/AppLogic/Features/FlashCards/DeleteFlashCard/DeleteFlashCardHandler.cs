using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCards.DeleteFlashCard;

public class DeleteFlashCardHandler : IRequestHandler<DeleteFlashCardRequest, OneOf<bool, FlashCardNotFound>>
{
    private readonly IContext _context;
    public DeleteFlashCardHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, FlashCardNotFound>> Handle(DeleteFlashCardRequest request, CancellationToken cancellationToken)
    {
        var FlashCard = await _context.FlashCard.FirstOrDefaultAsync(x => x.FlashCardId == request.FlashCardId
);

        if (FlashCard is null) return new FlashCardNotFound();

        _context.FlashCard.Remove(FlashCard);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
