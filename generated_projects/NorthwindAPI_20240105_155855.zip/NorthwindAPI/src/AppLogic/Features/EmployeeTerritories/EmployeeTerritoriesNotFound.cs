using AppLogic.Common.Responses;

namespace AppLogic.Features.EmployeeTerritories;

public record EmployeeTerritoriesNotFound : NotFound {}