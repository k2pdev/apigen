using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.FlashCards.UpdateFlashCard;

public class UpdateFlashCardHandler : IRequestHandler<UpdateFlashCardRequest, OneOf<GetFlashCardResponse, FlashCardNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateFlashCardHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetFlashCardResponse, FlashCardNotFound>> Handle(UpdateFlashCardRequest request,
        CancellationToken cancellationToken)
    {
        var updateFlashCard = await _context.FlashCard.FirstOrDefaultAsync(x => x.FlashCardId == request.FlashCardId
        , cancellationToken);
        if (updateFlashCard == null) return new FlashCardNotFound();


updateFlashCard.FlashCardId = request.FlashCardId;
updateFlashCard.QuizId = request.QuizId;
updateFlashCard.QuestionContent = request.QuestionContent;
updateFlashCard.AnswerContent = request.AnswerContent;


        _context.FlashCard.Update(updateFlashCard);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetFlashCardResponse>(updateFlashCard);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);