using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Categories.UpdateCategories;

public class UpdateCategoriesHandler : IRequestHandler<UpdateCategoriesRequest, OneOf<GetCategoriesResponse, CategoriesNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateCategoriesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetCategoriesResponse, CategoriesNotFound>> Handle(UpdateCategoriesRequest request,
        CancellationToken cancellationToken)
    {
        var updateCategories = await _context.Categories.FirstOrDefaultAsync(x => x.CategoryID == request.CategoryID
        , cancellationToken);
        if (updateCategories == null) return new CategoriesNotFound();


updateCategories.CategoryID = request.CategoryID;
updateCategories.CategoryName = request.CategoryName;
updateCategories.Description = request.Description;
updateCategories.Picture = request.Picture;


        _context.Categories.Update(updateCategories);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetCategoriesResponse>(updateCategories);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);