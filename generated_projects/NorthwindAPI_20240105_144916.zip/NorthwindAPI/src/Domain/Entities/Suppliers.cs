
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(SupplierID))]
  public partial class Suppliers
  {
    public Int32? SupplierID {get; set;}
    public String? CompanyName {get; set;} = null!;
    public String? ContactName {get; set;} = null!;
    public String? ContactTitle {get; set;} = null!;
    public String? Address {get; set;} = null!;
    public String? City {get; set;} = null!;
    public String? Region {get; set;} = null!;
    public String? PostalCode {get; set;} = null!;
    public String? Country {get; set;} = null!;
    public String? Phone {get; set;} = null!;
    public String? Fax {get; set;} = null!;
    public String? HomePage {get; set;}
  }


