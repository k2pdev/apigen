using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.AppUserFlashCards.GetAllAppUserFlashCards;
using AppLogic.Features.AppUserFlashCards.GetAppUserFlashCardById;
using AppLogic.Features.AppUserFlashCards.CreateAppUserFlashCard;
using AppLogic.Features.AppUserFlashCards.UpdateAppUserFlashCard;
using AppLogic.Features.AppUserFlashCards.DeleteAppUserFlashCard;
using AppLogic.Features.AppUserFlashCards;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class AppUserFlashCardController : ControllerBase
{
  private readonly IMediator _mediator;
  public AppUserFlashCardController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllAppUserFlashCards")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetAppUserFlashCardResponse>>> GetAllAppUserFlashCards([FromQuery] GetAllAppUserFlashCardsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetAppUserFlashCardById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetAppUserFlashCardById(Int32? _AppUserFlashCardId)
  {
    var result = await _mediator.Send(new GetAppUserFlashCardByIdRequest(_AppUserFlashCardId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateAppUserFlashCard")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetAppUserFlashCardResponse> CreateAppUserFlashCard([FromBody] CreateAppUserFlashCardRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateAppUserFlashCard")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateAppUserFlashCard(Int32? _AppUserFlashCardId, [FromBody] UpdateAppUserFlashCardRequest req)
  {
      var result = await _mediator.Send(req with {AppUserFlashCardId = _AppUserFlashCardId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteAppUserFlashCard")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteAppUserFlashCard(Int32? _AppUserFlashCardId)
  {
      var result = await _mediator.Send(new DeleteAppUserFlashCardRequest( _AppUserFlashCardId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}