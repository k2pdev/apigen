using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ExamTypes.GetAllExamTypes;

public class GetAllExamTypesHandler : IRequestHandler<GetAllExamTypesRequest, PaginatedList<GetExamTypeResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllExamTypesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetExamTypeResponse>> Handle(GetAllExamTypesRequest request, CancellationToken cancellationToken)
    {
        var ExamType = _context.ExamType;
        return await _mapper.ProjectTo<GetExamTypeResponse>(ExamType)
            .OrderBy(x => x.ExamTypeName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    