using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.CustomerCustomerDemos.GetAllCustomerCustomerDemos;
using AppLogic.Features.CustomerCustomerDemos.GetCustomerCustomerDemoById;
using AppLogic.Features.CustomerCustomerDemos.CreateCustomerCustomerDemo;
using AppLogic.Features.CustomerCustomerDemos.UpdateCustomerCustomerDemo;
using AppLogic.Features.CustomerCustomerDemos.DeleteCustomerCustomerDemo;
using AppLogic.Features.CustomerCustomerDemos;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class CustomerCustomerDemoController : ControllerBase
{
  private readonly IMediator _mediator;
  public CustomerCustomerDemoController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllCustomerCustomerDemos")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetCustomerCustomerDemoResponse>>> GetAllCustomerCustomerDemos([FromQuery] GetAllCustomerCustomerDemosRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetCustomerCustomerDemoById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetCustomerCustomerDemoById(String? _CustomerID,String? _CustomerTypeID)
  {
    var result = await _mediator.Send(new GetCustomerCustomerDemoByIdRequest(_CustomerID,_CustomerTypeID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateCustomerCustomerDemo")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetCustomerCustomerDemoResponse> CreateCustomerCustomerDemo([FromBody] CreateCustomerCustomerDemoRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateCustomerCustomerDemo")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateCustomerCustomerDemo(String? _CustomerID,String? _CustomerTypeID, [FromBody] UpdateCustomerCustomerDemoRequest req)
  {
      var result = await _mediator.Send(req with {CustomerID = _CustomerID,CustomerTypeID = _CustomerTypeID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteCustomerCustomerDemo")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteCustomerCustomerDemo(String? _CustomerID,String? _CustomerTypeID)
  {
      var result = await _mediator.Send(new DeleteCustomerCustomerDemoRequest( _CustomerID, _CustomerTypeID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}