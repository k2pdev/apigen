using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Customers.GetCustomerById;

//ublic record GetCustomerByIdRequest(Int32? id) : IRequest<OneOf<GetCustomerResponse, CustomerNotFound>>;

public record GetCustomerByIdRequest(Guid? CustomerId) : IRequest<OneOf<GetCustomerResponse, CustomerNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;