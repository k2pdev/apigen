using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Regions.DeleteRegion;

//public record DeleteRegionRequest : IRequest<OneOf<GetRegionResponse, RegionNotFound>>
//public record DeleteRegionRequest : IRequest<OneOf<bool, RegionNotFound>>

public record DeleteRegionRequest(Int32? RegionID,String? RegionDescription) : IRequest<OneOf<bool, RegionNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
