using AutoMapper;
using AppLogic.Features.AppUsers;
using AppLogic.Features.AppUsers.GetAllAppUsers;
using AppLogic.Features.AppUsers.CreateAppUser;
using AppLogic.Features.AppUsers.UpdateAppUser;
using AppLogic.Features.Exams;
using AppLogic.Features.Exams.GetAllExams;
using AppLogic.Features.Exams.CreateExam;
using AppLogic.Features.Exams.UpdateExam;
using AppLogic.Features.ExamQuizzes;
using AppLogic.Features.ExamQuizzes.GetAllExamQuizzes;
using AppLogic.Features.ExamQuizzes.CreateExamQuiz;
using AppLogic.Features.ExamQuizzes.UpdateExamQuiz;
using AppLogic.Features.ExamTypes;
using AppLogic.Features.ExamTypes.GetAllExamTypes;
using AppLogic.Features.ExamTypes.CreateExamType;
using AppLogic.Features.ExamTypes.UpdateExamType;
using AppLogic.Features.FlashCards;
using AppLogic.Features.FlashCards.GetAllFlashCards;
using AppLogic.Features.FlashCards.CreateFlashCard;
using AppLogic.Features.FlashCards.UpdateFlashCard;
using AppLogic.Features.Quizzes;
using AppLogic.Features.Quizzes.GetAllQuizzes;
using AppLogic.Features.Quizzes.CreateQuiz;
using AppLogic.Features.Quizzes.UpdateQuiz;
using AppLogic.Features.QuizSessions;
using AppLogic.Features.QuizSessions.GetAllQuizSessions;
using AppLogic.Features.QuizSessions.CreateQuizSession;
using AppLogic.Features.QuizSessions.UpdateQuizSession;

using Domain.Auth;
using Domain.Entities;

namespace AppLogic.MappingProfiles;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<AppUser, GetAppUserResponse>().ReverseMap();
        CreateMap<CreateAppUserRequest, AppUser>();
        CreateMap<UpdateAppUserRequest, AppUser>();

        CreateMap<Exam, GetExamResponse>().ReverseMap();
        CreateMap<CreateExamRequest, Exam>();
        CreateMap<UpdateExamRequest, Exam>();

        CreateMap<ExamQuiz, GetExamQuizResponse>().ReverseMap();
        CreateMap<CreateExamQuizRequest, ExamQuiz>();
        CreateMap<UpdateExamQuizRequest, ExamQuiz>();

        CreateMap<ExamType, GetExamTypeResponse>().ReverseMap();
        CreateMap<CreateExamTypeRequest, ExamType>();
        CreateMap<UpdateExamTypeRequest, ExamType>();

        CreateMap<FlashCard, GetFlashCardResponse>().ReverseMap();
        CreateMap<CreateFlashCardRequest, FlashCard>();
        CreateMap<UpdateFlashCardRequest, FlashCard>();

        CreateMap<Quiz, GetQuizResponse>().ReverseMap();
        CreateMap<CreateQuizRequest, Quiz>();
        CreateMap<UpdateQuizRequest, Quiz>();

        CreateMap<QuizSession, GetQuizSessionResponse>().ReverseMap();
        CreateMap<CreateQuizSessionRequest, QuizSession>();
        CreateMap<UpdateQuizSessionRequest, QuizSession>();


    }
}