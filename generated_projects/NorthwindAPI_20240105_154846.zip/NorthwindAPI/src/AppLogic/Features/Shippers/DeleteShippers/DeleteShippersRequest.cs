using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Shippers.DeleteShippers;

//public record DeleteShippersRequest : IRequest<OneOf<GetShippersResponse, ShippersNotFound>>
//public record DeleteShippersRequest : IRequest<OneOf<bool, ShippersNotFound>>

public record DeleteShippersRequest(Int32? ShipperID) : IRequest<OneOf<bool, ShippersNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
