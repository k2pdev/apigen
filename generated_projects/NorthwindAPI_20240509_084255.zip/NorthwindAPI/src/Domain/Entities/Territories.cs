
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(TerritoryID),        nameof(TerritoryDescription),        nameof(RegionID))]
  public partial class Territories
  {
    public String? TerritoryID {get; set;} = null!;
    public String? TerritoryDescription {get; set;} = null!;
    public Int32? RegionID {get; set;}
  }


