using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Suppliers.CreateSuppliers;

public class CreateSuppliersHandler : IRequestHandler<CreateSuppliersRequest, GetSuppliersResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateSuppliersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetSuppliersResponse?> Handle(CreateSuppliersRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.Suppliers>(request);
        _context.Suppliers.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetSuppliersResponse?>(created);
    }
}