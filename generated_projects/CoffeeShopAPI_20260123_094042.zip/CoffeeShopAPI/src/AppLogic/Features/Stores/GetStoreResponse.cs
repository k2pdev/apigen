using Domain.Entities.Common;
using System;

namespace AppLogic.Features.Stores;

public record GetStoreResponse
{
    public Int32? Id {get; set;}
    public String? Name {get; set;} = null!;
}



