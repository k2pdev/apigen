using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Categories.CreateCategories;

public record CreateCategoriesRequest : IRequest<GetCategoriesResponse>
{
    public String? CategoryName {get; set;} = null!;
    public String? Description {get; set;}
    public System.Byte[]? Picture {get; set;} = null!;
}