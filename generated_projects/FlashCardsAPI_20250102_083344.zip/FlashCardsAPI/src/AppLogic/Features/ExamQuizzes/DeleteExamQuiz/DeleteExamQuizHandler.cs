using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ExamQuizzes.DeleteExamQuiz;

public class DeleteExamQuizHandler : IRequestHandler<DeleteExamQuizRequest, OneOf<bool, ExamQuizNotFound>>
{
    private readonly IContext _context;
    public DeleteExamQuizHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, ExamQuizNotFound>> Handle(DeleteExamQuizRequest request, CancellationToken cancellationToken)
    {
        var ExamQuiz = await _context.ExamQuiz.FirstOrDefaultAsync(x => x.ExamId == request.ExamId
 && x.QuizId == request.QuizId
);

        if (ExamQuiz is null) return new ExamQuizNotFound();

        _context.ExamQuiz.Remove(ExamQuiz);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
