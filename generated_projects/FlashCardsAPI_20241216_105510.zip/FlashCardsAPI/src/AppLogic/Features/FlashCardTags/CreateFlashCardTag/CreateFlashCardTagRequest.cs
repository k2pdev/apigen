using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.FlashCardTags.CreateFlashCardTag;

public record CreateFlashCardTagRequest : IRequest<GetFlashCardTagResponse>
{
    public Int32? FlashCardId {get; set;}
    public Int32? TagId {get; set;}
}