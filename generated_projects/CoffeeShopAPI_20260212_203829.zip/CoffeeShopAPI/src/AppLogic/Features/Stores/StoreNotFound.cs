using AppLogic.Common.Responses;

namespace AppLogic.Features.Stores;

public record StoreNotFound : NotFound {}