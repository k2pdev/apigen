using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Quizzes.GetAllQuizzes;

public class GetAllQuizzesHandler : IRequestHandler<GetAllQuizzesRequest, PaginatedList<GetQuizResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllQuizzesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetQuizResponse>> Handle(GetAllQuizzesRequest request, CancellationToken cancellationToken)
    {
        var Quiz = _context.Quiz;
        return await _mapper.ProjectTo<GetQuizResponse>(Quiz)
            .OrderBy(x => x.QuizName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    