using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Common;

public interface IContext : IAsyncDisposable, IDisposable
{
   public DatabaseFacade Database { get; }

    public DbSet<Categories> Categories { get; } 
    public DbSet<CustomerCustomerDemo> CustomerCustomerDemo { get; } 
    public DbSet<CustomerDemographics> CustomerDemographics { get; } 
    public DbSet<Customers> Customers { get; } 
    public DbSet<Employees> Employees { get; } 
    public DbSet<EmployeeTerritories> EmployeeTerritories { get; } 
    public DbSet<OrderDetails> OrderDetails { get; } 
    public DbSet<Orders> Orders { get; } 
    public DbSet<Products> Products { get; } 
    public DbSet<Region> Region { get; } 
    public DbSet<Shippers> Shippers { get; } 
    public DbSet<Suppliers> Suppliers { get; } 
    public DbSet<Territories> Territories { get; } 


    public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}