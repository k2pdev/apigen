using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Customers.GetAllCustomers;

public class GetAllCustomersHandler : IRequestHandler<GetAllCustomersRequest, PaginatedList<GetCustomerResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllCustomersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetCustomerResponse>> Handle(GetAllCustomersRequest request, CancellationToken cancellationToken)
    {
        var Customer = _context.Customer;
        return await _mapper.ProjectTo<GetCustomerResponse>(Customer)
            .OrderBy(x => x.FirstName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    