using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.AppUsers.CreateAppUser;

public record CreateAppUserRequest : IRequest<GetAppUserResponse>
{
    public String? UserName {get; set;} = null!;
    public String? FirstName {get; set;} = null!;
    public String? LastName {get; set;} = null!;
    public String? Email {get; set;} = null!;
}