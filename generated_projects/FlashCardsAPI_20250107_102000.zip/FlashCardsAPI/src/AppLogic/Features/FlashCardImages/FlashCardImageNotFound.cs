using AppLogic.Common.Responses;

namespace AppLogic.Features.FlashCardImages;

public record FlashCardImageNotFound : NotFound {}