using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Regions.CreateRegion;

public record CreateRegionRequest : IRequest<GetRegionResponse>
{
    public Int32? RegionID {get; set;}
    public String? RegionDescription {get; set;} = null!;
}