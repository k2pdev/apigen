using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.AppUsers.UpdateAppUser;

public class UpdateAppUserHandler : IRequestHandler<UpdateAppUserRequest, OneOf<GetAppUserResponse, AppUserNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateAppUserHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetAppUserResponse, AppUserNotFound>> Handle(UpdateAppUserRequest request,
        CancellationToken cancellationToken)
    {
        var updateAppUser = await _context.AppUser.FirstOrDefaultAsync(x => x.AppUserId == request.AppUserId
        , cancellationToken);
        if (updateAppUser == null) return new AppUserNotFound();


updateAppUser.AppUserId = request.AppUserId;
updateAppUser.UserName = request.UserName;
updateAppUser.FirstName = request.FirstName;
updateAppUser.LastName = request.LastName;
updateAppUser.Email = request.Email;


        _context.AppUser.Update(updateAppUser);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetAppUserResponse>(updateAppUser);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);