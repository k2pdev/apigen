using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.Stores.UpdateStore;

public record UpdateStoreRequest : IRequest<OneOf<GetStoreResponse, StoreNotFound>>
{
    public Int32? Id {get; set;}
    public String? Name {get; set;} = null!;
}   