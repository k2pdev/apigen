using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.ParkBoundaries.GetParkBoundariesById;

//ublic record GetParkBoundariesByIdRequest(Int32? id) : IRequest<OneOf<GetParkBoundariesResponse, ParkBoundariesNotFound>>;

public record GetParkBoundariesByIdRequest(Int32? ID) : IRequest<OneOf<GetParkBoundariesResponse, ParkBoundariesNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;