using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Quizzes.GetQuizById;

public class GetQuizByIdHandler : IRequestHandler<GetQuizByIdRequest, OneOf<GetQuizResponse, QuizNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetQuizByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetQuizResponse, QuizNotFound>> Handle(GetQuizByIdRequest request, CancellationToken cancellationToken)
    {
        //var Quiz = await _context.Quizzes.FirstOrDefaultAsync(x => x.QuizId == request.id,
          //  cancellationToken: cancellationToken);s
        var Quiz = await _context.Quiz.FirstOrDefaultAsync(x => x.QuizId == request.QuizId
);

        if (Quiz is null) return new QuizNotFound();
        return _mapper.Map<GetQuizResponse>(Quiz);
    }
}
