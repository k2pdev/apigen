using AppLogic.Common.Responses;

namespace AppLogic.Features.Territories;

public record TerritoriesNotFound : NotFound {}