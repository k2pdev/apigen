using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Categories.GetCategoriesById;

//ublic record GetCategoriesByIdRequest(Int32? id) : IRequest<OneOf<GetCategoriesResponse, CategoriesNotFound>>;

public record GetCategoriesByIdRequest(Int32? CategoryID) : IRequest<OneOf<GetCategoriesResponse, CategoriesNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;