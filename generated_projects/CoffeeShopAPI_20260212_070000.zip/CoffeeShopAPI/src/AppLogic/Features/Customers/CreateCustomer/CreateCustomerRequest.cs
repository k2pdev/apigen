using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Customers.CreateCustomer;

public record CreateCustomerRequest : IRequest<GetCustomerResponse>
{
    public Guid? CustomerId {get; set;}
    public String? FirstName {get; set;} = null!;
    public String? LastName {get; set;} = null!;
}