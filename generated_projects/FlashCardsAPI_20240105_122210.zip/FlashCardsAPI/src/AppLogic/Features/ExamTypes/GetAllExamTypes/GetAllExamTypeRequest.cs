using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.ExamTypes.GetAllExamTypes;

public record GetAllExamTypesRequest : PaginatedRequest, IRequest<PaginatedList<GetExamTypeResponse>>;