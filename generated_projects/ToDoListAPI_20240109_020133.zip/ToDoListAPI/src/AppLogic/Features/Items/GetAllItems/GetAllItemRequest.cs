using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Items.GetAllItems;

public record GetAllItemsRequest : PaginatedRequest, IRequest<PaginatedList<GetItemResponse>>;