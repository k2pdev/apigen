
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(FlashCardId))]
  public partial class FlashCard
  {
    public Int32? FlashCardId {get; set;}
    public Int32? QuizId {get; set;}
    public String? QuestionContent {get; set;} = null!;
    public String? AnswerContent {get; set;} = null!;
    public Int32? QuizSectionId {get; set;}
  }


