using Domain.Entities.Common;
using System;

namespace AppLogic.Features.QuizSections;

public record GetQuizSectionResponse
{
    public Int32? QuizSectionId {get; set;}
    public Int32? QuizId {get; set;}
    public String? SectionName {get; set;} = null!;
}



