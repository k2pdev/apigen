using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Tags.CreateTag;

public class CreateTagHandler : IRequestHandler<CreateTagRequest, GetTagResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateTagHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetTagResponse?> Handle(CreateTagRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.Tag>(request);
        _context.Tag.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetTagResponse?>(created);
    }
}