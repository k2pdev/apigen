using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Stores.GetStoreById;

//ublic record GetStoreByIdRequest(Int32? id) : IRequest<OneOf<GetStoreResponse, StoreNotFound>>;

public record GetStoreByIdRequest(Int32? Id) : IRequest<OneOf<GetStoreResponse, StoreNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;