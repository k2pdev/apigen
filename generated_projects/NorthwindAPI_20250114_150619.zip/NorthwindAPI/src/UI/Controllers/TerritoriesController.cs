using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Territories.GetAllTerritories;
using AppLogic.Features.Territories.GetTerritoriesById;
using AppLogic.Features.Territories.CreateTerritories;
using AppLogic.Features.Territories.UpdateTerritories;
using AppLogic.Features.Territories.DeleteTerritories;
using AppLogic.Features.Territories;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class TerritoriesController : ControllerBase
{
  private readonly IMediator _mediator;
  public TerritoriesController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllTerritories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetTerritoriesResponse>>> GetAllTerritories([FromQuery] GetAllTerritoriesRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetTerritoriesById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetTerritoriesById(String? _TerritoryID,String? _TerritoryDescription,Int32? _RegionID)
  {
    var result = await _mediator.Send(new GetTerritoriesByIdRequest(_TerritoryID,_TerritoryDescription,_RegionID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateTerritories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetTerritoriesResponse> CreateTerritories([FromBody] CreateTerritoriesRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateTerritories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateTerritories(String? _TerritoryID,String? _TerritoryDescription,Int32? _RegionID, [FromBody] UpdateTerritoriesRequest req)
  {
      var result = await _mediator.Send(req with {TerritoryID = _TerritoryID,TerritoryDescription = _TerritoryDescription,RegionID = _RegionID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteTerritories")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteTerritories(String? _TerritoryID,String? _TerritoryDescription,Int32? _RegionID)
  {
      var result = await _mediator.Send(new DeleteTerritoriesRequest( _TerritoryID, _TerritoryDescription, _RegionID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}