using Domain.Entities.Common;
using System;

namespace AppLogic.Features.AppUsers;

public record GetAppUserResponse
{
    public Int32? AppUserId {get; set;}
    public String? UserName {get; set;} = null!;
    public String? FirstName {get; set;} = null!;
    public String? LastName {get; set;} = null!;
    public String? Email {get; set;} = null!;
}



