using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.CustomerCustomerDemos.GetCustomerCustomerDemoById;

//ublic record GetCustomerCustomerDemoByIdRequest(Int32? id) : IRequest<OneOf<GetCustomerCustomerDemoResponse, CustomerCustomerDemoNotFound>>;

public record GetCustomerCustomerDemoByIdRequest(String? CustomerID,String? CustomerTypeID) : IRequest<OneOf<GetCustomerCustomerDemoResponse, CustomerCustomerDemoNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;