using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Tags.CreateTag;

public record CreateTagRequest : IRequest<GetTagResponse>
{
    public Int32? TagId {get; set;}
    public String? TagName {get; set;} = null!;
}