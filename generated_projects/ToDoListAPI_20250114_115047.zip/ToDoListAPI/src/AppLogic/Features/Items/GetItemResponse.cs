using Domain.Entities.Common;
using System;

namespace AppLogic.Features.Items;

public record GetItemResponse
{
    public Int32? ID {get; set;}
    public String? ItemName {get; set;} = null!;
    public String? Description {get; set;}
    public String? DueDttm {get; set;}
}



