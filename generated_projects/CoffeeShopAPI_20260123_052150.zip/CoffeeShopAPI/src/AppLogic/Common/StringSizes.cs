﻿namespace AppLogic.Common;

public static class StringSizes
{
    public const int Max = 4000;
}