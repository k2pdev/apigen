using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.ParkBoundaries.UpdateParkBoundaries;

public class UpdateParkBoundariesHandler : IRequestHandler<UpdateParkBoundariesRequest, OneOf<GetParkBoundariesResponse, ParkBoundariesNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateParkBoundariesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetParkBoundariesResponse, ParkBoundariesNotFound>> Handle(UpdateParkBoundariesRequest request,
        CancellationToken cancellationToken)
    {
        var updateParkBoundaries = await _context.ParkBoundaries.FirstOrDefaultAsync(x => x.ID == request.ID
        , cancellationToken);
        if (updateParkBoundaries == null) return new ParkBoundariesNotFound();


updateParkBoundaries.ID = request.ID;
updateParkBoundaries.Name = request.Name;
updateParkBoundaries.BoundaryType = request.BoundaryType;
updateParkBoundaries.geom = request.geom;


        _context.ParkBoundaries.Update(updateParkBoundaries);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetParkBoundariesResponse>(updateParkBoundaries);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);