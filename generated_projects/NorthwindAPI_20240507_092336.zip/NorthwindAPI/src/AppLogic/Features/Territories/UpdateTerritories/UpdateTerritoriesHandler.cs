using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Territories.UpdateTerritories;

public class UpdateTerritoriesHandler : IRequestHandler<UpdateTerritoriesRequest, OneOf<GetTerritoriesResponse, TerritoriesNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateTerritoriesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetTerritoriesResponse, TerritoriesNotFound>> Handle(UpdateTerritoriesRequest request,
        CancellationToken cancellationToken)
    {
        var updateTerritories = await _context.Territories.FirstOrDefaultAsync(x => x.TerritoryID == request.TerritoryID
 && x.TerritoryDescription == request.TerritoryDescription
 && x.RegionID == request.RegionID
        , cancellationToken);
        if (updateTerritories == null) return new TerritoriesNotFound();


updateTerritories.TerritoryID = request.TerritoryID;
updateTerritories.TerritoryDescription = request.TerritoryDescription;
updateTerritories.RegionID = request.RegionID;


        _context.Territories.Update(updateTerritories);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetTerritoriesResponse>(updateTerritories);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);