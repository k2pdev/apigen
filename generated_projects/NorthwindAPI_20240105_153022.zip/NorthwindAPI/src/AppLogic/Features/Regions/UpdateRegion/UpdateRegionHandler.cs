using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Regions.UpdateRegion;

public class UpdateRegionHandler : IRequestHandler<UpdateRegionRequest, OneOf<GetRegionResponse, RegionNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateRegionHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetRegionResponse, RegionNotFound>> Handle(UpdateRegionRequest request,
        CancellationToken cancellationToken)
    {
        var updateRegion = await _context.Region.FirstOrDefaultAsync(x => x.RegionID == request.RegionID
 && x.RegionDescription == request.RegionDescription
        , cancellationToken);
        if (updateRegion == null) return new RegionNotFound();


updateRegion.RegionID = request.RegionID;
updateRegion.RegionDescription = request.RegionDescription;


        _context.Region.Update(updateRegion);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetRegionResponse>(updateRegion);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);