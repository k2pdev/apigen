using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.Regions.UpdateRegion;

public record UpdateRegionRequest : IRequest<OneOf<GetRegionResponse, RegionNotFound>>
{
    public Int32? RegionID {get; set;}
    public String? RegionDescription {get; set;} = null!;
}   