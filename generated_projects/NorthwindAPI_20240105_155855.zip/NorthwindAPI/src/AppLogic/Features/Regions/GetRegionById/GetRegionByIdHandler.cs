using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Regions.GetRegionById;

public class GetRegionByIdHandler : IRequestHandler<GetRegionByIdRequest, OneOf<GetRegionResponse, RegionNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetRegionByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetRegionResponse, RegionNotFound>> Handle(GetRegionByIdRequest request, CancellationToken cancellationToken)
    {
        //var Region = await _context.Regions.FirstOrDefaultAsync(x => x.RegionId == request.id,
          //  cancellationToken: cancellationToken);s
        var Region = await _context.Region.FirstOrDefaultAsync(x => x.RegionID == request.RegionID
 && x.RegionDescription == request.RegionDescription
);

        if (Region is null) return new RegionNotFound();
        return _mapper.Map<GetRegionResponse>(Region);
    }
}
