using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Shippers.UpdateShippers;

public class UpdateShippersHandler : IRequestHandler<UpdateShippersRequest, OneOf<GetShippersResponse, ShippersNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateShippersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetShippersResponse, ShippersNotFound>> Handle(UpdateShippersRequest request,
        CancellationToken cancellationToken)
    {
        var updateShippers = await _context.Shippers.FirstOrDefaultAsync(x => x.ShipperID == request.ShipperID
        , cancellationToken);
        if (updateShippers == null) return new ShippersNotFound();


updateShippers.ShipperID = request.ShipperID;
updateShippers.CompanyName = request.CompanyName;
updateShippers.Phone = request.Phone;


        _context.Shippers.Update(updateShippers);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetShippersResponse>(updateShippers);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);