using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Categories.GetAllCategories;

public class GetAllCategoriesHandler : IRequestHandler<GetAllCategoriesRequest, PaginatedList<GetCategoriesResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllCategoriesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetCategoriesResponse>> Handle(GetAllCategoriesRequest request, CancellationToken cancellationToken)
    {
        var Categories = _context.Categories;
        return await _mapper.ProjectTo<GetCategoriesResponse>(Categories)
            .OrderBy(x => x.CategoryName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    