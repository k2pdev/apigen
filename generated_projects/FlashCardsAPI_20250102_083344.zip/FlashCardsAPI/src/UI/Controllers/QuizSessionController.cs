using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.QuizSessions.GetAllQuizSessions;
using AppLogic.Features.QuizSessions.GetQuizSessionById;
using AppLogic.Features.QuizSessions.CreateQuizSession;
using AppLogic.Features.QuizSessions.UpdateQuizSession;
using AppLogic.Features.QuizSessions.DeleteQuizSession;
using AppLogic.Features.QuizSessions;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class QuizSessionController : ControllerBase
{
  private readonly IMediator _mediator;
  public QuizSessionController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllQuizSessions")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetQuizSessionResponse>>> GetAllQuizSessions([FromQuery] GetAllQuizSessionsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetQuizSessionById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetQuizSessionById(Int32? _QuizSessionId)
  {
    var result = await _mediator.Send(new GetQuizSessionByIdRequest(_QuizSessionId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateQuizSession")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetQuizSessionResponse> CreateQuizSession([FromBody] CreateQuizSessionRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateQuizSession")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateQuizSession(Int32? _QuizSessionId, [FromBody] UpdateQuizSessionRequest req)
  {
      var result = await _mediator.Send(req with {QuizSessionId = _QuizSessionId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteQuizSession")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteQuizSession(Int32? _QuizSessionId)
  {
      var result = await _mediator.Send(new DeleteQuizSessionRequest( _QuizSessionId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}