using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.EmployeeTerritories.CreateEmployeeTerritories;

public record CreateEmployeeTerritoriesRequest : IRequest<GetEmployeeTerritoriesResponse>
{
    public Int32? EmployeeID {get; set;}
    public String? TerritoryID {get; set;} = null!;
}