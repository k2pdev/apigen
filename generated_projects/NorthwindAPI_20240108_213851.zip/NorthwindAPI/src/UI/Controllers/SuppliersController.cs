using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Suppliers.GetAllSuppliers;
using AppLogic.Features.Suppliers.GetSuppliersById;
using AppLogic.Features.Suppliers.CreateSuppliers;
using AppLogic.Features.Suppliers.UpdateSuppliers;
using AppLogic.Features.Suppliers.DeleteSuppliers;
using AppLogic.Features.Suppliers;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class SuppliersController : ControllerBase
{
  private readonly IMediator _mediator;
  public SuppliersController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllSuppliers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetSuppliersResponse>>> GetAllSuppliers([FromQuery] GetAllSuppliersRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetSuppliersById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetSuppliersById(Int32? _SupplierID)
  {
    var result = await _mediator.Send(new GetSuppliersByIdRequest(_SupplierID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateSuppliers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetSuppliersResponse> CreateSuppliers([FromBody] CreateSuppliersRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateSuppliers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateSuppliers(Int32? _SupplierID, [FromBody] UpdateSuppliersRequest req)
  {
      var result = await _mediator.Send(req with {SupplierID = _SupplierID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteSuppliers")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteSuppliers(Int32? _SupplierID)
  {
      var result = await _mediator.Send(new DeleteSuppliersRequest( _SupplierID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}