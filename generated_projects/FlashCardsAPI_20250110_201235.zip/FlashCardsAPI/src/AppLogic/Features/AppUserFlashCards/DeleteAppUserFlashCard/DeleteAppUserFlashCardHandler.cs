using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.AppUserFlashCards.DeleteAppUserFlashCard;

public class DeleteAppUserFlashCardHandler : IRequestHandler<DeleteAppUserFlashCardRequest, OneOf<bool, AppUserFlashCardNotFound>>
{
    private readonly IContext _context;
    public DeleteAppUserFlashCardHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, AppUserFlashCardNotFound>> Handle(DeleteAppUserFlashCardRequest request, CancellationToken cancellationToken)
    {
        var AppUserFlashCard = await _context.AppUserFlashCard.FirstOrDefaultAsync(x => x.AppUserFlashCardId == request.AppUserFlashCardId
);

        if (AppUserFlashCard is null) return new AppUserFlashCardNotFound();

        _context.AppUserFlashCard.Remove(AppUserFlashCard);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
