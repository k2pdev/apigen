using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Suppliers.DeleteSuppliers;

//public record DeleteSuppliersRequest : IRequest<OneOf<GetSuppliersResponse, SuppliersNotFound>>
//public record DeleteSuppliersRequest : IRequest<OneOf<bool, SuppliersNotFound>>

public record DeleteSuppliersRequest(Int32? SupplierID) : IRequest<OneOf<bool, SuppliersNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
