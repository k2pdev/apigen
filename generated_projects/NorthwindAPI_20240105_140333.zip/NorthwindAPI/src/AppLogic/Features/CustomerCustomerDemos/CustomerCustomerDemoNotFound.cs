using AppLogic.Common.Responses;

namespace AppLogic.Features.CustomerCustomerDemos;

public record CustomerCustomerDemoNotFound : NotFound {}