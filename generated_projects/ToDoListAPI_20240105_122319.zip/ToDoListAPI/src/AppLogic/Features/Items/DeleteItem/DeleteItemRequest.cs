using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Items.DeleteItem;

//public record DeleteItemRequest : IRequest<OneOf<GetItemResponse, ItemNotFound>>
//public record DeleteItemRequest : IRequest<OneOf<bool, ItemNotFound>>

public record DeleteItemRequest(Int32? ID) : IRequest<OneOf<bool, ItemNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
