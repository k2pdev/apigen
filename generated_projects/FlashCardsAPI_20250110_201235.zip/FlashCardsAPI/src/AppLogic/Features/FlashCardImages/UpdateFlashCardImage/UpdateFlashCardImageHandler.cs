using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.FlashCardImages.UpdateFlashCardImage;

public class UpdateFlashCardImageHandler : IRequestHandler<UpdateFlashCardImageRequest, OneOf<GetFlashCardImageResponse, FlashCardImageNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateFlashCardImageHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetFlashCardImageResponse, FlashCardImageNotFound>> Handle(UpdateFlashCardImageRequest request,
        CancellationToken cancellationToken)
    {
        var updateFlashCardImage = await _context.FlashCardImage.FirstOrDefaultAsync(x => x.FlashCardId == request.FlashCardId
        , cancellationToken);
        if (updateFlashCardImage == null) return new FlashCardImageNotFound();


updateFlashCardImage.FlashCardId = request.FlashCardId;
updateFlashCardImage.Image = request.Image;


        _context.FlashCardImage.Update(updateFlashCardImage);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetFlashCardImageResponse>(updateFlashCardImage);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);