using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.CustomerDemographics.GetCustomerDemographicsById;

public class GetCustomerDemographicsByIdHandler : IRequestHandler<GetCustomerDemographicsByIdRequest, OneOf<GetCustomerDemographicsResponse, CustomerDemographicsNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetCustomerDemographicsByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetCustomerDemographicsResponse, CustomerDemographicsNotFound>> Handle(GetCustomerDemographicsByIdRequest request, CancellationToken cancellationToken)
    {
        //var CustomerDemographics = await _context.CustomerDemographics.FirstOrDefaultAsync(x => x.CustomerDemographicsId == request.id,
          //  cancellationToken: cancellationToken);s
        var CustomerDemographics = await _context.CustomerDemographics.FirstOrDefaultAsync(x => x.CustomerTypeID == request.CustomerTypeID
 && x.CustomerDesc == request.CustomerDesc
);

        if (CustomerDemographics is null) return new CustomerDemographicsNotFound();
        return _mapper.Map<GetCustomerDemographicsResponse>(CustomerDemographics);
    }
}
