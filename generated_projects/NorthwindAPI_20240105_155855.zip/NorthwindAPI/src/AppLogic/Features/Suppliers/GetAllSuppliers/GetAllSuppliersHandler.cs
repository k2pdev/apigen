using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Suppliers.GetAllSuppliers;

public class GetAllSuppliersHandler : IRequestHandler<GetAllSuppliersRequest, PaginatedList<GetSuppliersResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllSuppliersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetSuppliersResponse>> Handle(GetAllSuppliersRequest request, CancellationToken cancellationToken)
    {
        var Suppliers = _context.Suppliers;
        return await _mapper.ProjectTo<GetSuppliersResponse>(Suppliers)
            .OrderBy(x => x.CompanyName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    