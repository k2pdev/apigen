
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(CustomerId))]
  public partial class Customer
  {
    public Guid? CustomerId {get; set;}
    public String? FirstName {get; set;} = null!;
    public String? LastName {get; set;} = null!;
  }


