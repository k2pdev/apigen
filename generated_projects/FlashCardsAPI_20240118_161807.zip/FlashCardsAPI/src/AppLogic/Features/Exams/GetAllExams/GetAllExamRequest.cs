using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Exams.GetAllExams;

public record GetAllExamsRequest : PaginatedRequest, IRequest<PaginatedList<GetExamResponse>>;