
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(CustomerTypeID),        nameof(CustomerDesc))]
  public partial class CustomerDemographics
  {
    public String? CustomerTypeID {get; set;} = null!;
    public String? CustomerDesc {get; set;}
  }


