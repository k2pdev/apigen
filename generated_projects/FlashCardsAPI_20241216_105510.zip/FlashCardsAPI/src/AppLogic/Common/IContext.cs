using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Common;

public interface IContext : IAsyncDisposable, IDisposable
{
   public DatabaseFacade Database { get; }

    public DbSet<AppUser> AppUser { get; } 
    public DbSet<AppUserFlashCard> AppUserFlashCard { get; } 
    public DbSet<Exam> Exam { get; } 
    public DbSet<ExamQuiz> ExamQuiz { get; } 
    public DbSet<ExamType> ExamType { get; } 
    public DbSet<FlashCard> FlashCard { get; } 
    public DbSet<FlashCardImage> FlashCardImage { get; } 
    public DbSet<FlashCardTag> FlashCardTag { get; } 
    public DbSet<Quiz> Quiz { get; } 
    public DbSet<QuizSection> QuizSection { get; } 
    public DbSet<QuizSession> QuizSession { get; } 
    public DbSet<Tag> Tag { get; } 


    public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}