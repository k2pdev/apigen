using AppLogic.Common.Responses;

namespace AppLogic.Features.ExamTypes;

public record ExamTypeNotFound : NotFound {}