using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Quizzes.DeleteQuiz;

//public record DeleteQuizRequest : IRequest<OneOf<GetQuizResponse, QuizNotFound>>
//public record DeleteQuizRequest : IRequest<OneOf<bool, QuizNotFound>>

public record DeleteQuizRequest(Int32? QuizId) : IRequest<OneOf<bool, QuizNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
