using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.CustomerCustomerDemos.GetCustomerCustomerDemoById;

public class GetCustomerCustomerDemoByIdHandler : IRequestHandler<GetCustomerCustomerDemoByIdRequest, OneOf<GetCustomerCustomerDemoResponse, CustomerCustomerDemoNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetCustomerCustomerDemoByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetCustomerCustomerDemoResponse, CustomerCustomerDemoNotFound>> Handle(GetCustomerCustomerDemoByIdRequest request, CancellationToken cancellationToken)
    {
        //var CustomerCustomerDemo = await _context.CustomerCustomerDemos.FirstOrDefaultAsync(x => x.CustomerCustomerDemoId == request.id,
          //  cancellationToken: cancellationToken);s
        var CustomerCustomerDemo = await _context.CustomerCustomerDemo.FirstOrDefaultAsync(x => x.CustomerID == request.CustomerID
 && x.CustomerTypeID == request.CustomerTypeID
);

        if (CustomerCustomerDemo is null) return new CustomerCustomerDemoNotFound();
        return _mapper.Map<GetCustomerCustomerDemoResponse>(CustomerCustomerDemo);
    }
}
