using Domain.Entities;
using Domain.Entities.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configuration;

public class TerritoriesConfiguration : IEntityTypeConfiguration<Territories>
{
    public void Configure(EntityTypeBuilder<Territories> builder)
    {

    }
}