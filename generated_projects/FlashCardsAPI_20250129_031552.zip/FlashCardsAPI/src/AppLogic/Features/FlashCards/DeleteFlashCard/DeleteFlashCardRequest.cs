using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.FlashCards.DeleteFlashCard;

//public record DeleteFlashCardRequest : IRequest<OneOf<GetFlashCardResponse, FlashCardNotFound>>
//public record DeleteFlashCardRequest : IRequest<OneOf<bool, FlashCardNotFound>>

public record DeleteFlashCardRequest(Int32? FlashCardId) : IRequest<OneOf<bool, FlashCardNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
