using AutoMapper;
using AppLogic.Features.Categories;
using AppLogic.Features.Categories.GetAllCategories;
using AppLogic.Features.Categories.CreateCategories;
using AppLogic.Features.Categories.UpdateCategories;
using AppLogic.Features.CustomerCustomerDemos;
using AppLogic.Features.CustomerCustomerDemos.GetAllCustomerCustomerDemos;
using AppLogic.Features.CustomerCustomerDemos.CreateCustomerCustomerDemo;
using AppLogic.Features.CustomerCustomerDemos.UpdateCustomerCustomerDemo;
using AppLogic.Features.CustomerDemographics;
using AppLogic.Features.CustomerDemographics.GetAllCustomerDemographics;
using AppLogic.Features.CustomerDemographics.CreateCustomerDemographics;
using AppLogic.Features.CustomerDemographics.UpdateCustomerDemographics;
using AppLogic.Features.Customers;
using AppLogic.Features.Customers.GetAllCustomers;
using AppLogic.Features.Customers.CreateCustomers;
using AppLogic.Features.Customers.UpdateCustomers;
using AppLogic.Features.Employees;
using AppLogic.Features.Employees.GetAllEmployees;
using AppLogic.Features.Employees.CreateEmployees;
using AppLogic.Features.Employees.UpdateEmployees;
using AppLogic.Features.EmployeeTerritories;
using AppLogic.Features.EmployeeTerritories.GetAllEmployeeTerritories;
using AppLogic.Features.EmployeeTerritories.CreateEmployeeTerritories;
using AppLogic.Features.EmployeeTerritories.UpdateEmployeeTerritories;
using AppLogic.Features.OrderDetails;
using AppLogic.Features.OrderDetails.GetAllOrderDetails;
using AppLogic.Features.OrderDetails.CreateOrderDetails;
using AppLogic.Features.OrderDetails.UpdateOrderDetails;
using AppLogic.Features.Orders;
using AppLogic.Features.Orders.GetAllOrders;
using AppLogic.Features.Orders.CreateOrders;
using AppLogic.Features.Orders.UpdateOrders;
using AppLogic.Features.Products;
using AppLogic.Features.Products.GetAllProducts;
using AppLogic.Features.Products.CreateProducts;
using AppLogic.Features.Products.UpdateProducts;
using AppLogic.Features.Regions;
using AppLogic.Features.Regions.GetAllRegions;
using AppLogic.Features.Regions.CreateRegion;
using AppLogic.Features.Regions.UpdateRegion;
using AppLogic.Features.Shippers;
using AppLogic.Features.Shippers.GetAllShippers;
using AppLogic.Features.Shippers.CreateShippers;
using AppLogic.Features.Shippers.UpdateShippers;
using AppLogic.Features.Suppliers;
using AppLogic.Features.Suppliers.GetAllSuppliers;
using AppLogic.Features.Suppliers.CreateSuppliers;
using AppLogic.Features.Suppliers.UpdateSuppliers;
using AppLogic.Features.Territories;
using AppLogic.Features.Territories.GetAllTerritories;
using AppLogic.Features.Territories.CreateTerritories;
using AppLogic.Features.Territories.UpdateTerritories;

using Domain.Auth;
using Domain.Entities;

namespace AppLogic.MappingProfiles;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<Categories, GetCategoriesResponse>().ReverseMap();
        CreateMap<CreateCategoriesRequest, Categories>();
        CreateMap<UpdateCategoriesRequest, Categories>();

        CreateMap<CustomerCustomerDemo, GetCustomerCustomerDemoResponse>().ReverseMap();
        CreateMap<CreateCustomerCustomerDemoRequest, CustomerCustomerDemo>();
        CreateMap<UpdateCustomerCustomerDemoRequest, CustomerCustomerDemo>();

        CreateMap<CustomerDemographics, GetCustomerDemographicsResponse>().ReverseMap();
        CreateMap<CreateCustomerDemographicsRequest, CustomerDemographics>();
        CreateMap<UpdateCustomerDemographicsRequest, CustomerDemographics>();

        CreateMap<Customers, GetCustomersResponse>().ReverseMap();
        CreateMap<CreateCustomersRequest, Customers>();
        CreateMap<UpdateCustomersRequest, Customers>();

        CreateMap<Employees, GetEmployeesResponse>().ReverseMap();
        CreateMap<CreateEmployeesRequest, Employees>();
        CreateMap<UpdateEmployeesRequest, Employees>();

        CreateMap<EmployeeTerritories, GetEmployeeTerritoriesResponse>().ReverseMap();
        CreateMap<CreateEmployeeTerritoriesRequest, EmployeeTerritories>();
        CreateMap<UpdateEmployeeTerritoriesRequest, EmployeeTerritories>();

        CreateMap<OrderDetails, GetOrderDetailsResponse>().ReverseMap();
        CreateMap<CreateOrderDetailsRequest, OrderDetails>();
        CreateMap<UpdateOrderDetailsRequest, OrderDetails>();

        CreateMap<Orders, GetOrdersResponse>().ReverseMap();
        CreateMap<CreateOrdersRequest, Orders>();
        CreateMap<UpdateOrdersRequest, Orders>();

        CreateMap<Products, GetProductsResponse>().ReverseMap();
        CreateMap<CreateProductsRequest, Products>();
        CreateMap<UpdateProductsRequest, Products>();

        CreateMap<Region, GetRegionResponse>().ReverseMap();
        CreateMap<CreateRegionRequest, Region>();
        CreateMap<UpdateRegionRequest, Region>();

        CreateMap<Shippers, GetShippersResponse>().ReverseMap();
        CreateMap<CreateShippersRequest, Shippers>();
        CreateMap<UpdateShippersRequest, Shippers>();

        CreateMap<Suppliers, GetSuppliersResponse>().ReverseMap();
        CreateMap<CreateSuppliersRequest, Suppliers>();
        CreateMap<UpdateSuppliersRequest, Suppliers>();

        CreateMap<Territories, GetTerritoriesResponse>().ReverseMap();
        CreateMap<CreateTerritoriesRequest, Territories>();
        CreateMap<UpdateTerritoriesRequest, Territories>();


    }
}