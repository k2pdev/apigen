using Domain.Entities;
using Domain.Entities.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configuration;

public class ExamQuizConfiguration : IEntityTypeConfiguration<ExamQuiz>
{
    public void Configure(EntityTypeBuilder<ExamQuiz> builder)
    {
        builder.HasKey(x => x.ExamId);
        builder.Property(x => x.ExamId);
        builder.HasKey(x => x.QuizId);
        builder.Property(x => x.QuizId);

    }
}