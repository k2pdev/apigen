
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(ID))]
  public partial class ParkBoundaries
  {
    public Int32? ID {get; set;}
    public String? Name {get; set;} = null!;
    public String? BoundaryType {get; set;} = null!;
    public String? geom {get; set;}
  }


