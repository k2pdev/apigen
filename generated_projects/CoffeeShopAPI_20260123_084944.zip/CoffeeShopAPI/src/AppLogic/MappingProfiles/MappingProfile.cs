using AutoMapper;
using AppLogic.Features.Stores;
using AppLogic.Features.Stores.GetAllStores;
using AppLogic.Features.Stores.CreateStore;
using AppLogic.Features.Stores.UpdateStore;

using Domain.Auth;
using Domain.Entities;

namespace AppLogic.MappingProfiles;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<Store, GetStoreResponse>().ReverseMap();
        CreateMap<CreateStoreRequest, Store>();
        CreateMap<UpdateStoreRequest, Store>();


    }
}