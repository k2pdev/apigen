using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ParkBoundaries.GetAllParkBoundaries;

public class GetAllParkBoundariesHandler : IRequestHandler<GetAllParkBoundariesRequest, PaginatedList<GetParkBoundariesResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllParkBoundariesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetParkBoundariesResponse>> Handle(GetAllParkBoundariesRequest request, CancellationToken cancellationToken)
    {
        var ParkBoundaries = _context.ParkBoundaries;
        return await _mapper.ProjectTo<GetParkBoundariesResponse>(ParkBoundaries)
            .OrderBy(x => x.Name) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    