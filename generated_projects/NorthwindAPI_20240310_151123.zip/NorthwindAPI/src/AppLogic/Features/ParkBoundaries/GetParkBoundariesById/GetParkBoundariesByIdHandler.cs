using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.ParkBoundaries.GetParkBoundariesById;

public class GetParkBoundariesByIdHandler : IRequestHandler<GetParkBoundariesByIdRequest, OneOf<GetParkBoundariesResponse, ParkBoundariesNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetParkBoundariesByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetParkBoundariesResponse, ParkBoundariesNotFound>> Handle(GetParkBoundariesByIdRequest request, CancellationToken cancellationToken)
    {
        //var ParkBoundaries = await _context.ParkBoundaries.FirstOrDefaultAsync(x => x.ParkBoundariesId == request.id,
          //  cancellationToken: cancellationToken);s
        var ParkBoundaries = await _context.ParkBoundaries.FirstOrDefaultAsync(x => x.ID == request.ID
);

        if (ParkBoundaries is null) return new ParkBoundariesNotFound();
        return _mapper.Map<GetParkBoundariesResponse>(ParkBoundaries);
    }
}
