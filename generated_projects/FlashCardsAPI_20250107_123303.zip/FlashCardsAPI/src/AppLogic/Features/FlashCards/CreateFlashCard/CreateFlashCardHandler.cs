using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCards.CreateFlashCard;

public class CreateFlashCardHandler : IRequestHandler<CreateFlashCardRequest, GetFlashCardResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateFlashCardHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetFlashCardResponse?> Handle(CreateFlashCardRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.FlashCard>(request);
        _context.FlashCard.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetFlashCardResponse?>(created);
    }
}