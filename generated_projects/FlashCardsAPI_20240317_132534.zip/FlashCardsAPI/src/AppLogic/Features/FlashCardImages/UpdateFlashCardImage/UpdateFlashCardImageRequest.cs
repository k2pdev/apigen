using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.FlashCardImages.UpdateFlashCardImage;

public record UpdateFlashCardImageRequest : IRequest<OneOf<GetFlashCardImageResponse, FlashCardImageNotFound>>
{
    public Int32? FlashCardId {get; set;}
    public Int32? Image {get; set;}
}   