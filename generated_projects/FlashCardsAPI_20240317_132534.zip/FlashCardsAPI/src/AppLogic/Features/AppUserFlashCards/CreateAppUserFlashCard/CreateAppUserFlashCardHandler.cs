using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.AppUserFlashCards.CreateAppUserFlashCard;

public class CreateAppUserFlashCardHandler : IRequestHandler<CreateAppUserFlashCardRequest, GetAppUserFlashCardResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateAppUserFlashCardHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetAppUserFlashCardResponse?> Handle(CreateAppUserFlashCardRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.AppUserFlashCard>(request);
        _context.AppUserFlashCard.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetAppUserFlashCardResponse?>(created);
    }
}