using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Suppliers.DeleteSuppliers;

public class DeleteSuppliersHandler : IRequestHandler<DeleteSuppliersRequest, OneOf<bool, SuppliersNotFound>>
{
    private readonly IContext _context;
    public DeleteSuppliersHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, SuppliersNotFound>> Handle(DeleteSuppliersRequest request, CancellationToken cancellationToken)
    {
        var Suppliers = await _context.Suppliers.FirstOrDefaultAsync(x => x.SupplierID == request.SupplierID
);

        if (Suppliers is null) return new SuppliersNotFound();

        _context.Suppliers.Remove(Suppliers);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
