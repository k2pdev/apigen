using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Tags.GetTagById;

public class GetTagByIdHandler : IRequestHandler<GetTagByIdRequest, OneOf<GetTagResponse, TagNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetTagByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetTagResponse, TagNotFound>> Handle(GetTagByIdRequest request, CancellationToken cancellationToken)
    {
        //var Tag = await _context.Tags.FirstOrDefaultAsync(x => x.TagId == request.id,
          //  cancellationToken: cancellationToken);s
        var Tag = await _context.Tag.FirstOrDefaultAsync(x => x.TagId == request.TagId
 && x.TagName == request.TagName
);

        if (Tag is null) return new TagNotFound();
        return _mapper.Map<GetTagResponse>(Tag);
    }
}
