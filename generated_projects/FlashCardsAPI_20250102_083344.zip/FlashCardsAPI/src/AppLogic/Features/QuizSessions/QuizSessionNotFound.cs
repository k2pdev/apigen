using AppLogic.Common.Responses;

namespace AppLogic.Features.QuizSessions;

public record QuizSessionNotFound : NotFound {}