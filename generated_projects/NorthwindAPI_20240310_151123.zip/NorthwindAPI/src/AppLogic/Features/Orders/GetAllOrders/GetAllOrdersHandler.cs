using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Orders.GetAllOrders;

public class GetAllOrdersHandler : IRequestHandler<GetAllOrdersRequest, PaginatedList<GetOrdersResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllOrdersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetOrdersResponse>> Handle(GetAllOrdersRequest request, CancellationToken cancellationToken)
    {
        var Orders = _context.Orders;
        return await _mapper.ProjectTo<GetOrdersResponse>(Orders)
            .OrderBy(x => x.ShipName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    