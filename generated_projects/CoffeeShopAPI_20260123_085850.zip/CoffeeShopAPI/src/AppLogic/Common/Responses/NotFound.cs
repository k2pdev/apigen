﻿namespace AppLogic.Common.Responses;

public record NotFound();