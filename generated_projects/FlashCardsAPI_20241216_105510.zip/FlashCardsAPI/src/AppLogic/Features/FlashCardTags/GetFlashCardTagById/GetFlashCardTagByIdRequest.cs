using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.FlashCardTags.GetFlashCardTagById;

//ublic record GetFlashCardTagByIdRequest(Int32? id) : IRequest<OneOf<GetFlashCardTagResponse, FlashCardTagNotFound>>;

public record GetFlashCardTagByIdRequest(Int32? FlashCardId,Int32? TagId) : IRequest<OneOf<GetFlashCardTagResponse, FlashCardTagNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;