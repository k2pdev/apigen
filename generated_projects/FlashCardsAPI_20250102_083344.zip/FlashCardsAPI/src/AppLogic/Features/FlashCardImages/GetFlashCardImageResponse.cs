using Domain.Entities.Common;
using System;

namespace AppLogic.Features.FlashCardImages;

public record GetFlashCardImageResponse
{
    public Int32? FlashCardId {get; set;}
    public Int32? Image {get; set;}
}



