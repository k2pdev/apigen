using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.Stores.DeleteStore;

//public record DeleteStoreRequest : IRequest<OneOf<GetStoreResponse, StoreNotFound>>
//public record DeleteStoreRequest : IRequest<OneOf<bool, StoreNotFound>>

public record DeleteStoreRequest(Int32? Id) : IRequest<OneOf<bool, StoreNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
