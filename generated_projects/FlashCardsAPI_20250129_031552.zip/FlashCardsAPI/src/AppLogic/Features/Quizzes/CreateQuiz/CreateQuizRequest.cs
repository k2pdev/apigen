using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Quizzes.CreateQuiz;

public record CreateQuizRequest : IRequest<GetQuizResponse>
{
    public Int32? ParentQuizId {get; set;}
    public String? QuizName {get; set;} = null!;
}