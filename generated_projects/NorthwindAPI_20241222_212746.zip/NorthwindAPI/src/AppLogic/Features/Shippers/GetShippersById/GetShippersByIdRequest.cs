using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.Shippers.GetShippersById;

//ublic record GetShippersByIdRequest(Int32? id) : IRequest<OneOf<GetShippersResponse, ShippersNotFound>>;

public record GetShippersByIdRequest(Int32? ShipperID) : IRequest<OneOf<GetShippersResponse, ShippersNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;