using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.CustomerDemographics.CreateCustomerDemographics;

public record CreateCustomerDemographicsRequest : IRequest<GetCustomerDemographicsResponse>
{
    public String? CustomerTypeID {get; set;} = null!;
    public String? CustomerDesc {get; set;}
}