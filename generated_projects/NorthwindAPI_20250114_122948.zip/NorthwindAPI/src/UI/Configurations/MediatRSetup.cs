﻿using AppLogic.Common;
using AppLogic.Common.Behaviors;
using AppLogic.Common.Handlers;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace UI.Configurations;

public static class MediatRSetup
{
    public static IServiceCollection AddMediatRSetup(this IServiceCollection services)
    {
        services.AddMediatR(typeof(AppLogic.IAssemblyMarker).GetTypeInfo().Assembly);
        services.AddScoped<INotificationHandler<ValidationError>, ValidationErrorHandler>();
        services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidationPipelineBehavior<,>));

        return services;
    }
}