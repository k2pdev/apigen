using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.QuizSections.DeleteQuizSection;

public class DeleteQuizSectionHandler : IRequestHandler<DeleteQuizSectionRequest, OneOf<bool, QuizSectionNotFound>>
{
    private readonly IContext _context;
    public DeleteQuizSectionHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, QuizSectionNotFound>> Handle(DeleteQuizSectionRequest request, CancellationToken cancellationToken)
    {
        var QuizSection = await _context.QuizSection.FirstOrDefaultAsync(x => x.QuizSectionId == request.QuizSectionId
);

        if (QuizSection is null) return new QuizSectionNotFound();

        _context.QuizSection.Remove(QuizSection);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
