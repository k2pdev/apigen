using AppLogic.Common.Responses;

namespace AppLogic.Features.Quizzes;

public record QuizNotFound : NotFound {}