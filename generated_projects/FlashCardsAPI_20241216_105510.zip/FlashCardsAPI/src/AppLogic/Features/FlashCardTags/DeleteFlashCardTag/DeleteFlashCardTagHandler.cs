using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCardTags.DeleteFlashCardTag;

public class DeleteFlashCardTagHandler : IRequestHandler<DeleteFlashCardTagRequest, OneOf<bool, FlashCardTagNotFound>>
{
    private readonly IContext _context;
    public DeleteFlashCardTagHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, FlashCardTagNotFound>> Handle(DeleteFlashCardTagRequest request, CancellationToken cancellationToken)
    {
        var FlashCardTag = await _context.FlashCardTag.FirstOrDefaultAsync(x => x.FlashCardId == request.FlashCardId
 && x.TagId == request.TagId
);

        if (FlashCardTag is null) return new FlashCardTagNotFound();

        _context.FlashCardTag.Remove(FlashCardTag);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
