using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.FlashCardImages.GetAllFlashCardImages;

public class GetAllFlashCardImagesHandler : IRequestHandler<GetAllFlashCardImagesRequest, PaginatedList<GetFlashCardImageResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllFlashCardImagesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetFlashCardImageResponse>> Handle(GetAllFlashCardImagesRequest request, CancellationToken cancellationToken)
    {
        var FlashCardImage = _context.FlashCardImage;
        return await _mapper.ProjectTo<GetFlashCardImageResponse>(FlashCardImage)
            .OrderBy(x => x.Image) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    