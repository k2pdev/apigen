using AppLogic.Common.Requests;
using AppLogic.Common.Responses;
using MediatR;
using System;

namespace AppLogic.Features.Territories.GetAllTerritories;

public record GetAllTerritoriesRequest : PaginatedRequest, IRequest<PaginatedList<GetTerritoriesResponse>>;