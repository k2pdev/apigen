using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.OrderDetails.CreateOrderDetails;

public class CreateOrderDetailsHandler : IRequestHandler<CreateOrderDetailsRequest, GetOrderDetailsResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateOrderDetailsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetOrderDetailsResponse?> Handle(CreateOrderDetailsRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.OrderDetails>(request);
        _context.OrderDetails.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetOrderDetailsResponse?>(created);
    }
}