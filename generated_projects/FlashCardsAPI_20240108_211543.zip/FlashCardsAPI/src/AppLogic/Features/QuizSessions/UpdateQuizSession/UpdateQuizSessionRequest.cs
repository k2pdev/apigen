using Domain.Entities.Common;
using MediatR;
using OneOf;
using System.Text.Json.Serialization;
using System;

namespace AppLogic.Features.QuizSessions.UpdateQuizSession;

public record UpdateQuizSessionRequest : IRequest<OneOf<GetQuizSessionResponse, QuizSessionNotFound>>
{
    public Int32? QuizSessionId {get; set;}
    public Int32? QuizId {get; set;}
    public Int32? AppUserId {get; set;}
}   