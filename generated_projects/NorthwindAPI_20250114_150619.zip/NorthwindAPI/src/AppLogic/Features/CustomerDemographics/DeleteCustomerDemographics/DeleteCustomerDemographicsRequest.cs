using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.CustomerDemographics.DeleteCustomerDemographics;

//public record DeleteCustomerDemographicsRequest : IRequest<OneOf<GetCustomerDemographicsResponse, CustomerDemographicsNotFound>>
//public record DeleteCustomerDemographicsRequest : IRequest<OneOf<bool, CustomerDemographicsNotFound>>

public record DeleteCustomerDemographicsRequest(String? CustomerTypeID,String? CustomerDesc) : IRequest<OneOf<bool, CustomerDemographicsNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
