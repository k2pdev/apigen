using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.QuizSections.GetAllQuizSections;
using AppLogic.Features.QuizSections.GetQuizSectionById;
using AppLogic.Features.QuizSections.CreateQuizSection;
using AppLogic.Features.QuizSections.UpdateQuizSection;
using AppLogic.Features.QuizSections.DeleteQuizSection;
using AppLogic.Features.QuizSections;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class QuizSectionController : ControllerBase
{
  private readonly IMediator _mediator;
  public QuizSectionController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllQuizSections")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetQuizSectionResponse>>> GetAllQuizSections([FromQuery] GetAllQuizSectionsRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetQuizSectionById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetQuizSectionById(Int32? _QuizId,Int32? _SectionId)
  {
    var result = await _mediator.Send(new GetQuizSectionByIdRequest(_QuizId,_SectionId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateQuizSection")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetQuizSectionResponse> CreateQuizSection([FromBody] CreateQuizSectionRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateQuizSection")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateQuizSection(Int32? _QuizId,Int32? _SectionId, [FromBody] UpdateQuizSectionRequest req)
  {
      var result = await _mediator.Send(req with {QuizId = _QuizId,SectionId = _SectionId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteQuizSection")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteQuizSection(Int32? _QuizId,Int32? _SectionId)
  {
      var result = await _mediator.Send(new DeleteQuizSectionRequest( _QuizId, _SectionId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}