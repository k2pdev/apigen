using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.Products.UpdateProducts;

public class UpdateProductsHandler : IRequestHandler<UpdateProductsRequest, OneOf<GetProductsResponse, ProductsNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateProductsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetProductsResponse, ProductsNotFound>> Handle(UpdateProductsRequest request,
        CancellationToken cancellationToken)
    {
        var updateProducts = await _context.Products.FirstOrDefaultAsync(x => x.ProductID == request.ProductID
        , cancellationToken);
        if (updateProducts == null) return new ProductsNotFound();


updateProducts.ProductID = request.ProductID;
updateProducts.ProductName = request.ProductName;
updateProducts.SupplierID = request.SupplierID;
updateProducts.CategoryID = request.CategoryID;
updateProducts.QuantityPerUnit = request.QuantityPerUnit;
updateProducts.UnitPrice = request.UnitPrice;
updateProducts.UnitsInStock = request.UnitsInStock;
updateProducts.UnitsOnOrder = request.UnitsOnOrder;
updateProducts.ReorderLevel = request.ReorderLevel;
updateProducts.Discontinued = request.Discontinued;


        _context.Products.Update(updateProducts);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetProductsResponse>(updateProducts);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);