using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.ParkBoundaries.GetAllParkBoundaries;
using AppLogic.Features.ParkBoundaries.GetParkBoundariesById;
using AppLogic.Features.ParkBoundaries.CreateParkBoundaries;
using AppLogic.Features.ParkBoundaries.UpdateParkBoundaries;
using AppLogic.Features.ParkBoundaries.DeleteParkBoundaries;
using AppLogic.Features.ParkBoundaries;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class ParkBoundariesController : ControllerBase
{
  private readonly IMediator _mediator;
  public ParkBoundariesController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllParkBoundaries")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetParkBoundariesResponse>>> GetAllParkBoundaries([FromQuery] GetAllParkBoundariesRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetParkBoundariesById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetParkBoundariesById(Int32? _ID)
  {
    var result = await _mediator.Send(new GetParkBoundariesByIdRequest(_ID));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateParkBoundaries")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetParkBoundariesResponse> CreateParkBoundaries([FromBody] CreateParkBoundariesRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateParkBoundaries")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateParkBoundaries(Int32? _ID, [FromBody] UpdateParkBoundariesRequest req)
  {
      var result = await _mediator.Send(req with {ID = _ID});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteParkBoundaries")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteParkBoundaries(Int32? _ID)
  {
      var result = await _mediator.Send(new DeleteParkBoundariesRequest( _ID)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}