using MediatR;
using System;
using System.Collections.Generic;

namespace AppLogic.Features.Suppliers.CreateSuppliers;

public record CreateSuppliersRequest : IRequest<GetSuppliersResponse>
{
    public String? CompanyName {get; set;} = null!;
    public String? ContactName {get; set;} = null!;
    public String? ContactTitle {get; set;} = null!;
    public String? Address {get; set;} = null!;
    public String? City {get; set;} = null!;
    public String? Region {get; set;} = null!;
    public String? PostalCode {get; set;} = null!;
    public String? Country {get; set;} = null!;
    public String? Phone {get; set;} = null!;
    public String? Fax {get; set;} = null!;
    public String? HomePage {get; set;}
}