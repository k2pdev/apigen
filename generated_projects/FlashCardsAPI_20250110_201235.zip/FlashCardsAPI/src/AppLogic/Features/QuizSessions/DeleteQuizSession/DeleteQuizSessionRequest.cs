using Domain.Entities.Common;
using MediatR;
using OneOf;
using AppLogic.Common;
using System;
using System.Text.Json.Serialization;

namespace AppLogic.Features.QuizSessions.DeleteQuizSession;

//public record DeleteQuizSessionRequest : IRequest<OneOf<GetQuizSessionResponse, QuizSessionNotFound>>
//public record DeleteQuizSessionRequest : IRequest<OneOf<bool, QuizSessionNotFound>>

public record DeleteQuizSessionRequest(Int32? QuizSessionId) : IRequest<OneOf<bool, QuizSessionNotFound>>;
// {
// __//PrimaryKeyProperties__
// }   
