
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(FlashCardId))]
  public partial class FlashCardImage
  {
    public Int32? FlashCardId {get; set;}
    public Int32? Image {get; set;}
  }


