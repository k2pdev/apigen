
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(ExamTypeId))]
  public partial class ExamType
  {
    public Int32? ExamTypeId {get; set;}
    public String? ExamTypeName {get; set;} = null!;
  }


