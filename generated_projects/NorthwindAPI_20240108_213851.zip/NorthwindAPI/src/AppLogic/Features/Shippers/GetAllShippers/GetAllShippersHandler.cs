using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Shippers.GetAllShippers;

public class GetAllShippersHandler : IRequestHandler<GetAllShippersRequest, PaginatedList<GetShippersResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllShippersHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetShippersResponse>> Handle(GetAllShippersRequest request, CancellationToken cancellationToken)
    {
        var Shippers = _context.Shippers;
        return await _mapper.ProjectTo<GetShippersResponse>(Shippers)
            .OrderBy(x => x.CompanyName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    