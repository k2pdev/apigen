using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MediatR;
using AppLogic.Features.Quizzes.GetAllQuizzes;
using AppLogic.Features.Quizzes.GetQuizById;
using AppLogic.Features.Quizzes.CreateQuiz;
using AppLogic.Features.Quizzes.UpdateQuiz;
using AppLogic.Features.Quizzes.DeleteQuiz;
using AppLogic.Features.Quizzes;
using AppLogic.Common.Responses;

namespace UI.Controllers;

[ApiController]
[AllowAnonymous]
[Route("[controller]")]
[EnableCors]
public class QuizController : ControllerBase
{
  private readonly IMediator _mediator;
  public QuizController(IMediator mediator) { _mediator = mediator;}

  [HttpGet]
  [Route("GetAllQuizzes")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult<PaginatedList<GetQuizResponse>>> GetAllQuizzes([FromQuery] GetAllQuizzesRequest req)
  {
    var result = Ok(await _mediator.Send(req));
    return result;
  }

  [HttpGet]
  [Route("GetQuizById")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<ActionResult> GetQuizById(Int32? _QuizId)
  {
    var result = await _mediator.Send(new GetQuizByIdRequest(_QuizId));
    return result.Match<ActionResult>(
          valid => Ok(valid),
          notFound => NotFound()
      );
  }

  [HttpPost]
  [Route("CreateQuiz")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<GetQuizResponse> CreateQuiz([FromBody] CreateQuizRequest req)
  {
      var result = await _mediator.Send(req);
      return result;
  }

  [HttpPut]
  [Route("UpdateQuiz")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> UpdateQuiz(Int32? _QuizId, [FromBody] UpdateQuizRequest req)
  {
      var result = await _mediator.Send(req with {QuizId = _QuizId});
      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }

  [HttpDelete]
  [Route("DeleteQuiz")]
  [EnableCors]
  [Produces("application/json")]
  public async Task<IActionResult> DeleteQuiz(Int32? _QuizId)
  {
      var result = await _mediator.Send(new DeleteQuizRequest( _QuizId)); 

      return result.Match<IActionResult>(
          valid => NoContent(),
          notFound => NotFound()
      );
  }
}