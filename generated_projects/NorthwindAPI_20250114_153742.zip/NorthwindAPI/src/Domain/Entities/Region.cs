
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(RegionID),        nameof(RegionDescription))]
  public partial class Region
  {
    public Int32? RegionID {get; set;}
    public String? RegionDescription {get; set;} = null!;
  }


