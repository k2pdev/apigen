
  using Domain.Entities.Common;
  using MassTransit;
  using System;
  using Microsoft.EntityFrameworkCore;

  namespace Domain.Entities;

    [PrimaryKey(        nameof(EmployeeID),        nameof(TerritoryID))]
  public partial class EmployeeTerritories
  {
    public Int32? EmployeeID {get; set;}
    public String? TerritoryID {get; set;} = null!;
  }


