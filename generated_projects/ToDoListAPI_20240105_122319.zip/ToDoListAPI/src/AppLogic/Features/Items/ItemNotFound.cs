using AppLogic.Common.Responses;

namespace AppLogic.Features.Items;

public record ItemNotFound : NotFound {}