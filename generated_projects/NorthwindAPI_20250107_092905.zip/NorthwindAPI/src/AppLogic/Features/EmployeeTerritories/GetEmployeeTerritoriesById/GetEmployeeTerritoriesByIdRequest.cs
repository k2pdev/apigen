using System;
using Domain.Entities;
using Domain.Entities.Common;
using MediatR;
using OneOf;

namespace AppLogic.Features.EmployeeTerritories.GetEmployeeTerritoriesById;

//ublic record GetEmployeeTerritoriesByIdRequest(Int32? id) : IRequest<OneOf<GetEmployeeTerritoriesResponse, EmployeeTerritoriesNotFound>>;

public record GetEmployeeTerritoriesByIdRequest(Int32? EmployeeID,String? TerritoryID) : IRequest<OneOf<GetEmployeeTerritoriesResponse, EmployeeTerritoriesNotFound>>;
// {
// __  PrimaryKeyProperties__
// }   


//public record GetHeroByIdRequest(HeroId Id) : IRequest<OneOf<GetHeroResponse, HeroNotFound>>;