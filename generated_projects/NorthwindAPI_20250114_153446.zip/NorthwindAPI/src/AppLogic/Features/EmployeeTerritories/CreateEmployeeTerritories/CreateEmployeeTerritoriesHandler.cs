using AutoMapper;
using AppLogic.Common;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.EmployeeTerritories.CreateEmployeeTerritories;

public class CreateEmployeeTerritoriesHandler : IRequestHandler<CreateEmployeeTerritoriesRequest, GetEmployeeTerritoriesResponse?>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public CreateEmployeeTerritoriesHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<GetEmployeeTerritoriesResponse?> Handle(CreateEmployeeTerritoriesRequest request, CancellationToken cancellationToken)
    {
        var created = _mapper.Map<Domain.Entities.EmployeeTerritories>(request);
        _context.EmployeeTerritories.Add(created);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetEmployeeTerritoriesResponse?>(created);
    }
}