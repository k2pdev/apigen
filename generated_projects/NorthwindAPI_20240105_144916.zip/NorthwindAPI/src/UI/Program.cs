using UI.Common;
using UI.Configurations;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

var  MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
var builder = WebApplication.CreateBuilder(args);


 builder.Services.AddCors(options =>
 {
    options.AddPolicy(name: MyAllowSpecificOrigins,
      policy  =>
      {
          policy.WithOrigins("http://localhost:5000",
                            "https://localhost:5001",
                            "http://localhost",
                            "https://localhost",
                            "http://localhost:80",
                            "https://localhost:443",
                            "<https://productionurl.com>",
                            "<https://productionurl.com>")
                            .AllowAnyHeader()
                            .AllowAnyMethod();
      });
 });


// Controllers
builder.Services
    .AddControllers(options =>
    {
        options.AllowEmptyInputInBodyModelBinding = true;
        options.Filters.Add<ValidationErrorResultFilter>();
    })
    .AddValidationSetup();

builder.Services.AddAuthSetup(builder.Configuration);
builder.Services.AddSwaggerSetup();
builder.Services.AddPersistenceSetup(builder.Configuration);
builder.Services.AddApplicationSetup();
builder.Services.AddCompressionSetup();
builder.Services.AddHttpContextAccessor();
builder.Services.AddMediatRSetup();
builder.Services.AddScoped<ExceptionHandlerMiddleware>();
builder.Logging.ClearProviders();
if (builder.Environment.EnvironmentName != "Testing")
{
    builder.Host.UseLoggingSetup(builder.Configuration);
}
builder.AddOpenTemeletrySetup();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseRouting();
app.UseCors(MyAllowSpecificOrigins);
app.UseResponseCompression();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseMiddleware(typeof(ExceptionHandlerMiddleware));
app.UseSwaggerSetup();
app.UseResponseCompression();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers()
   .RequireAuthorization();

await app.RunAsync();