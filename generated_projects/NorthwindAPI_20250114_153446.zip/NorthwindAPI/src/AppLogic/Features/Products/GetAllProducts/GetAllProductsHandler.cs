using AutoMapper;
using AppLogic.Common;
using AppLogic.Common.Responses;
using AppLogic.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Products.GetAllProducts;

public class GetAllProductsHandler : IRequestHandler<GetAllProductsRequest, PaginatedList<GetProductsResponse>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;
    
    public GetAllProductsHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<PaginatedList<GetProductsResponse>> Handle(GetAllProductsRequest request, CancellationToken cancellationToken)
    {
        var Products = _context.Products;
        return await _mapper.ProjectTo<GetProductsResponse>(Products)
            .OrderBy(x => x.ProductName) 
            .ToPaginatedListAsync(request.CurrentPage, request.PageSize);  
    }
}    