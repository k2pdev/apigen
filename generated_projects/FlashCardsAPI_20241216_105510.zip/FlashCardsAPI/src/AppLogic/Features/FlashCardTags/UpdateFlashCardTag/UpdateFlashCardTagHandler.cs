using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using OneOf;

namespace AppLogic.Features.FlashCardTags.UpdateFlashCardTag;

public class UpdateFlashCardTagHandler : IRequestHandler<UpdateFlashCardTagRequest, OneOf<GetFlashCardTagResponse, FlashCardTagNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public UpdateFlashCardTagHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }

    public async Task<OneOf<GetFlashCardTagResponse, FlashCardTagNotFound>> Handle(UpdateFlashCardTagRequest request,
        CancellationToken cancellationToken)
    {
        var updateFlashCardTag = await _context.FlashCardTag.FirstOrDefaultAsync(x => x.FlashCardId == request.FlashCardId
 && x.TagId == request.TagId
        , cancellationToken);
        if (updateFlashCardTag == null) return new FlashCardTagNotFound();


updateFlashCardTag.FlashCardId = request.FlashCardId;
updateFlashCardTag.TagId = request.TagId;


        _context.FlashCardTag.Update(updateFlashCardTag);
        await _context.SaveChangesAsync(cancellationToken);
        return _mapper.Map<GetFlashCardTagResponse>(updateFlashCardTag);
    }
}    



        // var updateBirdAction = await _context.bird.FirstOrDefaultAsync(x => x.birdId == request.birdId, cancellationToken);

        // if (updateBirdAction == null) return new BirdNotFound();

        // updateBirdAction.birdId = request.birdId;
        // updateBirdAction.birdName = request.birdName;
        // updateBirdAction.birdDescription = request.birdDescription;

        // _context.bird.Update(updateBirdAction);
        // await _context.SaveChangesAsync(cancellationToken);
        // return _mapper.Map<GetBirdResponse>(updateBirdAction);