using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Items.DeleteItem;

public class DeleteItemHandler : IRequestHandler<DeleteItemRequest, OneOf<bool, ItemNotFound>>
{
    private readonly IContext _context;
    public DeleteItemHandler(IContext context)
    {
        _context = context;
    }
    public async Task<OneOf<bool, ItemNotFound>> Handle(DeleteItemRequest request, CancellationToken cancellationToken)
    {
        var Item = await _context.Item.FirstOrDefaultAsync(x => x.ID == request.ID
);

        if (Item is null) return new ItemNotFound();

        _context.Item.Remove(Item);
        return await _context.SaveChangesAsync(cancellationToken) > 0;
    }
}
