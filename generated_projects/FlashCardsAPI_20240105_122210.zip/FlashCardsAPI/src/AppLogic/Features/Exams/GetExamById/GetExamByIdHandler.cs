using Domain.Entities;
using System;
using AutoMapper;
using AppLogic.Common;
using MediatR;
using Microsoft.EntityFrameworkCore;
using OneOf;
using System.Threading;
using System.Threading.Tasks;

namespace AppLogic.Features.Exams.GetExamById;

public class GetExamByIdHandler : IRequestHandler<GetExamByIdRequest, OneOf<GetExamResponse, ExamNotFound>>
{
    private readonly IContext _context;
    private readonly IMapper _mapper;

    public GetExamByIdHandler(IMapper mapper, IContext context)
    {
        _mapper = mapper;
        _context = context;
    }
    public async Task<OneOf<GetExamResponse, ExamNotFound>> Handle(GetExamByIdRequest request, CancellationToken cancellationToken)
    {
        //var Exam = await _context.Exams.FirstOrDefaultAsync(x => x.ExamId == request.id,
          //  cancellationToken: cancellationToken);s
        var Exam = await _context.Exam.FirstOrDefaultAsync(x => x.ExamId == request.ExamId
);

        if (Exam is null) return new ExamNotFound();
        return _mapper.Map<GetExamResponse>(Exam);
    }
}
